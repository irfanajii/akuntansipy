from decimal import Decimal, InvalidOperation

from PySide6.QtWidgets import QMessageBox


def fmt_money(value) -> str:
    """1234567.5 -> 1.234.567,50 (format Indonesia)."""
    s = f"{Decimal(str(value or 0)):,.2f}"
    return s.replace(",", "_").replace(".", ",").replace("_", ".")


def parse_money(text: str) -> Decimal:
    """Input format Indonesia: titik = ribuan, koma = desimal."""
    t = (text or "").strip().replace(" ", "")
    if not t:
        return Decimal("0")
    t = t.replace(".", "").replace(",", ".")
    try:
        d = Decimal(t)
    except InvalidOperation:
        raise ValueError(f"Angka tidak valid: {text!r}")
    if not d.is_finite():
        raise ValueError(f"Angka tidak valid: {text!r}")
    return d


def show_error(parent, message, title="Perhatian"):
    QMessageBox.warning(parent, title, str(message))


def open_file(path):
    """Buka file dengan aplikasi bawaan (mis. pembaca PDF) agar langsung bisa dicetak."""
    from PySide6.QtCore import QUrl
    from PySide6.QtGui import QDesktopServices
    QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
