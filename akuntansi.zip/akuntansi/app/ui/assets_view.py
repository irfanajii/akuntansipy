from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QComboBox, QDateEdit, QDialog, QDialogButtonBox, QFormLayout, QInputDialog, QLineEdit, QMessageBox,
)

from app.database.connection import session_scope
from app.services import accounts as acc_svc
from app.services import assets as svc
from app.services import settings
from app.services.errors import AccountingError
from app.ui.base import ListWindow
from app.ui.common import fmt_money, parse_money, show_error


def _date_edit(d=None):
    e = QDateEdit(d or QDate.currentDate())
    e.setCalendarPopup(True)
    e.setDisplayFormat("dd/MM/yyyy")
    return e


def _buttons(dlg):
    b = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    b.accepted.connect(dlg.accept)
    b.rejected.connect(dlg.reject)
    return b


def _combo(options, default_code=None):
    cb = QComboBox()
    for code, aid, label in options:
        cb.addItem(label, aid)
        if code == default_code:
            cb.setCurrentIndex(cb.count() - 1)
    return cb


class AssetDialog(QDialog):
    def __init__(self, parent, assets_acc, accum_acc, expense_acc, defaults):
        super().__init__(parent)
        self.setWindowTitle("Aset Tetap Baru")
        self.code, self.name = QLineEdit(), QLineEdit()
        self.date_edit = _date_edit()
        self.cost, self.salvage, self.life = QLineEdit(), QLineEdit("0"), QLineEdit("48")
        self.a_acc = _combo(assets_acc, defaults["fixed_asset_account"])
        self.c_acc = _combo(accum_acc, defaults["accum_depreciation_account"])
        self.e_acc = _combo(expense_acc, defaults["depreciation_expense_account"])
        form = QFormLayout(self)
        for label, w in (("Kode", self.code), ("Nama", self.name), ("Tanggal perolehan", self.date_edit),
                         ("Harga perolehan", self.cost), ("Nilai sisa", self.salvage),
                         ("Umur ekonomis (bulan)", self.life), ("Akun aset", self.a_acc),
                         ("Akun akumulasi penyusutan", self.c_acc), ("Akun beban penyusutan", self.e_acc)):
            form.addRow(label, w)
        form.addRow(_buttons(self))
        self.setMinimumWidth(480)

    def values(self):
        return {"code": self.code.text(), "name": self.name.text(),
                "acquisition_date": self.date_edit.date().toPython(), "cost": parse_money(self.cost.text()),
                "salvage_value": parse_money(self.salvage.text()), "life_months": int(self.life.text() or 0),
                "asset_account_id": self.a_acc.currentData(), "accum_account_id": self.c_acc.currentData(),
                "expense_account_id": self.e_acc.currentData()}


class DisposeDialog(QDialog):
    def __init__(self, parent, cash_accounts):
        super().__init__(parent)
        self.setWindowTitle("Pelepasan Aset")
        self.date_edit = _date_edit()
        self.proceeds = QLineEdit("0")
        self.cash = QComboBox()
        self.cash.addItem("(tanpa hasil penjualan)", None)
        for aid, label in cash_accounts:
            self.cash.addItem(label, aid)
        form = QFormLayout(self)
        form.addRow("Tanggal pelepasan", self.date_edit)
        form.addRow("Hasil penjualan", self.proceeds)
        form.addRow("Diterima di", self.cash)
        form.addRow(_buttons(self))
        self.setMinimumWidth(420)


class AssetsView(ListWindow):
    COLUMNS = ["Kode", "Nama", "Tgl Perolehan", "Harga Perolehan", "Akum. Penyusutan", "Nilai Buku", "Bulan", "Status"]

    def __init__(self, user):
        super().__init__("Aset Tetap", self.COLUMNS, right_cols=(3, 4, 5, 6), stretch_col=1, size=(1100, 520))
        self.user, self.rows = user, []
        can = user.can("assets.edit")
        self.add_button("Aset Baru", self._new, can)
        self.add_button("Jalankan Penyusutan", self._depreciate, can)
        self.add_button("Batalkan Penyusutan", self._reverse, can)
        self.add_button("Lepas Aset", self._dispose, can)
        self.add_button("Muat Ulang", self.refresh)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                self.rows = [{"id": a.id, "code": a.code, "name": a.name, "date": a.acquisition_date,
                              "cost": a.cost, "acc": a.accumulated, "months": a.months_depreciated,
                              "life": a.life_months, "status": a.status} for a in svc.list_assets(s, self.user)]
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.set_rows([[r["code"], r["name"], r["date"].strftime("%d/%m/%Y"), fmt_money(r["cost"]),
                        fmt_money(r["acc"]), fmt_money(r["cost"] - r["acc"]), f'{r["months"]}/{r["life"]}',
                        "Aktif" if r["status"] == "ACTIVE" else "Dilepas"] for r in self.rows],
                      gray={i for i, r in enumerate(self.rows) if r["status"] != "ACTIVE"})

    def _accounts(self):
        with session_scope() as s:
            accs = [a for a in acc_svc.list_accounts(s, self.user) if a.is_active and not a.is_header]
            defaults = settings.get_all(s)
        pick = lambda types: [(a.code, a.id, f"{a.code} - {a.name}") for a in accs if a.type in types]  # noqa: E731
        return pick(("ASSET",)), pick(("EXPENSE",)), defaults

    def _new(self):
        try:
            asset_like, expense, defaults = self._accounts()
        except AccountingError as exc:
            show_error(self, exc)
            return
        dlg = AssetDialog(self, asset_like, asset_like, expense, defaults)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            v = dlg.values()
            with session_scope() as s:
                svc.create_asset(s, self.user, **v)
        except (AccountingError, ValueError) as exc:
            show_error(self, exc)
        self.refresh()

    def _depreciate(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Jalankan Penyusutan")
        form = QFormLayout(dlg)
        edit = _date_edit()
        form.addRow("Sampai bulan (tanggal mana pun di bulan itu)", edit)
        form.addRow(_buttons(dlg))
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            with session_scope() as s:
                result = svc.run_depreciation(s, self.user, edit.date().toPython())
        except AccountingError as exc:
            show_error(self, exc)
            return
        if not result:
            QMessageBox.information(self, "Penyusutan", "Tidak ada penyusutan baru yang perlu diposting.")
        else:
            QMessageBox.information(self, "Penyusutan selesai", "\n".join(
                f"{r['period_end']:%m/%Y}: {fmt_money(r['total'])} ({r['assets']} aset) - {r['journal']}"
                for r in result))
        self.refresh()

    def _reverse(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Batalkan Penyusutan")
        form = QFormLayout(dlg)
        edit = _date_edit()
        form.addRow("Bulan yang dibatalkan (tanggal mana pun di bulan itu)", edit)
        form.addRow(_buttons(dlg))
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            with session_scope() as s:
                n = svc.reverse_depreciation(s, self.user, svc.month_end(edit.date().toPython()))
        except AccountingError as exc:
            show_error(self, exc)
            return
        QMessageBox.information(self, "Dibatalkan", f"Penyusutan {n} aset dibatalkan.")
        self.refresh()

    def _dispose(self):
        i = self.current_index()
        if i < 0:
            return
        r = self.rows[i]
        try:
            with session_scope() as s:
                cash = [(a.id, f"{a.code} - {a.name}") for a in acc_svc.list_accounts(s, self.user)
                        if a.type == "ASSET" and a.is_active and not a.is_header]
        except AccountingError as exc:
            show_error(self, exc)
            return
        dlg = DisposeDialog(self, cash)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            with session_scope() as s:
                _a, gain = svc.dispose_asset(s, self.user, r["id"], dlg.date_edit.date().toPython(),
                                             parse_money(dlg.proceeds.text()), dlg.cash.currentData())
        except (AccountingError, ValueError) as exc:
            show_error(self, exc)
            return
        QMessageBox.information(self, "Aset dilepas",
                                f"Laba/(rugi) pelepasan: {fmt_money(gain)}")
        self.refresh()
