from PySide6.QtCore import QDate, Qt
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDateEdit, QDialog, QFormLayout, QHBoxLayout, QHeaderView,
    QInputDialog, QLabel, QLineEdit, QMessageBox, QPushButton, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from app.database.connection import session_scope
from app.services import excel_io as xl
from app.ui import excel_actions as xl_ui
from app.services import accounts as acc_svc
from app.services import journals as svc
from app.services.errors import AccountingError
from app.ui.common import fmt_money, parse_money, show_error

RIGHT = Qt.AlignRight | Qt.AlignVCenter


class JournalDialog(QDialog):
    """Form jurnal baru (detail=None) atau tampilan baca-saja (detail=dict)."""

    def __init__(self, parent, user, accounts=None, detail=None):
        super().__init__(parent)
        self.user = user
        self.accounts = accounts or []
        self.readonly = detail is not None
        self.setWindowTitle(f"Jurnal {detail['number']}" if detail else "Jurnal Umum Baru")
        self.resize(860, 540)

        self.date_edit = QDateEdit(QDate.currentDate())
        self.date_edit.setCalendarPopup(True)
        self.date_edit.setDisplayFormat("dd/MM/yyyy")
        self.desc_edit = QLineEdit()
        form = QFormLayout()
        form.addRow("Tanggal", self.date_edit)
        form.addRow("Keterangan", self.desc_edit)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Akun", "Keterangan Baris", "Debit", "Kredit"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setColumnWidth(2, 140)
        self.table.setColumnWidth(3, 140)
        self.total_label = QLabel()

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(self.table)
        layout.addWidget(self.total_label)

        bar = QHBoxLayout()
        if self.readonly:
            self._fill_readonly(detail)
        else:
            btn_add = QPushButton("Tambah Baris")
            btn_del = QPushButton("Hapus Baris")
            btn_add.clicked.connect(self._add_row)
            btn_del.clicked.connect(self._del_row)
            btn_save = QPushButton("Simpan")
            btn_save.clicked.connect(self._save)
            bar.addWidget(btn_add)
            bar.addWidget(btn_del)
            bar.addStretch()
            bar.addWidget(btn_save)
            for _ in range(4):
                self._add_row()
            self.table.itemChanged.connect(lambda _item: self._update_totals())
            self._update_totals()
        btn_close = QPushButton("Tutup")
        btn_close.clicked.connect(self.reject)
        bar.addWidget(btn_close)
        layout.addLayout(bar)

    # ---- mode baca-saja ----
    def _fill_readonly(self, d):
        self.date_edit.setDate(QDate(d["date"].year, d["date"].month, d["date"].day))
        self.date_edit.setEnabled(False)
        self.desc_edit.setText(d["description"])
        self.desc_edit.setReadOnly(True)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        total_d = total_k = 0
        for ln in d["lines"]:
            r = self.table.rowCount()
            self.table.insertRow(r)
            self.table.setItem(r, 0, QTableWidgetItem(ln["account"]))
            self.table.setItem(r, 1, QTableWidgetItem(ln["description"]))
            for c, key in ((2, "debit"), (3, "credit")):
                it = QTableWidgetItem(fmt_money(ln[key]) if ln[key] else "")
                it.setTextAlignment(RIGHT)
                self.table.setItem(r, c, it)
            total_d += ln["debit"]
            total_k += ln["credit"]
        self.total_label.setText(f"Total Debit: {fmt_money(total_d)}    Total Kredit: {fmt_money(total_k)}")

    # ---- mode input ----
    def _add_row(self):
        r = self.table.rowCount()
        self.table.insertRow(r)
        combo = QComboBox()
        combo.addItem("", None)
        for aid, label in self.accounts:
            combo.addItem(label, aid)
        self.table.setCellWidget(r, 0, combo)
        self.table.setItem(r, 1, QTableWidgetItem(""))
        for c in (2, 3):
            it = QTableWidgetItem("")
            it.setTextAlignment(RIGHT)
            self.table.setItem(r, c, it)

    def _del_row(self):
        r = self.table.currentRow()
        if r >= 0:
            self.table.removeRow(r)
            self._update_totals()

    def _cell_money(self, row, col, strict=False):
        item = self.table.item(row, col)
        text = item.text() if item else ""
        try:
            return parse_money(text)
        except ValueError:
            if strict:
                raise
            return 0

    def _update_totals(self):
        td = sum(self._cell_money(r, 2) for r in range(self.table.rowCount()))
        tk = sum(self._cell_money(r, 3) for r in range(self.table.rowCount()))
        diff = td - tk
        color = "green" if diff == 0 and td > 0 else "red"
        self.total_label.setText(
            f"Total Debit: {fmt_money(td)}    Total Kredit: {fmt_money(tk)}    "
            f'Selisih: <span style="color:{color}">{fmt_money(diff)}</span>'
        )

    def _collect(self):
        lines = []
        for r in range(self.table.rowCount()):
            combo = self.table.cellWidget(r, 0)
            aid = combo.currentData()
            debit = self._cell_money(r, 2, strict=True)
            credit = self._cell_money(r, 3, strict=True)
            desc_item = self.table.item(r, 1)
            desc = desc_item.text() if desc_item else ""
            if aid is None and debit == 0 and credit == 0:
                continue  # baris kosong
            if aid is None:
                raise AccountingError(f"Baris {r + 1}: akun belum dipilih.")
            lines.append(svc.LineInput(account_id=aid, debit=debit, credit=credit, description=desc))
        return lines

    def _save(self):
        try:
            lines = self._collect()
            with session_scope() as s:
                svc.post_journal(s, self.user, self.date_edit.date().toPython(),
                                 self.desc_edit.text(), lines)
        except (AccountingError, ValueError) as exc:
            show_error(self, exc)
            return
        self.accept()


class JournalsView(QWidget):
    COLUMNS = ["Nomor", "Tanggal", "Keterangan", "Total", "Status"]

    def __init__(self, user):
        super().__init__()
        self.setWindowTitle("Jurnal Umum")
        self.user = user
        self.rows = []

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.doubleClicked.connect(self._view)

        btn_new = QPushButton("Jurnal Baru")
        btn_view = QPushButton("Lihat Detail")
        btn_void = QPushButton("Batalkan Jurnal")
        btn_refresh = QPushButton("Muat Ulang")
        btn_new.clicked.connect(self._new)
        btn_view.clicked.connect(self._view)
        btn_void.clicked.connect(self._void)
        btn_refresh.clicked.connect(self.refresh)
        btn_new.setEnabled(user.can("journals.post"))
        btn_import = QPushButton("Import Excel")
        btn_export = QPushButton("Export Excel")
        btn_template = QPushButton("Template Import")
        btn_import.clicked.connect(self._import)
        btn_export.clicked.connect(self._export)
        btn_template.clicked.connect(self._template)
        btn_import.setEnabled(user.can("journals.post"))
        btn_void.setEnabled(user.can("journals.void"))

        bar = QHBoxLayout()
        for b in (btn_new, btn_view, btn_void, btn_refresh, btn_import, btn_export, btn_template):
            bar.addWidget(b)
        bar.addStretch()
        layout = QVBoxLayout(self)
        layout.addLayout(bar)
        layout.addWidget(self.table)
        self.resize(900, 520)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                self.rows = svc.list_journals(s, self.user)
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.table.setRowCount(len(self.rows))
        for i, r in enumerate(self.rows):
            status = "Dibatalkan" if r["status"] == "REVERSED" else (
                "Jurnal pembalik" if r["source"] == "REVERSAL" else "Diposting")
            values = [r["number"], r["date"].strftime("%d/%m/%Y"), r["description"],
                      fmt_money(r["total"]), status]
            for c, text in enumerate(values):
                it = QTableWidgetItem(text)
                if c == 3:
                    it.setTextAlignment(RIGHT)
                if r["status"] == "REVERSED":
                    it.setForeground(Qt.gray)
                self.table.setItem(i, c, it)

    def _selected(self):
        row = self.table.currentRow()
        return self.rows[row] if row >= 0 else None

    def _new(self):
        try:
            with session_scope() as s:
                accs = [(a.id, f"{a.code} - {a.name}")
                        for a in acc_svc.list_accounts(s, self.user)
                        if a.is_active and not a.is_header]
        except AccountingError as exc:
            show_error(self, exc)
            return
        if JournalDialog(self, self.user, accounts=accs).exec() == QDialog.Accepted:
            self.refresh()

    def _view(self):
        sel = self._selected()
        if not sel:
            return
        try:
            with session_scope() as s:
                detail = svc.journal_detail(s, self.user, sel["id"])
        except AccountingError as exc:
            show_error(self, exc)
            return
        JournalDialog(self, self.user, detail=detail).exec()

    def _void(self):
        sel = self._selected()
        if not sel:
            return
        reason, ok = QInputDialog.getText(
            self, "Batalkan Jurnal",
            f"Alasan pembatalan {sel['number']}\n(dibuat jurnal pembalik bertanggal hari ini):")
        if not ok:
            return
        try:
            with session_scope() as s:
                rev = svc.void_journal(s, self.user, sel["id"], reason)
                number = rev.number
        except AccountingError as exc:
            show_error(self, exc)
            self.refresh()
            return
        QMessageBox.information(self, "Selesai", f"Jurnal pembalik {number} berhasil dibuat.")
        self.refresh()

    def _export(self):
        today = QDate.currentDate()
        dates = xl_ui.ask_dates(self, "Export Jurnal", ["Dari tanggal", "Sampai tanggal"],
                                [QDate(today.year(), 1, 1), today])
        if dates is None:
            return
        xl_ui.export_to_file(
            self, "Export Jurnal", "jurnal.xlsx",
            lambda s, p: xl.export_journals(s, self.user, p, dates[0], dates[1]))

    def _import(self):
        xl_ui.import_from_file(self, "Import Jurnal dari Excel",
                               lambda s, p: xl.import_journals(s, self.user, p), "jurnal")
        self.refresh()

    def _template(self):
        xl_ui.save_template(self, "Simpan Template Import Jurnal",
                            "template_import_jurnal.xlsx", xl.template_journals)
