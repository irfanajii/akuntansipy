"""Layar penjualan dan pembelian (satu implementasi untuk keduanya, diatur lewat TradeMode)."""
from dataclasses import dataclass
from datetime import date

from PySide6.QtCore import QDate, Qt
from PySide6.QtWidgets import (
    QComboBox, QDateEdit, QDialog, QFileDialog, QFormLayout, QHBoxLayout, QHeaderView, QInputDialog,
    QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from app.database.connection import session_scope
from app.reports.pdf import render_invoice_pdf
from app.services import accounts as acc_svc
from app.services import inventory, purchases, sales, settings
from app.services.errors import AccountingError
from app.ui.base import RIGHT, ListWindow
from app.ui.common import fmt_money, open_file, parse_money, show_error


@dataclass
class TradeMode:
    key: str
    svc: object
    perm: str                 # awalan izin: sales / purchases
    party: str                # Pelanggan / Pemasok
    invoice_title: str
    settle_title: str
    return_title: str
    line_types: tuple         # tipe akun yang boleh dipilih di baris faktur
    pdf_title: str
    pdf_party_label: str
    cash_label: str
    use_item_price: bool      # harga baris diisi dari harga jual barang


SALES = TradeMode("sales", sales, "sales", "Pelanggan", "Faktur Penjualan", "Penerimaan Pembayaran",
                  "Retur Penjualan", ("REVENUE",), "FAKTUR PENJUALAN", "Kepada:", "Diterima di (kas/bank)", True)
PURCHASE = TradeMode("purchase", purchases, "purchases", "Pemasok", "Faktur Pembelian", "Pembayaran Hutang",
                     "Retur Pembelian", ("ASSET", "EXPENSE"), "FAKTUR PEMBELIAN", "Dari:", "Dibayar dari (kas/bank)",
                     False)


def _ro(text="", right=False):
    it = QTableWidgetItem(text)
    it.setFlags(it.flags() & ~Qt.ItemIsEditable)
    if right:
        it.setTextAlignment(RIGHT)
    return it


def _num_item(text=""):
    it = QTableWidgetItem(text)
    it.setTextAlignment(RIGHT)
    return it


def _date_edit(qdate=None):
    e = QDateEdit(qdate or QDate.currentDate())
    e.setCalendarPopup(True)
    e.setDisplayFormat("dd/MM/yyyy")
    return e


def _fmt(d):
    return d.strftime("%d/%m/%Y")


# ====================================================================== faktur
class InvoiceDialog(QDialog):
    def __init__(self, parent, user, mode, parties, accounts, items, warehouses, default_tax="0"):
        super().__init__(parent)
        self.user, self.mode, self.parties, self.items = user, mode, parties, items
        self.accounts, self._busy = accounts, True
        self.setWindowTitle(f"{mode.invoice_title} Baru")
        self.resize(1050, 600)

        self.party = QComboBox()
        for p in parties:
            self.party.addItem(p["label"], p["id"])
        self.date_edit, self.due_edit = _date_edit(), _date_edit()
        self.tax_edit = QLineEdit(default_tax.replace(".", ","))
        self.warehouse = QComboBox()
        for wid, label in warehouses:
            self.warehouse.addItem(label, wid)
        self.ref_edit = QLineEdit()
        self.desc_edit = QLineEdit()
        form = QFormLayout()
        form.addRow(mode.party, self.party)
        form.addRow("Tanggal", self.date_edit)
        form.addRow("Jatuh tempo", self.due_edit)
        if mode.key == "purchase":
            form.addRow("No. faktur pemasok", self.ref_edit)
        form.addRow("Gudang (untuk barang)", self.warehouse)
        form.addRow("Pajak (%)", self.tax_edit)
        form.addRow("Catatan", self.desc_edit)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Barang", "Deskripsi", "Qty", "Harga", "Jumlah", "Akun"])
        h = self.table.horizontalHeader()
        h.setSectionResizeMode(1, QHeaderView.Stretch)
        h.setSectionResizeMode(5, QHeaderView.Stretch)
        h.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        for c, w in ((2, 80), (3, 120), (4, 120)):
            self.table.setColumnWidth(c, w)
        self.total_label = QLabel()

        btns = [QPushButton(t) for t in ("Tambah Baris", "Hapus Baris", "Simpan", "Batal")]
        btns[0].clicked.connect(self._add_row)
        btns[1].clicked.connect(self._del_row)
        btns[2].clicked.connect(self._save)
        btns[3].clicked.connect(self.reject)
        bar = QHBoxLayout()
        bar.addWidget(btns[0])
        bar.addWidget(btns[1])
        bar.addStretch()
        bar.addWidget(btns[2])
        bar.addWidget(btns[3])
        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(self.table)
        layout.addWidget(self.total_label)
        layout.addLayout(bar)

        for _ in range(4):
            self._add_row()
        self._busy = False
        self.party.currentIndexChanged.connect(self._update_due)
        self.date_edit.dateChanged.connect(self._update_due)
        self.table.itemChanged.connect(self._on_item_changed)
        self.tax_edit.textChanged.connect(self._update_totals)
        self._update_due()
        self._update_totals()

    def _update_due(self):
        idx = self.party.currentIndex()
        term = self.parties[idx]["term_days"] if idx >= 0 else 30
        self.due_edit.setDate(self.date_edit.date().addDays(term))

    def _add_row(self):
        r = self.table.rowCount()
        busy, self._busy = self._busy, True
        self.table.insertRow(r)
        item_cb = QComboBox()
        item_cb.addItem("", None)
        for it in self.items:
            item_cb.addItem(it["label"], it["id"])
        item_cb.currentIndexChanged.connect(lambda _i, cb=item_cb: self._on_item_chosen(cb))
        self.table.setCellWidget(r, 0, item_cb)
        self.table.setItem(r, 1, QTableWidgetItem(""))
        self.table.setItem(r, 2, _num_item(""))
        self.table.setItem(r, 3, _num_item(""))
        self.table.setItem(r, 4, _ro("", right=True))
        acc_cb = QComboBox()
        acc_cb.addItem("(otomatis)" if self.mode.key == "sales" else "(pilih akun / otomatis untuk barang)", None)
        for aid, label in self.accounts:
            acc_cb.addItem(label, aid)
        self.table.setCellWidget(r, 5, acc_cb)
        self._busy = busy

    def _del_row(self):
        r = self.table.currentRow()
        if r >= 0:
            self.table.removeRow(r)
            self._update_totals()

    def _row_of(self, widget):
        for r in range(self.table.rowCount()):
            if self.table.cellWidget(r, 0) is widget:
                return r
        return -1

    def _on_item_chosen(self, cb):
        r = self._row_of(cb)
        item = next((i for i in self.items if i["id"] == cb.currentData()), None)
        if r < 0 or item is None:
            return
        self._busy = True
        self.table.item(r, 1).setText(item["name"])
        if self.mode.use_item_price and item["price"]:
            self.table.item(r, 3).setText(fmt_money(item["price"]))
        if not self.table.item(r, 2).text().strip():
            self.table.item(r, 2).setText("1")
        self._busy = False
        self._refresh_row(r)
        self._update_totals()

    def _cell(self, r, c):
        it = self.table.item(r, c)
        return it.text() if it else ""

    def _line_amount(self, r):
        try:
            return parse_money(self._cell(r, 2)) * parse_money(self._cell(r, 3))
        except ValueError:
            return 0

    def _refresh_row(self, r):
        busy, self._busy = self._busy, True
        amount = self._line_amount(r)
        self.table.item(r, 4).setText(fmt_money(amount) if amount else "")
        self._busy = busy

    def _on_item_changed(self, item):
        if self._busy or item.column() not in (2, 3):
            return
        self._refresh_row(item.row())
        self._update_totals()

    def _update_totals(self):
        sub = sum(self._line_amount(r) for r in range(self.table.rowCount()))
        try:
            rate = parse_money(self.tax_edit.text())
        except ValueError:
            rate = 0
        tax = sub * rate / 100
        self.total_label.setText(
            f"Subtotal: {fmt_money(sub)}    Pajak: {fmt_money(tax)}    <b>Total: {fmt_money(sub + tax)}</b>")

    def _collect(self):
        lines = []
        for r in range(self.table.rowCount()):
            item_id = self.table.cellWidget(r, 0).currentData()
            desc, qty, price = self._cell(r, 1).strip(), self._cell(r, 2), self._cell(r, 3)
            if item_id is None and not desc and not qty.strip() and not price.strip():
                continue
            lines.append(inventory_line(desc, qty, price, self.table.cellWidget(r, 5).currentData(), item_id))
        return lines

    def _save(self):
        try:
            lines = self._collect()
            extra = {"supplier_invoice_no": self.ref_edit.text()} if self.mode.key == "purchase" else {}
            with session_scope() as s:
                self.mode.svc.create_invoice(
                    s, self.user, self.party.currentData(), self.date_edit.date().toPython(), lines,
                    tax_rate=parse_money(self.tax_edit.text()), due_date=self.due_edit.date().toPython(),
                    description=self.desc_edit.text(), warehouse_id=self.warehouse.currentData(), **extra)
        except (AccountingError, ValueError) as exc:
            show_error(self, exc)
            return
        self.accept()


def inventory_line(desc, qty, price, account_id, item_id):
    from app.services.trade_common import InvoiceLineInput
    return InvoiceLineInput(description=desc, quantity=parse_money(qty), unit_price=parse_money(price),
                            account_id=account_id, item_id=item_id)


class InvoicesView(ListWindow):
    def __init__(self, user, mode):
        super().__init__(mode.invoice_title,
                         ["Nomor", "Tanggal", mode.party, "Jatuh Tempo", "Total", "Dibayar", "Diretur", "Sisa", "Status"],
                         right_cols=(4, 5, 6, 7), stretch_col=2, size=(1100, 540))
        self.user, self.mode, self.rows = user, mode, []
        p = mode.perm
        self.add_button("Faktur Baru", self._new, user.can(f"{p}.post"))
        self.add_button("Cetak PDF", self._print)
        self.add_button("Retur", self._return, user.can(f"{p}.post"))
        self.add_button("Batalkan Faktur", self._void, user.can(f"{p}.void"))
        self.add_button("Muat Ulang", self.refresh)
        self.table.doubleClicked.connect(self._print)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                self.rows = self.mode.svc.list_invoices(s, self.user)
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.set_rows([[r["number"], _fmt(r["date"]), r["party"], _fmt(r["due_date"]), fmt_money(r["total"]),
                        fmt_money(r["paid"]), fmt_money(r["returned"]), fmt_money(r["outstanding"]),
                        r["status_label"]] for r in self.rows],
                      gray={i for i, r in enumerate(self.rows) if r["status"] == "VOID"})

    def _selected(self):
        i = self.current_index()
        return self.rows[i] if i >= 0 else None

    def _new(self):
        m = self.mode
        try:
            with session_scope() as s:
                parties = [{"id": c.id, "label": f"{c.code} - {c.name}", "term_days": c.term_days}
                           for c in m.svc.list_parties(s, self.user, include_inactive=False)]
                accounts = [(a.id, f"{a.code} - {a.name}") for a in acc_svc.list_accounts(s, self.user)
                            if a.type in m.line_types and a.is_active and not a.is_header]
                items = [{"id": i.id, "label": f"{i.code} - {i.name}", "name": i.name, "price": i.sell_price}
                         for i in inventory.list_items(s, self.user, include_inactive=False)]
                whs = [(w.id, f"{w.code} - {w.name}") for w in inventory.list_warehouses(s, self.user, False)]
                tax = settings.get(s, "default_tax_rate")
        except AccountingError as exc:
            show_error(self, exc)
            return
        if not parties:
            show_error(self, f"Belum ada {m.party.lower()} aktif. Tambahkan dulu di menu Master.")
            return
        if InvoiceDialog(self, self.user, m, parties, accounts, items, whs, tax).exec() == QDialog.Accepted:
            self.refresh()

    def _print(self):
        sel = self._selected()
        if not sel:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Simpan Faktur PDF", f"{sel['number']}.pdf", "PDF (*.pdf)")
        if not path:
            return
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        try:
            with session_scope() as s:
                detail = self.mode.svc.invoice_detail(s, self.user, sel["id"])
                company = settings.company_info(s)
            render_invoice_pdf(detail, company, path, title=self.mode.pdf_title,
                               party_label=self.mode.pdf_party_label)
        except (AccountingError, OSError) as exc:
            show_error(self, exc)
            return
        open_file(path)

    def _return(self):
        sel = self._selected()
        if not sel:
            return
        if sel["status"] == "VOID":
            show_error(self, "Faktur ini sudah dibatalkan.")
            return
        if ReturnDialog(self, self.user, self.mode, sel).exec() == QDialog.Accepted:
            self.refresh()

    def _void(self):
        sel = self._selected()
        if not sel:
            return
        reason, ok = QInputDialog.getText(
            self, "Batalkan Faktur", f"Alasan pembatalan {sel['number']}\n(jurnal pembalik bertanggal hari ini):")
        if not ok:
            return
        try:
            with session_scope() as s:
                self.mode.svc.void_invoice(s, self.user, sel["id"], reason)
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()


# ====================================================================== retur
class ReturnDialog(QDialog):
    def __init__(self, parent, user, mode, invoice):
        super().__init__(parent)
        self.user, self.mode, self.invoice, self.lines = user, mode, invoice, []
        self.setWindowTitle(f"{mode.return_title} - {invoice['number']}")
        self.resize(900, 460)
        try:
            with session_scope() as s:
                self.lines = mode.svc.returnable_lines(s, user, invoice["id"])
        except AccountingError as exc:
            show_error(self, exc)
        self.date_edit = _date_edit()
        self.desc_edit = QLineEdit()
        form = QFormLayout()
        form.addRow("Tanggal retur", self.date_edit)
        form.addRow("Catatan", self.desc_edit)
        self.table = QTableWidget(len(self.lines), 6)
        self.table.setHorizontalHeaderLabels(["Deskripsi", "Qty Faktur", "Sudah Diretur", "Sisa", "Harga", "Qty Retur"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        for i, ln in enumerate(self.lines):
            self.table.setItem(i, 0, _ro(ln["description"]))
            for c, key in ((1, "quantity"), (2, "returned_qty"), (3, "remaining")):
                self.table.setItem(i, c, _ro(f"{ln[key].normalize():f}", right=True))
            self.table.setItem(i, 4, _ro(fmt_money(ln["unit_price"]), right=True))
            self.table.setItem(i, 5, _num_item(""))
        save, cancel = QPushButton("Simpan Retur"), QPushButton("Batal")
        save.clicked.connect(self._save)
        cancel.clicked.connect(self.reject)
        bar = QHBoxLayout()
        bar.addStretch()
        bar.addWidget(save)
        bar.addWidget(cancel)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Sisa tagihan faktur: <b>{fmt_money(invoice['outstanding'])}</b> "
                                "(nilai retur tidak boleh melebihinya)"))
        layout.addLayout(form)
        layout.addWidget(self.table)
        layout.addLayout(bar)

    def _save(self):
        try:
            lines = []
            for i, ln in enumerate(self.lines):
                it = self.table.item(i, 5)
                lines.append((ln["line_id"], parse_money(it.text() if it else "")))
            with session_scope() as s:
                self.mode.svc.create_return(s, self.user, self.invoice["id"], self.date_edit.date().toPython(),
                                            lines, self.desc_edit.text())
        except (AccountingError, ValueError) as exc:
            show_error(self, exc)
            return
        self.accept()


class ReturnsView(ListWindow):
    def __init__(self, user, mode):
        super().__init__(mode.return_title, ["Nomor", "Tanggal", "Faktur", mode.party, "Total", "Status"],
                         right_cols=(4,), stretch_col=3)
        self.user, self.mode, self.rows = user, mode, []
        self.add_button("Batalkan Retur", self._void, user.can(f"{mode.perm}.void"))
        self.add_button("Muat Ulang", self.refresh)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                self.rows = self.mode.svc.list_returns(s, self.user)
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.set_rows([[r["number"], _fmt(r["date"]), r["invoice"], r["party"], fmt_money(r["total"]),
                        "Dibatalkan" if r["status"] == "VOID" else "Diposting"] for r in self.rows],
                      gray={i for i, r in enumerate(self.rows) if r["status"] == "VOID"})

    def _void(self):
        i = self.current_index()
        if i < 0:
            return
        sel = self.rows[i]
        reason, ok = QInputDialog.getText(self, "Batalkan Retur", f"Alasan pembatalan {sel['number']}:")
        if not ok:
            return
        try:
            with session_scope() as s:
                self.mode.svc.void_return(s, self.user, sel["id"], reason)
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()


# ====================================================================== penerimaan / pembayaran
class SettleDialog(QDialog):
    def __init__(self, parent, user, mode, parties, cash_accounts):
        super().__init__(parent)
        self.user, self.mode, self.invoices, self._busy = user, mode, [], False
        self.setWindowTitle(f"{mode.settle_title} Baru")
        self.resize(900, 520)
        self.party = QComboBox()
        for p in parties:
            self.party.addItem(p["label"], p["id"])
        self.date_edit = _date_edit()
        self.cash = QComboBox()
        for aid, label in cash_accounts:
            self.cash.addItem(label, aid)
        self.desc_edit = QLineEdit()
        form = QFormLayout()
        form.addRow(mode.party, self.party)
        form.addRow("Tanggal", self.date_edit)
        form.addRow(mode.cash_label, self.cash)
        form.addRow("Catatan", self.desc_edit)
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["Faktur", "Tanggal", "Jatuh Tempo", "Total", "Sisa", "Bayar"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.total_label = QLabel()
        btn_all, btn_save, btn_close = QPushButton("Lunasi Semua"), QPushButton("Simpan"), QPushButton("Batal")
        btn_all.clicked.connect(self._pay_all)
        btn_save.clicked.connect(self._save)
        btn_close.clicked.connect(self.reject)
        bar = QHBoxLayout()
        bar.addWidget(btn_all)
        bar.addStretch()
        bar.addWidget(btn_save)
        bar.addWidget(btn_close)
        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(self.table)
        layout.addWidget(self.total_label)
        layout.addLayout(bar)
        self.party.currentIndexChanged.connect(self._load)
        self.table.itemChanged.connect(lambda _i: self._update_total())
        self._load()

    def _load(self):
        pid = self.party.currentData()
        try:
            with session_scope() as s:
                self.invoices = self.mode.svc.outstanding_invoices(s, self.user, pid) if pid else []
        except AccountingError as exc:
            show_error(self, exc)
            self.invoices = []
        self._busy = True
        self.table.setRowCount(len(self.invoices))
        for i, inv in enumerate(self.invoices):
            vals = [inv["number"], _fmt(inv["date"]), _fmt(inv["due_date"]), fmt_money(inv["total"]),
                    fmt_money(inv["outstanding"])]
            for c, text in enumerate(vals):
                self.table.setItem(i, c, _ro(text, right=c >= 3))
            self.table.setItem(i, 5, _num_item(""))
        self._busy = False
        self._update_total()

    def _pay_all(self):
        self._busy = True
        for i, inv in enumerate(self.invoices):
            self.table.item(i, 5).setText(fmt_money(inv["outstanding"]))
        self._busy = False
        self._update_total()

    def _amounts(self, strict=False):
        out = []
        for i, inv in enumerate(self.invoices):
            text = self.table.item(i, 5).text() if self.table.item(i, 5) else ""
            try:
                out.append((inv["id"], parse_money(text)))
            except ValueError:
                if strict:
                    raise
                out.append((inv["id"], 0))
        return out

    def _update_total(self):
        if not self._busy:
            self.total_label.setText(f"<b>Total: {fmt_money(sum(a for _, a in self._amounts()))}</b>")

    def _save(self):
        try:
            allocations = self._amounts(strict=True)
            with session_scope() as s:
                self.mode.svc.create_settlement(s, self.user, self.party.currentData(),
                                                self.date_edit.date().toPython(), self.cash.currentData(),
                                                allocations, self.desc_edit.text())
        except (AccountingError, ValueError) as exc:
            show_error(self, exc)
            return
        self.accept()


class SettlementsView(ListWindow):
    def __init__(self, user, mode):
        super().__init__(mode.settle_title, ["Nomor", "Tanggal", mode.party, "Akun Kas/Bank", "Jumlah", "Status"],
                         right_cols=(4,), stretch_col=2)
        self.user, self.mode, self.rows = user, mode, []
        self.add_button(f"{mode.settle_title} Baru", self._new, user.can(f"{mode.perm}.post"))
        self.add_button("Batalkan", self._void, user.can(f"{mode.perm}.void"))
        self.add_button("Muat Ulang", self.refresh)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                self.rows = self.mode.svc.list_settlements(s, self.user)
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.set_rows([[r["number"], _fmt(r["date"]), r["party"], r["cash_account"], fmt_money(r["amount"]),
                        "Dibatalkan" if r["status"] == "VOID" else "Diposting"] for r in self.rows],
                      gray={i for i, r in enumerate(self.rows) if r["status"] == "VOID"})

    def _new(self):
        try:
            with session_scope() as s:
                parties = [{"id": c.id, "label": f"{c.code} - {c.name}"}
                           for c in self.mode.svc.list_parties(s, self.user, include_inactive=False)]
                cash = [(a.id, f"{a.code} - {a.name}") for a in acc_svc.list_accounts(s, self.user)
                        if a.type == "ASSET" and a.is_active and not a.is_header]
        except AccountingError as exc:
            show_error(self, exc)
            return
        if not parties:
            show_error(self, f"Belum ada {self.mode.party.lower()} aktif.")
            return
        if SettleDialog(self, self.user, self.mode, parties, cash).exec() == QDialog.Accepted:
            self.refresh()

    def _void(self):
        i = self.current_index()
        if i < 0:
            return
        sel = self.rows[i]
        reason, ok = QInputDialog.getText(
            self, "Batalkan", f"Alasan pembatalan {sel['number']}\n(jurnal pembalik bertanggal hari ini):")
        if not ok:
            return
        try:
            with session_scope() as s:
                self.mode.svc.void_settlement(s, self.user, sel["id"], reason)
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()


# ====================================================================== kelas konkret untuk menu
class SalesInvoicesView(InvoicesView):
    def __init__(self, user):
        super().__init__(user, SALES)


class SalesSettlementsView(SettlementsView):
    def __init__(self, user):
        super().__init__(user, SALES)


class SalesReturnsView(ReturnsView):
    def __init__(self, user):
        super().__init__(user, SALES)


class PurchaseInvoicesView(InvoicesView):
    def __init__(self, user):
        super().__init__(user, PURCHASE)


class PurchaseSettlementsView(SettlementsView):
    def __init__(self, user):
        super().__init__(user, PURCHASE)


class PurchaseReturnsView(ReturnsView):
    def __init__(self, user):
        super().__init__(user, PURCHASE)
