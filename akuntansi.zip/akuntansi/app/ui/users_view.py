from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout, QGroupBox, QLineEdit, QVBoxLayout,
)

from app.database.connection import session_scope
from app.services import users as svc
from app.services.errors import AccountingError
from app.services.permissions import PERMISSIONS
from app.ui.base import ListWindow
from app.ui.common import show_error


def _buttons(dlg):
    b = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    b.accepted.connect(dlg.accept)
    b.rejected.connect(dlg.reject)
    return b


class UserDialog(QDialog):
    def __init__(self, parent, roles, data=None):
        super().__init__(parent)
        self.setWindowTitle("Ubah User" if data else "User Baru")
        self.username, self.full_name = QLineEdit(), QLineEdit()
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.role = QComboBox()
        for r in roles:
            self.role.addItem(r["name"], r["id"])
        self.active = QCheckBox("Aktif")
        self.active.setChecked(True)
        if data:
            self.username.setText(data["username"])
            self.username.setEnabled(False)
            self.full_name.setText(data["full_name"])
            self.role.setCurrentIndex(max(0, self.role.findData(data["role_id"])))
            self.active.setChecked(data["is_active"])
        form = QFormLayout(self)
        form.addRow("Username", self.username)
        form.addRow("Nama lengkap", self.full_name)
        form.addRow("Password baru (kosongkan jika tidak diubah)" if data else "Password (min. 8 karakter)",
                    self.password)
        form.addRow("Role", self.role)
        form.addRow("", self.active)
        form.addRow(_buttons(self))
        self.setMinimumWidth(460)


class RoleDialog(QDialog):
    def __init__(self, parent, data=None):
        super().__init__(parent)
        self.setWindowTitle("Ubah Role" if data else "Role Baru")
        self.name = QLineEdit(data["name"] if data else "")
        self.boxes = {}
        have = set(data["permissions"]) if data else set()
        group = QGroupBox("Izin akses")
        inner = QVBoxLayout(group)
        for key, label in PERMISSIONS.items():
            cb = QCheckBox(f"{label}  [{key}]")
            cb.setChecked(key in have)
            self.boxes[key] = cb
            inner.addWidget(cb)
        form = QVBoxLayout(self)
        f = QFormLayout()
        f.addRow("Nama role", self.name)
        form.addLayout(f)
        form.addWidget(group)
        form.addWidget(_buttons(self))

    def permissions(self):
        return [k for k, cb in self.boxes.items() if cb.isChecked()]


class RolesView(ListWindow):
    def __init__(self, user):
        super().__init__("Role", ["Nama", "Jumlah izin"], stretch_col=0, size=(420, 360))
        self.user, self.rows = user, []
        self.add_button("Role Baru", self._new)
        self.add_button("Ubah", self._edit)
        self.table.doubleClicked.connect(self._edit)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                self.rows = svc.list_roles(s, self.user)
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.set_rows([[r["name"], "semua" if r["permissions"] == ["*"] else len(r["permissions"])]
                       for r in self.rows])

    def _save(self, dlg, role_id):
        try:
            with session_scope() as s:
                svc.save_role(s, self.user, name=dlg.name.text(), permissions=dlg.permissions(), role_id=role_id)
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()

    def _new(self):
        dlg = RoleDialog(self)
        if dlg.exec() == QDialog.Accepted:
            self._save(dlg, None)

    def _edit(self):
        i = self.current_index()
        if i < 0:
            return
        r = self.rows[i]
        if r["permissions"] == ["*"]:
            show_error(self, "Role Administrator memiliki semua izin dan tidak bisa diubah.")
            return
        dlg = RoleDialog(self, r)
        if dlg.exec() == QDialog.Accepted:
            self._save(dlg, r["id"])


class UsersView(ListWindow):
    def __init__(self, user):
        super().__init__("User", ["Username", "Nama", "Role", "Status"], stretch_col=1, size=(720, 440))
        self.user, self.rows, self.roles, self._roles_win = user, [], [], None
        self.add_button("User Baru", self._new)
        self.add_button("Ubah / Reset Password", self._edit)
        self.add_button("Kelola Role...", self._open_roles)
        self.add_button("Muat Ulang", self.refresh)
        self.table.doubleClicked.connect(self._edit)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                self.rows = svc.list_users(s, self.user)
                self.roles = svc.list_roles(s, self.user)
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.set_rows([[r["username"], r["full_name"], r["role"], "Aktif" if r["is_active"] else "Nonaktif"]
                       for r in self.rows], gray={i for i, r in enumerate(self.rows) if not r["is_active"]})

    def _new(self):
        dlg = UserDialog(self, self.roles)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            with session_scope() as s:
                svc.create_user(s, self.user, username=dlg.username.text(), full_name=dlg.full_name.text(),
                                password=dlg.password.text(), role_id=dlg.role.currentData())
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()

    def _edit(self):
        i = self.current_index()
        if i < 0:
            return
        r = self.rows[i]
        dlg = UserDialog(self, self.roles, r)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            with session_scope() as s:
                svc.update_user(s, self.user, r["id"], full_name=dlg.full_name.text(),
                                role_id=dlg.role.currentData(), is_active=dlg.active.isChecked(),
                                new_password=dlg.password.text() or None)
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()

    def _open_roles(self):
        self._roles_win = RolesView(self.user)
        self._roles_win.show()
