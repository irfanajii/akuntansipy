from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDateEdit, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QLineEdit, QMessageBox,
)

from app.database.connection import session_scope
from app.services import accounts as acc_svc
from app.services import excel_io as xl
from app.services import inventory as svc
from app.services.errors import AccountingError
from app.ui import excel_actions as xl_ui
from app.ui.base import ListWindow
from app.ui.common import fmt_money, parse_money, show_error


def _date_edit():
    e = QDateEdit(QDate.currentDate())
    e.setCalendarPopup(True)
    e.setDisplayFormat("dd/MM/yyyy")
    return e


def _buttons(dlg):
    b = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    b.accepted.connect(dlg.accept)
    b.rejected.connect(dlg.reject)
    return b


def _qty(v):
    return f"{v.normalize():f}"


class ItemDialog(QDialog):
    def __init__(self, parent, data=None):
        super().__init__(parent)
        self.setWindowTitle("Ubah Barang" if data else "Barang Baru")
        self.code, self.name, self.unit, self.price = QLineEdit(), QLineEdit(), QLineEdit("pcs"), QLineEdit()
        self.is_service = QCheckBox("Jasa (tanpa stok)")
        self.is_active = QCheckBox("Aktif")
        self.is_active.setChecked(True)
        if data:
            self.code.setText(data["code"])
            self.code.setEnabled(False)
            self.name.setText(data["name"])
            self.unit.setText(data["unit"])
            self.price.setText(fmt_money(data["price"]))
            self.is_service.setChecked(data["is_service"])
            self.is_active.setChecked(data["is_active"])
        form = QFormLayout(self)
        for label, w in (("Kode", self.code), ("Nama", self.name), ("Satuan", self.unit),
                         ("Harga jual", self.price), ("", self.is_service), ("", self.is_active)):
            form.addRow(label, w)
        form.addRow(_buttons(self))
        self.setMinimumWidth(420)

    def values(self):
        return {"code": self.code.text(), "name": self.name.text(), "unit": self.unit.text(),
                "sell_price": parse_money(self.price.text()), "is_service": self.is_service.isChecked(),
                "is_active": self.is_active.isChecked()}


class AdjustDialog(QDialog):
    """Penyesuaian stok: masuk (butuh harga pokok) atau keluar."""

    def __init__(self, parent, items, warehouses, accounts, default_offset):
        super().__init__(parent)
        self.setWindowTitle("Penyesuaian Stok")
        self.item, self.wh, self.offset = QComboBox(), QComboBox(), QComboBox()
        for i in items:
            self.item.addItem(i["label"], i["id"])
        for wid, label in warehouses:
            self.wh.addItem(label, wid)
        for aid, label in accounts:
            self.offset.addItem(label, aid)
        idx = self.offset.findData(default_offset)
        if idx >= 0:
            self.offset.setCurrentIndex(idx)
        self.kind = QComboBox()
        self.kind.addItem("Stok masuk (tambah)", 1)
        self.kind.addItem("Stok keluar (kurangi)", -1)
        self.qty, self.cost, self.note = QLineEdit(), QLineEdit(), QLineEdit()
        self.date_edit = _date_edit()
        form = QFormLayout(self)
        for label, w in (("Barang", self.item), ("Gudang", self.wh), ("Tanggal", self.date_edit),
                         ("Jenis", self.kind), ("Qty", self.qty), ("Harga pokok / unit (stok masuk)", self.cost),
                         ("Akun lawan (modal untuk saldo awal)", self.offset), ("Catatan", self.note)):
            form.addRow(label, w)
        form.addRow(_buttons(self))
        self.setMinimumWidth(480)

    def values(self):
        return {"item_id": self.item.currentData(), "warehouse_id": self.wh.currentData(),
                "adj_date": self.date_edit.date().toPython(),
                "qty": parse_money(self.qty.text()) * self.kind.currentData(),
                "unit_cost": parse_money(self.cost.text()) if self.cost.text().strip() else None,
                "offset_account_id": self.offset.currentData(), "note": self.note.text()}


class TransferDialog(QDialog):
    def __init__(self, parent, items, warehouses):
        super().__init__(parent)
        self.setWindowTitle("Transfer Stok Antar Gudang")
        self.item, self.src, self.dst = QComboBox(), QComboBox(), QComboBox()
        for i in items:
            self.item.addItem(i["label"], i["id"])
        for wid, label in warehouses:
            self.src.addItem(label, wid)
            self.dst.addItem(label, wid)
        if self.dst.count() > 1:
            self.dst.setCurrentIndex(1)
        self.qty, self.note = QLineEdit(), QLineEdit()
        self.date_edit = _date_edit()
        form = QFormLayout(self)
        for label, w in (("Barang", self.item), ("Dari gudang", self.src), ("Ke gudang", self.dst),
                         ("Tanggal", self.date_edit), ("Qty", self.qty), ("Catatan", self.note)):
            form.addRow(label, w)
        form.addRow(_buttons(self))
        self.setMinimumWidth(440)

    def values(self):
        return {"item_id": self.item.currentData(), "from_warehouse_id": self.src.currentData(),
                "to_warehouse_id": self.dst.currentData(), "move_date": self.date_edit.date().toPython(),
                "qty": parse_money(self.qty.text()), "note": self.note.text()}


class OpeningDialog(QDialog):
    def __init__(self, parent, accounts, default_offset):
        super().__init__(parent)
        self.setWindowTitle("Import Saldo Awal Stok")
        self.offset = QComboBox()
        for aid, label in accounts:
            self.offset.addItem(label, aid)
        idx = self.offset.findData(default_offset)
        if idx >= 0:
            self.offset.setCurrentIndex(idx)
        self.date_edit = _date_edit()
        form = QFormLayout(self)
        form.addRow("Tanggal saldo awal", self.date_edit)
        form.addRow("Akun lawan (mis. Modal Pemilik)", self.offset)
        form.addRow(_buttons(self))
        self.setMinimumWidth(440)


class WarehouseDialog(QDialog):
    def __init__(self, parent, data=None):
        super().__init__(parent)
        self.setWindowTitle("Ubah Gudang" if data else "Gudang Baru")
        self.code, self.name = QLineEdit(), QLineEdit()
        self.active = QCheckBox("Aktif")
        self.active.setChecked(True)
        if data:
            self.code.setText(data["code"])
            self.code.setEnabled(False)
            self.name.setText(data["name"])
            self.active.setChecked(data["active"])
        form = QFormLayout(self)
        form.addRow("Kode", self.code)
        form.addRow("Nama", self.name)
        form.addRow("", self.active)
        form.addRow(_buttons(self))


class WarehousesView(ListWindow):
    def __init__(self, user):
        super().__init__("Gudang", ["Kode", "Nama", "Status"], stretch_col=1, size=(520, 360))
        self.user, self.rows = user, []
        can = user.can("inventory.edit")
        self.add_button("Gudang Baru", self._new, can)
        self.add_button("Ubah", self._edit, can)
        self.table.doubleClicked.connect(self._edit)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                self.rows = [{"id": w.id, "code": w.code, "name": w.name, "active": w.is_active}
                             for w in svc.list_warehouses(s, self.user)]
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.set_rows([[r["code"], r["name"], "Aktif" if r["active"] else "Nonaktif"] for r in self.rows])

    def _new(self):
        dlg = WarehouseDialog(self)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            with session_scope() as s:
                svc.create_warehouse(s, self.user, code=dlg.code.text(), name=dlg.name.text())
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()

    def _edit(self):
        i = self.current_index()
        if i < 0 or not self.user.can("inventory.edit"):
            return
        r = self.rows[i]
        dlg = WarehouseDialog(self, r)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            with session_scope() as s:
                svc.update_warehouse(s, self.user, r["id"], name=dlg.name.text(), is_active=dlg.active.isChecked())
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()


class ItemsView(ListWindow):
    COLUMNS = ["Kode", "Nama", "Satuan", "Harga Jual", "Jenis", "Stok", "Nilai Stok", "Status"]

    def __init__(self, user):
        super().__init__("Barang dan Persediaan", self.COLUMNS, right_cols=(3, 5, 6), stretch_col=1, size=(1100, 560))
        self.user, self.rows, self._wh_win = user, [], None
        can = user.can("inventory.edit")
        self.add_button("Barang Baru", self._new, can)
        self.add_button("Ubah", self._edit, can)
        self.add_button("Penyesuaian Stok", self._adjust, can)
        self.add_button("Transfer Stok", self._transfer, can)
        self.add_button("Gudang...", self._warehouses)
        self.add_button("Import Excel", self._import, can)
        self.add_button("Export Excel", self._export)
        self.add_button("Template", self._template)
        self.add_button("Import Saldo Awal Stok", self._import_opening, can)
        self.add_button("Muat Ulang", self.refresh)
        self.table.doubleClicked.connect(self._edit)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                self.rows = [{"id": i.id, "code": i.code, "name": i.name, "unit": i.unit, "price": i.sell_price,
                              "is_service": i.is_service, "is_active": i.is_active, "qty": i.qty_on_hand,
                              "value": i.stock_value, "version": i.version} for i in svc.list_items(s, self.user)]
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.set_rows([[r["code"], r["name"], r["unit"], fmt_money(r["price"]), "Jasa" if r["is_service"] else "Barang",
                        "" if r["is_service"] else _qty(r["qty"]), "" if r["is_service"] else fmt_money(r["value"]),
                        "Aktif" if r["is_active"] else "Nonaktif"] for r in self.rows],
                      gray={i for i, r in enumerate(self.rows) if not r["is_active"]})

    def _lookups(self):
        with session_scope() as s:
            items = [{"id": i.id, "label": f"{i.code} - {i.name}"}
                     for i in svc.list_items(s, self.user, include_inactive=False) if not i.is_service]
            whs = [(w.id, f"{w.code} - {w.name}") for w in svc.list_warehouses(s, self.user, False)]
            accs = [(a.id, f"{a.code} - {a.name}") for a in acc_svc.list_accounts(s, self.user)
                    if a.is_active and not a.is_header]
            from app.services import settings
            from app.database.models import Account
            from sqlalchemy import select
            offset_code = settings.get(s, "inventory_adjust_account")
            offset_id = s.scalar(select(Account.id).where(Account.code == offset_code))
        return items, whs, accs, offset_id

    def _new(self):
        dlg = ItemDialog(self)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            v = dlg.values()
            with session_scope() as s:
                svc.create_item(s, self.user, code=v["code"], name=v["name"], unit=v["unit"],
                                sell_price=v["sell_price"], is_service=v["is_service"])
        except (AccountingError, ValueError) as exc:
            show_error(self, exc)
        self.refresh()

    def _edit(self):
        i = self.current_index()
        if i < 0 or not self.user.can("inventory.edit"):
            return
        r = self.rows[i]
        dlg = ItemDialog(self, r)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            v = dlg.values()
            with session_scope() as s:
                svc.update_item(s, self.user, r["id"], name=v["name"], unit=v["unit"], sell_price=v["sell_price"],
                                is_service=v["is_service"], is_active=v["is_active"], expected_version=r["version"])
        except (AccountingError, ValueError) as exc:
            show_error(self, exc)
        self.refresh()

    def _adjust(self):
        try:
            items, whs, accs, offset = self._lookups()
        except AccountingError as exc:
            show_error(self, exc)
            return
        if not items:
            show_error(self, "Belum ada barang berstok.")
            return
        dlg = AdjustDialog(self, items, whs, accs, offset)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            v = dlg.values()
            with session_scope() as s:
                svc.adjust_stock(s, self.user, v["item_id"], v["warehouse_id"], v["adj_date"], v["qty"],
                                 unit_cost=v["unit_cost"], offset_account_id=v["offset_account_id"], note=v["note"])
        except (AccountingError, ValueError) as exc:
            show_error(self, exc)
        self.refresh()

    def _transfer(self):
        try:
            items, whs, _a, _o = self._lookups()
        except AccountingError as exc:
            show_error(self, exc)
            return
        if len(whs) < 2:
            show_error(self, "Transfer butuh minimal dua gudang aktif.")
            return
        dlg = TransferDialog(self, items, whs)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            v = dlg.values()
            with session_scope() as s:
                svc.transfer_stock(s, self.user, **v)
        except (AccountingError, ValueError) as exc:
            show_error(self, exc)
        self.refresh()

    def _warehouses(self):
        self._wh_win = WarehousesView(self.user)
        self._wh_win.show()

    def _export(self):
        xl_ui.export_to_file(self, "Export Barang", "barang.xlsx", lambda s, p: xl.export_items(s, self.user, p))

    def _import(self):
        xl_ui.import_from_file(self, "Import Barang dari Excel", lambda s, p: xl.import_items(s, self.user, p), "barang")
        self.refresh()

    def _template(self):
        xl_ui.save_template(self, "Simpan Template Import Barang", "template_import_barang.xlsx", xl.template_items)

    def _import_opening(self):
        try:
            _i, _w, accs, offset = self._lookups()
        except AccountingError as exc:
            show_error(self, exc)
            return
        box = QMessageBox(QMessageBox.Question, "Saldo Awal Stok",
                          "Simpan template dulu?", QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel, self)
        box.setInformativeText("Pilih Yes untuk menyimpan template, No untuk langsung memilih file import.")
        choice = box.exec()
        if choice == QMessageBox.Cancel:
            return
        if choice == QMessageBox.Yes:
            xl_ui.save_template(self, "Simpan Template Saldo Awal", "template_saldo_awal_stok.xlsx",
                                xl.template_opening_stock)
            return
        dlg = OpeningDialog(self, accs, offset)
        if dlg.exec() != QDialog.Accepted:
            return
        when, acc_id = dlg.date_edit.date().toPython(), dlg.offset.currentData()
        xl_ui.import_from_file(self, "Import Saldo Awal Stok",
                               lambda s, p: xl.import_opening_stock(s, self.user, p, when, acc_id), "baris stok")
        self.refresh()
