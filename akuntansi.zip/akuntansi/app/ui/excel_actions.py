"""Dialog bantu untuk import/export Excel (dipakai beberapa tampilan)."""
from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QDateEdit, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QMessageBox,
)

from app.database.connection import session_scope
from app.services.errors import AccountingError
from app.ui.common import show_error

XLSX = "Excel (*.xlsx)"


def ask_dates(parent, title, labels, defaults=None):
    """Mengembalikan daftar date sesuai labels, atau None jika dibatalkan."""
    dlg = QDialog(parent)
    dlg.setWindowTitle(title)
    form = QFormLayout(dlg)
    edits = []
    for i, label in enumerate(labels):
        e = QDateEdit(defaults[i] if defaults else QDate.currentDate())
        e.setCalendarPopup(True)
        e.setDisplayFormat("dd/MM/yyyy")
        form.addRow(label, e)
        edits.append(e)
    buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    buttons.accepted.connect(dlg.accept)
    buttons.rejected.connect(dlg.reject)
    form.addRow(buttons)
    if dlg.exec() != QDialog.Accepted:
        return None
    return [e.date().toPython() for e in edits]


def _ensure_xlsx(path: str) -> str:
    return path if path.lower().endswith(".xlsx") else path + ".xlsx"


def export_to_file(parent, title, default_name, func):
    """func(session, path) -> jumlah baris."""
    path, _ = QFileDialog.getSaveFileName(parent, title, default_name, XLSX)
    if not path:
        return
    path = _ensure_xlsx(path)
    try:
        with session_scope() as s:
            count = func(s, path)
    except (AccountingError, OSError) as exc:
        show_error(parent, exc)
        return
    QMessageBox.information(parent, "Export selesai", f"{count} baris diekspor ke:\n{path}")


def save_template(parent, title, default_name, func):
    """func(path) membuat file template."""
    path, _ = QFileDialog.getSaveFileName(parent, title, default_name, XLSX)
    if not path:
        return
    path = _ensure_xlsx(path)
    try:
        func(path)
    except (AccountingError, OSError) as exc:
        show_error(parent, exc)
        return
    QMessageBox.information(parent, "Template tersimpan", f"Template disimpan di:\n{path}")


def import_from_file(parent, title, func, what):
    """func(session, path) -> ImportResult. True jika berhasil mengimport."""
    path, _ = QFileDialog.getOpenFileName(parent, title, "", XLSX)
    if not path:
        return False
    try:
        with session_scope() as s:
            result = func(s, path)
    except (AccountingError, OSError) as exc:
        show_error(parent, exc)
        return False
    if result.ok:
        QMessageBox.information(parent, "Import selesai", f"{result.imported} {what} berhasil diimport.")
        return True
    box = QMessageBox(QMessageBox.Warning, "Import dibatalkan",
                      f"Ditemukan {len(result.errors)} kesalahan. TIDAK ADA data yang disimpan.\n\n"
                      + "\n".join(result.errors[:15])
                      + ("\n..." if len(result.errors) > 15 else ""), parent=parent)
    box.setDetailedText("\n".join(result.errors))
    box.exec()
    return False
