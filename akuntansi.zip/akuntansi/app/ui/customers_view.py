from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QHeaderView,
    QLineEdit, QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from app.database.connection import session_scope
from app.services import excel_io as xl
from app.services import sales as svc
from app.services.errors import AccountingError
from app.ui import excel_actions as xl_ui
from app.ui.common import show_error


class CustomerDialog(QDialog):
    def __init__(self, parent, data=None):
        super().__init__(parent)
        self.setWindowTitle("Ubah Pelanggan" if data else "Pelanggan Baru")
        self.code, self.name = QLineEdit(), QLineEdit()
        self.address, self.phone, self.email = QLineEdit(), QLineEdit(), QLineEdit()
        self.term = QSpinBox()
        self.term.setRange(0, 365)
        self.term.setValue(30)
        self.term.setSuffix(" hari")
        self.is_active = QCheckBox("Aktif")
        self.is_active.setChecked(True)
        if data:
            self.code.setText(data["code"])
            self.code.setEnabled(False)
            self.name.setText(data["name"])
            self.address.setText(data["address"])
            self.phone.setText(data["phone"])
            self.email.setText(data["email"])
            self.term.setValue(data["term_days"])
            self.is_active.setChecked(data["is_active"])
        form = QFormLayout(self)
        for label, w in (("Kode", self.code), ("Nama", self.name), ("Alamat", self.address),
                         ("Telepon", self.phone), ("Email", self.email), ("Termin", self.term),
                         ("", self.is_active)):
            form.addRow(label, w)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)
        self.setMinimumWidth(440)

    def values(self):
        return {"code": self.code.text(), "name": self.name.text(), "address": self.address.text(),
                "phone": self.phone.text(), "email": self.email.text(),
                "term_days": self.term.value(), "is_active": self.is_active.isChecked()}


class CustomersView(QWidget):
    COLUMNS = ["Kode", "Nama", "Telepon", "Termin", "Status"]

    def __init__(self, user):
        super().__init__()
        self.setWindowTitle("Pelanggan")
        self.user = user
        self.rows = []
        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.doubleClicked.connect(self._edit)

        can = user.can("customers.edit")
        bar = QHBoxLayout()
        for text, slot, needs_edit in (
                ("Pelanggan Baru", self._new, True), ("Ubah", self._edit, True),
                ("Muat Ulang", self.refresh, False), ("Import Excel", self._import, True),
                ("Export Excel", self._export, False), ("Template Import", self._template, False)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            b.setEnabled(can or not needs_edit)
            bar.addWidget(b)
        bar.addStretch()
        layout = QVBoxLayout(self)
        layout.addLayout(bar)
        layout.addWidget(self.table)
        self.resize(820, 500)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                self.rows = [
                    {"id": c.id, "code": c.code, "name": c.name, "address": c.address or "",
                     "phone": c.phone or "", "email": c.email or "", "term_days": c.term_days,
                     "is_active": c.is_active, "version": c.version}
                    for c in svc.list_customers(s, self.user)]
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.table.setRowCount(len(self.rows))
        for i, r in enumerate(self.rows):
            for c, text in enumerate([r["code"], r["name"], r["phone"], f'{r["term_days"]} hari',
                                      "Aktif" if r["is_active"] else "Nonaktif"]):
                self.table.setItem(i, c, QTableWidgetItem(text))

    def _new(self):
        dlg = CustomerDialog(self)
        if dlg.exec() != QDialog.Accepted:
            return
        v = dlg.values()
        try:
            with session_scope() as s:
                svc.create_customer(s, self.user, code=v["code"], name=v["name"], address=v["address"],
                                    phone=v["phone"], email=v["email"], term_days=v["term_days"])
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()

    def _edit(self):
        row = self.table.currentRow()
        if row < 0 or not self.user.can("customers.edit"):
            return
        data = self.rows[row]
        dlg = CustomerDialog(self, data)
        if dlg.exec() != QDialog.Accepted:
            return
        v = dlg.values()
        try:
            with session_scope() as s:
                svc.update_customer(s, self.user, data["id"], name=v["name"], address=v["address"],
                                    phone=v["phone"], email=v["email"], term_days=v["term_days"],
                                    is_active=v["is_active"], expected_version=data["version"])
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()

    def _export(self):
        xl_ui.export_to_file(self, "Export Pelanggan", "pelanggan.xlsx",
                             lambda s, p: xl.export_customers(s, self.user, p))

    def _import(self):
        xl_ui.import_from_file(self, "Import Pelanggan dari Excel",
                               lambda s, p: xl.import_customers(s, self.user, p), "pelanggan")
        self.refresh()

    def _template(self):
        xl_ui.save_template(self, "Simpan Template Import Pelanggan",
                            "template_import_pelanggan.xlsx", xl.template_customers)
