from app.database.connection import session_scope
from app.services import users as svc
from app.services.errors import AccountingError
from app.ui.base import ListWindow
from app.ui.common import show_error


class AuditView(ListWindow):
    def __init__(self, user):
        super().__init__("Log Audit", ["Waktu", "User", "Aksi", "Objek", "ID", "Keterangan"],
                         stretch_col=5, size=(1000, 560))
        self.user = user
        self.add_button("Muat Ulang", self.refresh)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                rows = svc.list_audit(s, self.user, limit=500)
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.set_rows([[r["time"].strftime("%d/%m/%Y %H:%M:%S") if r["time"] else "", r["user"], r["action"],
                        r["entity"], r["entity_id"], r["detail"]] for r in rows])
