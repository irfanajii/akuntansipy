from PySide6.QtCore import QDate
from PySide6.QtWidgets import QDateEdit, QDialog, QDialogButtonBox, QFormLayout, QLineEdit, QMessageBox

from app.database.connection import session_scope
from app.services import periods as svc
from app.services.errors import AccountingError
from app.ui.base import ListWindow
from app.ui.common import show_error


class PeriodsView(ListWindow):
    def __init__(self, user):
        super().__init__("Periode Akuntansi", ["Nama", "Mulai", "Sampai", "Status", "Jurnal Penutup"],
                         stretch_col=0, size=(780, 420))
        self.user, self.rows = user, []
        can = user.can("periods.close")
        self.add_button("Periode Baru", self._new, can)
        self.add_button("Tutup Periode", lambda: self._close(False), can)
        self.add_button("Tutup Buku (dengan jurnal penutup)", lambda: self._close(True), can)
        self.add_button("Buka Kembali", self._reopen, can)
        self.add_button("Muat Ulang", self.refresh)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                self.rows = svc.list_periods(s, self.user)
        except AccountingError as exc:
            show_error(self, exc)
            return
        self.set_rows([[r["name"], r["start"].strftime("%d/%m/%Y"), r["end"].strftime("%d/%m/%Y"),
                        "Ditutup" if r["closed"] else "Terbuka", "Ada" if r["has_closing"] else "-"]
                       for r in self.rows])

    def _new(self):
        dlg = QDialog(self)
        dlg.setWindowTitle("Periode Baru")
        name = QLineEdit()
        start, end = QDateEdit(QDate.currentDate()), QDateEdit(QDate.currentDate())
        for e in (start, end):
            e.setCalendarPopup(True)
            e.setDisplayFormat("dd/MM/yyyy")
        form = QFormLayout(dlg)
        form.addRow("Nama", name)
        form.addRow("Mulai", start)
        form.addRow("Sampai", end)
        b = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        b.accepted.connect(dlg.accept)
        b.rejected.connect(dlg.reject)
        form.addRow(b)
        if dlg.exec() != QDialog.Accepted:
            return
        try:
            with session_scope() as s:
                svc.create_period(s, self.user, name.text(), start.date().toPython(), end.date().toPython())
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()

    def _selected(self):
        i = self.current_index()
        return self.rows[i] if i >= 0 else None

    def _close(self, with_closing):
        r = self._selected()
        if not r:
            return
        text = (f"Tutup periode '{r['name']}'? Setelah ditutup tidak ada transaksi yang bisa disimpan pada periode ini.")
        if with_closing:
            text += "\nJurnal penutup akan dibuat: saldo pendapatan dan beban dipindahkan ke Laba Ditahan."
        if QMessageBox.question(self, "Konfirmasi", text) != QMessageBox.Yes:
            return
        try:
            with session_scope() as s:
                svc.close_period(s, self.user, r["id"], post_closing=with_closing)
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()

    def _reopen(self):
        r = self._selected()
        if not r:
            return
        if QMessageBox.question(self, "Konfirmasi", f"Buka kembali periode '{r['name']}'?") != QMessageBox.Yes:
            return
        try:
            with session_scope() as s:
                svc.reopen_period(s, self.user, r["id"])
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()
