"""Pengaturan koneksi dan pembuatan database saat pertama kali dijalankan."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel,
    QLineEdit, QMessageBox, QPushButton, QSpinBox, QVBoxLayout,
)

from app.config import DBConfig, config_path, load_config, save_config
from app.database.connection import get_engine, init_engine, make_engine
from app.database.setup import check_connection, initialize_database, schema_status
from app.services.errors import AccountingError


class ConnectionDialog(QDialog):
    def __init__(self, parent=None, cfg: DBConfig = None, first_run=False):
        super().__init__(parent)
        self.setWindowTitle("Pengaturan Koneksi Database")
        cfg = cfg or DBConfig()
        self.saved_cfg = None
        self.driver = QComboBox()
        self.driver.addItem("MariaDB / MySQL (beberapa komputer di jaringan)", "mysql")
        self.driver.addItem("SQLite (satu komputer / uji coba)", "sqlite")
        self.driver.setCurrentIndex(1 if cfg.driver == "sqlite" else 0)
        self.host, self.name, self.user = QLineEdit(cfg.host), QLineEdit(cfg.name), QLineEdit(cfg.user)
        self.port = QSpinBox()
        self.port.setRange(1, 65535)
        self.port.setValue(cfg.port)
        self.password = QLineEdit(cfg.password)
        self.password.setEchoMode(QLineEdit.Password)
        self.sqlite_path = QLineEdit(cfg.sqlite_path)
        browse = QPushButton("Pilih...")
        browse.clicked.connect(self._browse)
        sqlite_row = QHBoxLayout()
        sqlite_row.addWidget(self.sqlite_path)
        sqlite_row.addWidget(browse)

        self.form = QFormLayout()
        self.form.addRow("Jenis database", self.driver)
        self.form.addRow("Alamat server (IP / nama komputer)", self.host)
        self.form.addRow("Port", self.port)
        self.form.addRow("Nama database", self.name)
        self.form.addRow("User database", self.user)
        self.form.addRow("Password database", self.password)
        self.form.addRow("File SQLite", sqlite_row)

        intro = ("Selamat datang. Isi alamat server database (komputer yang menjalankan MariaDB/MySQL)."
                 if first_run else "Ubah alamat server database.")
        btn_test, btn_save = QPushButton("Tes Koneksi"), QPushButton("Simpan")
        btn_cancel = QPushButton("Batal")
        btn_test.clicked.connect(self._test)
        btn_save.clicked.connect(self._save)
        btn_cancel.clicked.connect(self.reject)
        bar = QHBoxLayout()
        bar.addWidget(btn_test)
        bar.addStretch()
        bar.addWidget(btn_save)
        bar.addWidget(btn_cancel)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(intro))
        layout.addLayout(self.form)
        layout.addWidget(QLabel(f"Disimpan di: {config_path()}"))
        layout.addLayout(bar)
        self.driver.currentIndexChanged.connect(self._sync)
        self._sync()
        self.setMinimumWidth(520)

    def _sync(self):
        sqlite = self.driver.currentData() == "sqlite"
        for row in (1, 2, 3, 4, 5):
            self.form.itemAt(row, QFormLayout.LabelRole).widget().setVisible(not sqlite)
            self.form.itemAt(row, QFormLayout.FieldRole).widget().setVisible(not sqlite)
        self.form.itemAt(6, QFormLayout.LabelRole).widget().setVisible(sqlite)
        self.form.itemAt(6, QFormLayout.FieldRole).layout().itemAt(0).widget().setVisible(sqlite)
        self.form.itemAt(6, QFormLayout.FieldRole).layout().itemAt(1).widget().setVisible(sqlite)

    def _browse(self):
        path, _ = QFileDialog.getSaveFileName(self, "File database SQLite", self.sqlite_path.text(),
                                              "SQLite (*.db);;Semua file (*)")
        if path:
            self.sqlite_path.setText(path)

    def _cfg(self) -> DBConfig:
        base = DBConfig()
        try:
            base = load_config()  # pertahankan pengaturan backup yang sudah ada
        except Exception:
            pass
        base.driver = self.driver.currentData()
        base.host, base.port = self.host.text().strip(), self.port.value()
        base.name, base.user, base.password = self.name.text().strip(), self.user.text().strip(), self.password.text()
        base.sqlite_path = self.sqlite_path.text().strip() or "akuntansi.db"
        return base

    def _test(self):
        cfg = self._cfg()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            engine = make_engine(cfg)
            try:
                check_connection(engine)
            finally:
                engine.dispose()
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Koneksi gagal", f"{exc}\n\nPeriksa alamat server, port, user, password, "
                                 "dan firewall di komputer server.")
            return
        QApplication.restoreOverrideCursor()
        QMessageBox.information(self, "Koneksi berhasil", "Aplikasi dapat terhubung ke database.")

    def _save(self):
        cfg = self._cfg()
        if cfg.driver != "sqlite" and not (cfg.host and cfg.name and cfg.user):
            QMessageBox.warning(self, "Perhatian", "Alamat server, nama database, dan user wajib diisi.")
            return
        try:
            save_config(cfg)
        except OSError as exc:
            QMessageBox.critical(self, "Gagal menyimpan", str(exc))
            return
        self.saved_cfg = cfg
        self.accept()


class InitDbDialog(QDialog):
    """Membuat tabel dan data awal; meminta password admin bila belum ada."""

    def __init__(self, parent=None, need_admin=True):
        super().__init__(parent)
        self.setWindowTitle("Siapkan Database")
        self.need_admin = need_admin
        self.pw, self.pw2 = QLineEdit(), QLineEdit()
        for w in (self.pw, self.pw2):
            w.setEchoMode(QLineEdit.Password)
        form = QFormLayout()
        if need_admin:
            form.addRow("Password untuk user 'admin' (min. 8 karakter)", self.pw)
            form.addRow("Ulangi password", self.pw2)
        text = ("Database masih kosong. Aplikasi akan membuat tabel, daftar akun contoh, dan user 'admin'."
                if need_admin else "Database akan diperbarui ke versi aplikasi ini.")
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._run)
        buttons.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(text))
        layout.addLayout(form)
        layout.addWidget(buttons)
        self.setMinimumWidth(460)

    def _run(self):
        if self.need_admin and self.pw.text() != self.pw2.text():
            QMessageBox.warning(self, "Perhatian", "Konfirmasi password tidak sama.")
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            initialize_database(self.pw.text() if self.need_admin else None)
        except AccountingError as exc:
            QApplication.restoreOverrideCursor()
            QMessageBox.warning(self, "Perhatian", str(exc))
            return
        except Exception as exc:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Gagal menyiapkan database",
                                 f"{exc}\n\nPastikan user database memiliki hak CREATE dan ALTER.")
            return
        QApplication.restoreOverrideCursor()
        self.accept()


def prepare_database():
    """Memastikan konfigurasi, koneksi, dan skema database siap. Mengembalikan DBConfig, atau None bila dibatalkan."""
    cfg = None
    while True:
        try:
            cfg = load_config()
            engine = init_engine(cfg)
            check_connection(engine)
            break
        except FileNotFoundError:
            dlg = ConnectionDialog(None, None, first_run=True)
        except Exception as exc:
            box = QMessageBox(QMessageBox.Critical, "Tidak dapat terhubung ke database", str(exc))
            box.setInformativeText("Buka Pengaturan Koneksi untuk memperbaiki alamat server, atau keluar.")
            fix = box.addButton("Pengaturan Koneksi...", QMessageBox.AcceptRole)
            box.addButton("Keluar", QMessageBox.RejectRole)
            box.exec()
            if box.clickedButton() is not fix:
                return None
            dlg = ConnectionDialog(None, cfg)
        if dlg.exec() != QDialog.Accepted:
            return None

    try:
        missing_tables, missing_columns = schema_status(get_engine())
    except Exception as exc:
        QMessageBox.critical(None, "Gagal memeriksa database", str(exc))
        return None
    if "users" in missing_tables:
        return cfg if InitDbDialog(None, need_admin=True).exec() == QDialog.Accepted else None
    if missing_tables or missing_columns:
        answer = QMessageBox.question(
            None, "Database perlu diperbarui",
            "Struktur database lebih lama daripada versi aplikasi ini.\n"
            "Pastikan pengguna lain sudah menutup aplikasi, lalu perbarui sekarang?")
        if answer != QMessageBox.Yes:
            return None
        return cfg if InitDbDialog(None, need_admin=False).exec() == QDialog.Accepted else None
    return cfg
