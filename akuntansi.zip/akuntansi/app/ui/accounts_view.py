from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout,
    QHBoxLayout, QHeaderView, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from app.database.connection import session_scope
from app.services import excel_io as xl
from app.ui import excel_actions as xl_ui
from app.services import accounts as svc
from app.services.errors import AccountingError
from app.ui.common import show_error

TYPE_LABELS = {
    "ASSET": "Aset", "LIABILITY": "Kewajiban", "EQUITY": "Modal",
    "REVENUE": "Pendapatan", "EXPENSE": "Beban",
}


class AccountDialog(QDialog):
    def __init__(self, parent, parents, data=None):
        super().__init__(parent)
        self.setWindowTitle("Ubah Akun" if data else "Akun Baru")
        self.code = QLineEdit()
        self.name = QLineEdit()
        self.type = QComboBox()
        for key, label in TYPE_LABELS.items():
            self.type.addItem(label, key)
        self.parent_cb = QComboBox()
        self.parent_cb.addItem("(tanpa induk)", None)
        for pid, label in parents:
            self.parent_cb.addItem(label, pid)
        self.is_header = QCheckBox("Akun induk / header (tidak dipakai langsung di jurnal)")
        self.is_active = QCheckBox("Aktif")
        self.is_active.setChecked(True)

        if data:
            self.code.setText(data["code"])
            self.code.setEnabled(False)  # kode tidak diubah setelah dibuat
            self.name.setText(data["name"])
            self.type.setCurrentIndex(self.type.findData(data["type"]))
            if data["parent_id"] is not None:
                self.parent_cb.setCurrentIndex(self.parent_cb.findData(data["parent_id"]))
            self.is_header.setChecked(data["is_header"])
            self.is_active.setChecked(data["is_active"])

        form = QFormLayout(self)
        form.addRow("Kode", self.code)
        form.addRow("Nama", self.name)
        form.addRow("Tipe", self.type)
        form.addRow("Induk", self.parent_cb)
        form.addRow("", self.is_header)
        form.addRow("", self.is_active)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)
        self.setMinimumWidth(420)

    def values(self):
        return {
            "code": self.code.text(),
            "name": self.name.text(),
            "type": self.type.currentData(),
            "parent_id": self.parent_cb.currentData(),
            "is_header": self.is_header.isChecked(),
            "is_active": self.is_active.isChecked(),
        }


class AccountsView(QWidget):
    COLUMNS = ["Kode", "Nama Akun", "Tipe", "Saldo Normal", "Status"]

    def __init__(self, user):
        super().__init__()
        self.setWindowTitle("Daftar Akun")
        self.user = user
        self.rows = []

        self.table = QTableWidget(0, len(self.COLUMNS))
        self.table.setHorizontalHeaderLabels(self.COLUMNS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.doubleClicked.connect(self._edit)

        btn_new = QPushButton("Akun Baru")
        btn_edit = QPushButton("Ubah")
        btn_refresh = QPushButton("Muat Ulang")
        btn_new.clicked.connect(self._new)
        btn_edit.clicked.connect(self._edit)
        btn_refresh.clicked.connect(self.refresh)
        can_edit = user.can("accounts.edit")
        btn_new.setEnabled(can_edit)
        btn_edit.setEnabled(can_edit)
        btn_import = QPushButton("Import Excel")
        btn_export = QPushButton("Export Excel")
        btn_template = QPushButton("Template Import")
        btn_import.clicked.connect(self._import)
        btn_export.clicked.connect(self._export)
        btn_template.clicked.connect(self._template)
        btn_import.setEnabled(can_edit)

        bar = QHBoxLayout()
        for b in (btn_new, btn_edit, btn_refresh, btn_import, btn_export, btn_template):
            bar.addWidget(b)
        bar.addStretch()
        layout = QVBoxLayout(self)
        layout.addLayout(bar)
        layout.addWidget(self.table)
        self.resize(760, 520)
        self.refresh()

    def refresh(self):
        try:
            with session_scope() as s:
                accs = svc.list_accounts(s, self.user)
                self.rows = [
                    {"id": a.id, "code": a.code, "name": a.name, "type": a.type,
                     "normal": a.normal_balance, "parent_id": a.parent_id,
                     "is_header": a.is_header, "is_active": a.is_active, "version": a.version}
                    for a in accs
                ]
        except AccountingError as exc:
            show_error(self, exc)
            return
        by_id = {r["id"]: r for r in self.rows}
        self.table.setRowCount(len(self.rows))
        for i, r in enumerate(self.rows):
            level, cur = 0, r
            while cur["parent_id"] in by_id:
                level += 1
                cur = by_id[cur["parent_id"]]
            values = [
                r["code"], "    " * level + r["name"], TYPE_LABELS[r["type"]],
                "Debit" if r["normal"] == "D" else "Kredit",
                "Aktif" if r["is_active"] else "Nonaktif",
            ]
            for c, text in enumerate(values):
                item = QTableWidgetItem(text)
                if r["is_header"]:
                    f = QFont()
                    f.setBold(True)
                    item.setFont(f)
                if not r["is_active"]:
                    item.setForeground(Qt.gray)
                self.table.setItem(i, c, item)

    def _parents(self, exclude_id=None):
        return [(r["id"], f'{r["code"]} - {r["name"]}')
                for r in self.rows if r["is_header"] and r["id"] != exclude_id]

    def _new(self):
        dlg = AccountDialog(self, self._parents())
        if dlg.exec() != QDialog.Accepted:
            return
        v = dlg.values()
        try:
            with session_scope() as s:
                svc.create_account(s, self.user, code=v["code"], name=v["name"], type=v["type"],
                                   parent_id=v["parent_id"], is_header=v["is_header"])
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()

    def _edit(self):
        row = self.table.currentRow()
        if row < 0 or not self.user.can("accounts.edit"):
            return
        data = self.rows[row]
        dlg = AccountDialog(self, self._parents(exclude_id=data["id"]), data)
        if dlg.exec() != QDialog.Accepted:
            return
        v = dlg.values()
        try:
            with session_scope() as s:
                svc.update_account(
                    s, self.user, data["id"], name=v["name"], type=v["type"],
                    parent_id=v["parent_id"], is_header=v["is_header"],
                    is_active=v["is_active"], expected_version=data["version"],
                )
        except AccountingError as exc:
            show_error(self, exc)
        self.refresh()

    def _export(self):
        xl_ui.export_to_file(self, "Export Daftar Akun", "daftar_akun.xlsx",
                             lambda s, p: xl.export_accounts(s, self.user, p))

    def _import(self):
        xl_ui.import_from_file(self, "Import Daftar Akun dari Excel",
                               lambda s, p: xl.import_accounts(s, self.user, p), "akun")
        self.refresh()

    def _template(self):
        xl_ui.save_template(self, "Simpan Template Import Akun",
                            "template_import_akun.xlsx", xl.template_accounts)
