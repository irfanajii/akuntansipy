from PySide6.QtWidgets import (
    QComboBox, QDialog, QDialogButtonBox, QFormLayout, QLabel, QLineEdit, QMessageBox, QScrollArea, QVBoxLayout, QWidget,
)

from app.database.connection import session_scope
from app.services import accounts as acc_svc
from app.services import settings as svc
from app.services.errors import AccountingError
from app.ui.common import show_error

ACCOUNT_KEYS = (
    ("receivable_account", "Piutang Usaha"),
    ("sales_account", "Penjualan (default faktur)"),
    ("sales_return_account", "Retur Penjualan"),
    ("tax_payable_account", "Pajak Keluaran"),
    ("payable_account", "Hutang Usaha"),
    ("purchase_tax_account", "Pajak Masukan"),
    ("inventory_account", "Persediaan Barang"),
    ("cogs_account", "Harga Pokok Penjualan"),
    ("inventory_adjust_account", "Selisih Persediaan"),
    ("fixed_asset_account", "Aset Tetap (default aset baru)"),
    ("accum_depreciation_account", "Akumulasi Penyusutan (default)"),
    ("depreciation_expense_account", "Beban Penyusutan (default)"),
    ("disposal_gain_loss_account", "Laba/Rugi Pelepasan Aset"),
    ("retained_earnings_account", "Laba Ditahan (jurnal penutup)"),
)
CODE_LIST_KEYS = (
    ("cash_parent", "Header Kas & Bank (kode)"),
    ("investing_parents", "Header aset tetap / investasi (kode)"),
    ("financing_parents", "Header pendanaan (kode, pisahkan koma)"),
    ("cogs_parents", "Akun / header HPP untuk laba rugi (kode, pisahkan koma)"),
)


class SettingsDialog(QDialog):
    def __init__(self, parent, user):
        super().__init__(parent)
        self.user = user
        self.setWindowTitle("Pengaturan Perusahaan dan Akun")
        self.widgets = {}
        try:
            with session_scope() as s:
                current = svc.get_all(s)
                accounts = [(a.code, f"{a.code} - {a.name}") for a in acc_svc.list_accounts(s, user)
                            if not a.is_header and a.is_active]
        except AccountingError as exc:
            show_error(self, exc)
            current, accounts = svc.DEFAULTS, []

        inner = QWidget()
        form = QFormLayout(inner)
        for key, label in (("company_name", "Nama perusahaan"), ("company_address", "Alamat"),
                           ("company_phone", "Telepon")):
            w = QLineEdit(current[key])
            self.widgets[key] = w
            form.addRow(label, w)
        form.addRow(QLabel("<b>Akun otomatis modul</b>"))
        for key, label in ACCOUNT_KEYS:
            cb = QComboBox()
            for code, text in accounts:
                cb.addItem(text, code)
            idx = cb.findData(current[key])
            if idx < 0:
                cb.addItem(f"{current[key]} (tidak ditemukan)", current[key])
                idx = cb.count() - 1
            cb.setCurrentIndex(idx)
            self.widgets[key] = cb
            form.addRow(label, cb)
        w = QLineEdit(current["default_tax_rate"])
        self.widgets["default_tax_rate"] = w
        form.addRow("Tarif pajak default faktur (%)", w)
        form.addRow(QLabel("<b>Pengaturan laporan arus kas dan laba rugi</b>"))
        for key, label in CODE_LIST_KEYS:
            w = QLineEdit(current[key])
            self.widgets[key] = w
            form.addRow(label, w)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(inner)
        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)
        layout = QVBoxLayout(self)
        layout.addWidget(scroll)
        layout.addWidget(buttons)
        self.resize(640, 640)

    def _save(self):
        values = {}
        for key, w in self.widgets.items():
            values[key] = w.currentData() if isinstance(w, QComboBox) else w.text()
        try:
            with session_scope() as s:
                svc.save_many(s, self.user, values)
        except AccountingError as exc:
            show_error(self, exc)
            return
        QMessageBox.information(self, "Tersimpan", "Pengaturan disimpan.")
        self.accept()
