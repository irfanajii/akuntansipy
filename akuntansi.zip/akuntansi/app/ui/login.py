from PySide6.QtWidgets import (
    QDialog, QFormLayout, QLabel, QLineEdit, QMessageBox, QPushButton, QVBoxLayout,
)

from app.config import DBConfig
from app.database.connection import session_scope
from app.services.auth import authenticate


class LoginDialog(QDialog):
    def __init__(self, server_label: str, cfg: DBConfig = None):
        super().__init__()
        self.cfg = cfg
        self.setWindowTitle("Login - Aplikasi Akuntansi")
        self.user = None

        self.username = QLineEdit()
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)

        form = QFormLayout()
        form.addRow("Username", self.username)
        form.addRow("Password", self.password)

        btn = QPushButton("Masuk")
        btn.setDefault(True)
        btn.clicked.connect(self._login)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(f"Server: {server_label}"))
        layout.addLayout(form)
        layout.addWidget(btn)
        btn_conn = QPushButton("Pengaturan Koneksi...")
        btn_conn.clicked.connect(self._connection_settings)
        layout.addWidget(btn_conn)
        self.setMinimumWidth(340)

    def _connection_settings(self):
        from app.ui.setup_wizard import ConnectionDialog
        dlg = ConnectionDialog(self, self.cfg)
        if dlg.exec() == QDialog.Accepted:
            QMessageBox.information(self, "Tersimpan",
                                    "Pengaturan koneksi disimpan. Aplikasi akan ditutup; buka kembali untuk memakainya.")
            self.reject()

    def _login(self):
        try:
            with session_scope() as s:
                user = authenticate(s, self.username.text(), self.password.text())
        except Exception as exc:  # koneksi gagal, tabel belum dibuat, dll
            QMessageBox.critical(self, "Gagal terhubung ke database", str(exc))
            return
        if user is None:
            QMessageBox.warning(self, "Login gagal", "Username atau password salah.")
            self.password.clear()
            self.password.setFocus()
            return
        self.user = user
        self.accept()
