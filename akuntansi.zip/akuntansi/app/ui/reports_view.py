from PySide6.QtCore import QDate, Qt
from PySide6.QtGui import QBrush, QColor, QFont
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDateEdit, QFileDialog, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from app.database.connection import session_scope
from app.reports.export import render_report_xlsx
from app.reports.pdf import render_report_pdf
from app.services import accounts as acc_svc
from app.services import inventory, reports, reports_ext
from app.services.errors import AccountingError
from app.ui.common import open_file, show_error

# kunci: (judul, perlu tanggal awal, perlu akun, perlu barang)
REPORTS = {
    "trial_balance": ("Neraca Saldo", False, False, False),
    "ledger": ("Buku Besar", True, True, False),
    "income": ("Laba Rugi", True, False, False),
    "balance": ("Neraca", False, False, False),
    "cashflow": ("Arus Kas", True, False, False),
    "aging": ("Umur Piutang", False, False, False),
    "aging_ap": ("Umur Hutang", False, False, False),
    "sales": ("Laporan Penjualan", True, False, False),
    "purchase": ("Laporan Pembelian", True, False, False),
    "stockcard": ("Kartu Stok", True, False, True),
    "valuation": ("Nilai Persediaan", False, False, False),
    "assets": ("Daftar Aset Tetap", False, False, False),
    "tax": ("Rekap Pajak", True, False, False),
}


class ReportsView(QWidget):
    def __init__(self, user):
        super().__init__()
        self.setWindowTitle("Laporan Keuangan")
        self.user, self.spec = user, None

        self.combo = QComboBox()
        for key, (title, _f, _a, _i) in REPORTS.items():
            self.combo.addItem(title, key)
        today = QDate.currentDate()
        self.date_from = self._date(QDate(today.year(), 1, 1))
        self.date_to = self._date(today)
        self.account = QComboBox()
        try:
            with session_scope() as s:
                for a in acc_svc.list_accounts(s, user):
                    if not a.is_header:
                        self.account.addItem(f"{a.code} - {a.name}", a.id)
        except AccountingError:
            pass
        self.item = QComboBox()
        try:
            with session_scope() as s:
                for it in inventory.list_items(s, user):
                    if not it.is_service:
                        self.item.addItem(f"{it.code} - {it.name}", it.id)
        except AccountingError:
            pass

        btn_show, btn_pdf, btn_xlsx = QPushButton("Tampilkan"), QPushButton("Cetak PDF"), QPushButton("Export Excel")
        btn_show.clicked.connect(self._show)
        btn_pdf.clicked.connect(self._pdf)
        btn_xlsx.clicked.connect(self._xlsx)

        bar = QHBoxLayout()
        for text, w in (("Laporan", self.combo), ("Dari", self.date_from), ("Sampai / per", self.date_to),
                        ("Akun", self.account), ("Barang", self.item)):
            bar.addWidget(QLabel(text))
            bar.addWidget(w)
        for b in (btn_show, btn_pdf, btn_xlsx):
            bar.addWidget(b)
        bar.addStretch()

        self.heading = QLabel()
        self.table = QTableWidget(0, 0)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.notes = QLabel()
        self.notes.setWordWrap(True)
        layout = QVBoxLayout(self)
        layout.addLayout(bar)
        layout.addWidget(self.heading)
        layout.addWidget(self.table)
        layout.addWidget(self.notes)
        self.combo.currentIndexChanged.connect(self._sync_controls)
        self._sync_controls()
        self.resize(1000, 640)

    @staticmethod
    def _date(qdate):
        e = QDateEdit(qdate)
        e.setCalendarPopup(True)
        e.setDisplayFormat("dd/MM/yyyy")
        return e

    def _sync_controls(self):
        _t, need_from, need_acc, need_item = REPORTS[self.combo.currentData()]
        self.date_from.setEnabled(need_from)
        self.account.setEnabled(need_acc)
        self.item.setEnabled(need_item)

    def _build(self, s):
        key = self.combo.currentData()
        d_from, d_to = self.date_from.date().toPython(), self.date_to.date().toPython()
        if key == "trial_balance":
            return reports.trial_balance_report(s, self.user, d_to)
        if key == "ledger":
            if self.account.currentData() is None:
                raise AccountingError("Pilih akun untuk buku besar.")
            return reports.general_ledger(s, self.user, self.account.currentData(), d_from, d_to)
        if key == "income":
            return reports.income_statement(s, self.user, d_from, d_to)
        if key == "balance":
            return reports.balance_sheet(s, self.user, d_to)
        if key == "cashflow":
            return reports.cash_flow(s, self.user, d_from, d_to)
        if key == "aging":
            return reports.receivable_aging(s, self.user, d_to)
        if key == "aging_ap":
            return reports.payable_aging(s, self.user, d_to)
        if key == "purchase":
            return reports.purchase_report(s, self.user, d_from, d_to)
        if key == "stockcard":
            if self.item.currentData() is None:
                raise AccountingError("Pilih barang untuk kartu stok.")
            return reports_ext.stock_card(s, self.user, self.item.currentData(), d_from, d_to)
        if key == "valuation":
            return reports_ext.stock_valuation(s, self.user, d_to)
        if key == "assets":
            return reports_ext.asset_register(s, self.user, d_to)
        if key == "tax":
            return reports_ext.tax_summary(s, self.user, d_from, d_to)
        return reports.sales_report(s, self.user, d_from, d_to)

    def _show(self):
        try:
            with session_scope() as s:
                self.spec = self._build(s)
        except AccountingError as exc:
            show_error(self, exc)
            return
        spec = self.spec
        self.heading.setText(f"<b>{spec.company}</b><br><b>{spec.title}</b><br>{spec.subtitle}")
        self.table.clear()
        self.table.setColumnCount(len(spec.columns))
        self.table.setHorizontalHeaderLabels([c.title for c in spec.columns])
        self.table.setRowCount(len(spec.rows))
        first_text = next((i for i, c in enumerate(spec.columns) if c.kind == "text" and i > 0), 0)
        for r, row in enumerate(spec.rows):
            for c, col in enumerate(spec.columns):
                text = spec.cell_text(row, c)
                if c == first_text:
                    text = "    " * row.indent + text
                item = QTableWidgetItem(text)
                if col.kind in ("money", "number", "qty"):
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                if row.style != "normal":
                    f = QFont()
                    f.setBold(True)
                    item.setFont(f)
                if row.style in ("section", "total"):
                    item.setBackground(QBrush(QColor("#EDEDED")))
                self.table.setItem(r, c, item)
        for c, col in enumerate(spec.columns):
            self.table.setColumnWidth(c, int(60 * col.width) + 40)
        self.notes.setText("\n".join(spec.notes))

    def _ensure_spec(self):
        if self.spec is None:
            show_error(self, "Tampilkan laporan terlebih dahulu.")
            return False
        return True

    def _pdf(self):
        if not self._ensure_spec():
            return
        name = self.spec.title.replace(" ", "_").replace("/", "-") + ".pdf"
        path, _ = QFileDialog.getSaveFileName(self, "Simpan PDF", name, "PDF (*.pdf)")
        if not path:
            return
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        try:
            render_report_pdf(self.spec, path)
        except OSError as exc:
            show_error(self, exc)
            return
        open_file(path)

    def _xlsx(self):
        if not self._ensure_spec():
            return
        name = self.spec.title.replace(" ", "_").replace("/", "-") + ".xlsx"
        path, _ = QFileDialog.getSaveFileName(self, "Export Excel", name, "Excel (*.xlsx)")
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        try:
            render_report_xlsx(self.spec, path)
        except OSError as exc:
            show_error(self, exc)
            return
        open_file(path)
