"""Dialog akun pengguna dan backup."""
from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QLineEdit, QMessageBox,
)

from app.database.connection import session_scope
from app.services import users as users_svc
from app.services.backup import backup_with_permission
from app.services.errors import AccountingError
from app.ui.common import open_file, show_error


class ChangePasswordDialog(QDialog):
    def __init__(self, parent, user):
        super().__init__(parent)
        self.user = user
        self.setWindowTitle("Ganti Password")
        self.old, self.new, self.confirm = QLineEdit(), QLineEdit(), QLineEdit()
        for w in (self.old, self.new, self.confirm):
            w.setEchoMode(QLineEdit.Password)
        form = QFormLayout(self)
        form.addRow("Password lama", self.old)
        form.addRow("Password baru (min. 8 karakter)", self.new)
        form.addRow("Ulangi password baru", self.confirm)
        b = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        b.accepted.connect(self._save)
        b.rejected.connect(self.reject)
        form.addRow(b)
        self.setMinimumWidth(400)

    def _save(self):
        if self.new.text() != self.confirm.text():
            show_error(self, "Konfirmasi password baru tidak sama.")
            return
        try:
            with session_scope() as s:
                users_svc.change_password(s, self.user, self.old.text(), self.new.text())
        except AccountingError as exc:
            show_error(self, exc)
            return
        QMessageBox.information(self, "Berhasil", "Password berhasil diganti.")
        self.accept()


def run_backup_dialog(parent, user, cfg):
    if cfg is None:
        show_error(parent, "Konfigurasi database tidak tersedia.")
        return
    folder = QFileDialog.getExistingDirectory(parent, "Pilih folder tujuan backup")
    if not folder:
        return
    try:
        path = backup_with_permission(user, cfg, folder)
    except (AccountingError, OSError) as exc:
        show_error(parent, exc, "Backup gagal")
        return
    QMessageBox.information(parent, "Backup selesai", f"Backup tersimpan di:\n{path}")
