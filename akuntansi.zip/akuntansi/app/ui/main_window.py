from PySide6.QtGui import QAction
from PySide6.QtWidgets import QMainWindow, QMdiArea, QMessageBox

from app.version import APP_NAME, __version__
from app.ui.account_dialogs import ChangePasswordDialog, run_backup_dialog
from app.ui.accounts_view import AccountsView
from app.ui.assets_view import AssetsView
from app.ui.audit_view import AuditView
from app.ui.common import show_error
from app.ui.customers_view import CustomersView
from app.ui.items_view import ItemsView
from app.ui.journal_view import JournalsView
from app.ui.periods_view import PeriodsView
from app.ui.reports_view import ReportsView
from app.ui.settings_dialog import SettingsDialog
from app.ui.suppliers_view import SuppliersView
from app.ui.trade_views import (
    PurchaseInvoicesView, PurchaseReturnsView, PurchaseSettlementsView, SalesInvoicesView, SalesReturnsView,
    SalesSettlementsView,
)
from app.ui.users_view import UsersView


class MainWindow(QMainWindow):
    def __init__(self, user, cfg=None):
        super().__init__()
        self.user, self.cfg = user, cfg
        self.setWindowTitle(f"Aplikasi Akuntansi - {user.full_name} ({user.role})")
        self.resize(1280, 800)
        self.mdi = QMdiArea()
        self.setCentralWidget(self.mdi)
        self._windows = {}
        bar = self.menuBar()

        m_file = bar.addMenu("&Berkas")
        self._action(m_file, "Ganti Password...", lambda: ChangePasswordDialog(self, self.user).exec())
        self._action(m_file, "Backup Database...", self._backup)
        m_file.addSeparator()
        self._action(m_file, "Keluar", self.close)

        m_master = bar.addMenu("&Master")
        self._add(m_master, "Daftar Akun", "accounts.view", "accounts", AccountsView)
        self._add(m_master, "Pelanggan", "sales.view", "customers", CustomersView)
        self._add(m_master, "Pemasok", "purchases.view", "suppliers", SuppliersView)
        self._add(m_master, "Barang dan Persediaan", "inventory.view", "items", ItemsView)
        self._add(m_master, "Aset Tetap", "assets.view", "assets", AssetsView)

        m_sales = bar.addMenu("&Penjualan")
        self._add(m_sales, "Faktur Penjualan", "sales.view", "s_inv", SalesInvoicesView)
        self._add(m_sales, "Penerimaan Pembayaran", "sales.view", "s_set", SalesSettlementsView)
        self._add(m_sales, "Retur Penjualan", "sales.view", "s_ret", SalesReturnsView)

        m_buy = bar.addMenu("P&embelian")
        self._add(m_buy, "Faktur Pembelian", "purchases.view", "p_inv", PurchaseInvoicesView)
        self._add(m_buy, "Pembayaran Hutang", "purchases.view", "p_set", PurchaseSettlementsView)
        self._add(m_buy, "Retur Pembelian", "purchases.view", "p_ret", PurchaseReturnsView)

        m_acc = bar.addMenu("&Akuntansi")
        self._add(m_acc, "Jurnal Umum", "journals.view", "journals", JournalsView)
        self._add(m_acc, "Periode Akuntansi", "reports.view", "periods", PeriodsView)

        m_rep = bar.addMenu("&Laporan")
        self._add(m_rep, "Laporan Keuangan", "reports.view", "reports", ReportsView)

        m_set = bar.addMenu("&Pengaturan")
        self._action(m_set, "Pengaturan Perusahaan dan Akun...", self._settings)
        self._add(m_set, "User dan Role", "users.manage", "users", UsersView)
        self._add(m_set, "Log Audit", "audit.view", "audit", AuditView)

        m_help = bar.addMenu("&Bantuan")
        self._action(m_help, "Tentang",
                     lambda: QMessageBox.information(self, "Tentang", f"{APP_NAME}\nVersi {__version__}"))
        self.statusBar().showMessage(f"Login sebagai {user.username}")

    def _action(self, menu, title, slot):
        act = QAction(title, self)
        act.triggered.connect(lambda _checked=False: slot())
        menu.addAction(act)

    def _add(self, menu, title, permission, key, view_cls):
        self._action(menu, title, lambda: self._open(key, permission, view_cls))

    def _open(self, key, permission, view_cls):
        if not self.user.can(permission):
            show_error(self, "Anda tidak memiliki hak akses untuk menu ini.")
            return
        sub = self._windows.get(key)
        if sub is not None and sub in self.mdi.subWindowList():
            self.mdi.setActiveSubWindow(sub)
            return
        sub = self.mdi.addSubWindow(view_cls(self.user))
        self._windows[key] = sub
        sub.show()

    def _settings(self):
        if not self.user.can("settings.edit"):
            show_error(self, "Hanya administrator yang dapat mengubah pengaturan.")
            return
        SettingsDialog(self, self.user).exec()

    def _backup(self):
        if not self.user.can("backup.run"):
            show_error(self, "Anda tidak memiliki hak akses untuk backup.")
            return
        run_backup_dialog(self, self.user, self.cfg)
