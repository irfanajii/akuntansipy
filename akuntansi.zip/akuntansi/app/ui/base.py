"""Jendela daftar generik: tabel + deretan tombol."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView, QHBoxLayout, QHeaderView, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

RIGHT = Qt.AlignRight | Qt.AlignVCenter


class ListWindow(QWidget):
    def __init__(self, title, columns, right_cols=(), stretch_col=1, size=(900, 520)):
        super().__init__()
        self.setWindowTitle(title)
        self.right_cols = set(right_cols)
        self.table = QTableWidget(0, len(columns))
        self.table.setHorizontalHeaderLabels(columns)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(stretch_col, QHeaderView.Stretch)
        self.bar = QHBoxLayout()
        self.bar.addStretch()
        layout = QVBoxLayout(self)
        layout.addLayout(self.bar)
        layout.addWidget(self.table)
        self.resize(*size)

    def add_button(self, text, slot, enabled=True):
        b = QPushButton(text)
        b.clicked.connect(lambda _checked=False: slot())
        b.setEnabled(enabled)
        self.bar.insertWidget(self.bar.count() - 1, b)
        return b

    def set_rows(self, rows, gray=()):
        self.table.setRowCount(len(rows))
        for r, cells in enumerate(rows):
            for c, text in enumerate(cells):
                it = QTableWidgetItem(str(text))
                if c in self.right_cols:
                    it.setTextAlignment(RIGHT)
                if r in gray:
                    it.setForeground(Qt.gray)
                self.table.setItem(r, c, it)

    def current_index(self) -> int:
        return self.table.currentRow()
