"""Pemeriksaan koneksi dan pembuatan/pembaruan database (dipakai wizard pertama kali dan init_db.py)."""
from sqlalchemy import inspect, select, text

from app.database.connection import get_engine, session_scope
from app.database.models import Base, User
from app.database.schema_sync import sync_missing_columns
from app.database.seed import seed
from app.services.errors import AccountingError


def check_connection(engine) -> None:
    """Melempar exception jika server tidak bisa dihubungi / login database ditolak."""
    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))


def schema_status(engine):
    """Mengembalikan (tabel_yang_belum_ada, kolom_yang_belum_ada) dibanding versi aplikasi ini."""
    insp = inspect(engine)
    missing_tables, missing_columns = [], []
    for table in Base.metadata.sorted_tables:
        if not insp.has_table(table.name):
            missing_tables.append(table.name)
            continue
        existing = {c["name"] for c in insp.get_columns(table.name)}
        missing_columns += [f"{table.name}.{c.name}" for c in table.columns if c.name not in existing]
    return missing_tables, missing_columns


def initialize_database(admin_password: str = None) -> list:
    """Membuat/memperbarui tabel, kolom, data awal. Aman dijalankan berulang.

    admin_password hanya dibutuhkan bila user 'admin' belum ada. Mengembalikan daftar kolom yang ditambahkan.
    """
    engine = get_engine()
    Base.metadata.create_all(engine)
    added = sync_missing_columns(engine)
    with session_scope() as s:
        has_admin = s.scalar(select(User.id).where(User.username == "admin")) is not None
    if not has_admin and len(admin_password or "") < 8:
        raise AccountingError("Password untuk user 'admin' minimal 8 karakter.")
    with session_scope() as s:
        seed(s, admin_password=admin_password or "")
    return added
