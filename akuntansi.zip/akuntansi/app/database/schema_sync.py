"""Menambah kolom baru ke tabel yang sudah ada (migrasi sederhana, hanya penambahan).

create_all() hanya membuat tabel yang belum ada. Fungsi ini melengkapinya dengan
ALTER TABLE ... ADD COLUMN untuk kolom model yang belum ada di database. Semua kolom baru
pada tabel lama harus NULLABLE atau punya server_default. Constraint foreign key untuk
kolom yang ditambahkan lewat cara ini tidak dibuat ulang (kolomnya tetap berfungsi).
"""
from sqlalchemy import inspect
from sqlalchemy.schema import CreateColumn

from app.database.models import Base


def sync_missing_columns(engine) -> list:
    insp = inspect(engine)
    prep = engine.dialect.identifier_preparer
    added = []
    for table in Base.metadata.sorted_tables:
        if not insp.has_table(table.name):
            continue
        existing = {c["name"] for c in insp.get_columns(table.name)}
        for col in table.columns:
            if col.name in existing or col.primary_key:
                continue
            ddl = str(CreateColumn(col).compile(dialect=engine.dialect))
            with engine.begin() as conn:
                conn.exec_driver_sql(f"ALTER TABLE {prep.format_table(table)} ADD COLUMN {ddl}")
            added.append(f"{table.name}.{col.name}")
    return added
