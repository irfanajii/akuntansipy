"""Model database inti: user, akun, periode, jurnal, penomoran, audit."""
from datetime import date, datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import (
    Boolean, CheckConstraint, Date, DateTime, ForeignKey, Integer,
    Numeric, String, Text, func, text,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

MONEY = Numeric(18, 2)  # uang selalu DECIMAL, bukan float


class Base(DeclarativeBase):
    pass


class Role(Base):
    __tablename__ = "roles"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50), unique=True)
    # daftar izin dipisah koma, "*" = semua izin
    permissions: Mapped[str] = mapped_column(Text, default="")


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(50), unique=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    full_name: Mapped[str] = mapped_column(String(100))
    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id"))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    role: Mapped[Role] = relationship(lazy="joined")


class FiscalPeriod(Base):
    __tablename__ = "fiscal_periods"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(50))
    start_date: Mapped[date] = mapped_column(Date)
    end_date: Mapped[date] = mapped_column(Date)
    is_closed: Mapped[bool] = mapped_column(Boolean, default=False)
    closing_journal_id: Mapped[Optional[int]] = mapped_column(ForeignKey("journals.id"))


class Account(Base):
    __tablename__ = "accounts"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True)
    name: Mapped[str] = mapped_column(String(150))
    type: Mapped[str] = mapped_column(String(20))  # ASSET/LIABILITY/EQUITY/REVENUE/EXPENSE
    normal_balance: Mapped[str] = mapped_column(String(1))  # D / K
    parent_id: Mapped[Optional[int]] = mapped_column(ForeignKey("accounts.id"))
    is_header: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    # optimistic locking: SQLAlchemy menolak simpan jika data sudah diubah user lain
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    __mapper_args__ = {"version_id_col": version}


class Journal(Base):
    __tablename__ = "journals"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(30), unique=True)
    entry_date: Mapped[date] = mapped_column(Date, index=True)
    description: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(10), default="POSTED")  # POSTED / REVERSED
    source: Mapped[str] = mapped_column(String(20), default="MANUAL")  # MANUAL / REVERSAL / ...
    reversed_of_id: Mapped[Optional[int]] = mapped_column(ForeignKey("journals.id"))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())  # jam server
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    __mapper_args__ = {"version_id_col": version}

    lines: Mapped[list["JournalLine"]] = relationship(
        back_populates="journal", cascade="all, delete-orphan", order_by="JournalLine.id"
    )


class JournalLine(Base):
    __tablename__ = "journal_lines"
    __table_args__ = (
        CheckConstraint(
            "debit >= 0 AND credit >= 0 AND NOT (debit > 0 AND credit > 0)",
            name="ck_line_one_side",
        ),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    journal_id: Mapped[int] = mapped_column(ForeignKey("journals.id"), index=True)
    account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"), index=True)
    description: Mapped[Optional[str]] = mapped_column(String(255))
    debit: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    credit: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))

    journal: Mapped[Journal] = relationship(back_populates="lines")
    account: Mapped[Account] = relationship()


class Sequence(Base):
    """Penomoran dokumen per prefix + tahun, mis. 'JU-2026'."""
    __tablename__ = "sequences"
    key: Mapped[str] = mapped_column(String(30), primary_key=True)
    last_number: Mapped[int] = mapped_column(Integer, default=0)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    user_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(String(50))
    entity: Mapped[str] = mapped_column(String(50))
    entity_id: Mapped[Optional[str]] = mapped_column(String(50))
    detail: Mapped[Optional[str]] = mapped_column(Text)


class Setting(Base):
    """Pengaturan perusahaan dan akun-akun default (key/value)."""
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(50), primary_key=True)
    value: Mapped[str] = mapped_column(Text, default="")


class Customer(Base):
    __tablename__ = "customers"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True)
    name: Mapped[str] = mapped_column(String(150))
    address: Mapped[Optional[str]] = mapped_column(Text)
    phone: Mapped[Optional[str]] = mapped_column(String(50))
    email: Mapped[Optional[str]] = mapped_column(String(100))
    term_days: Mapped[int] = mapped_column(Integer, default=30)  # termin pembayaran
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    __mapper_args__ = {"version_id_col": version}


class SalesInvoice(Base):
    __tablename__ = "sales_invoices"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(30), unique=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    invoice_date: Mapped[date] = mapped_column(Date, index=True)
    due_date: Mapped[date] = mapped_column(Date)
    description: Mapped[Optional[str]] = mapped_column(String(255))
    subtotal: Mapped[Decimal] = mapped_column(MONEY)
    tax_rate: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=Decimal("0"))
    tax_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    total: Mapped[Decimal] = mapped_column(MONEY)
    paid_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    returned_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"), server_default=text("0"))
    status: Mapped[str] = mapped_column(String(10), default="OPEN")  # OPEN / PAID / VOID
    journal_id: Mapped[int] = mapped_column(ForeignKey("journals.id"))
    void_journal_id: Mapped[Optional[int]] = mapped_column(ForeignKey("journals.id"))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    customer: Mapped[Customer] = relationship()
    lines: Mapped[list["SalesInvoiceLine"]] = relationship(
        back_populates="invoice", cascade="all, delete-orphan", order_by="SalesInvoiceLine.id"
    )


class SalesInvoiceLine(Base):
    __tablename__ = "sales_invoice_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    invoice_id: Mapped[int] = mapped_column(ForeignKey("sales_invoices.id"), index=True)
    description: Mapped[str] = mapped_column(String(255))
    quantity: Mapped[Decimal] = mapped_column(Numeric(18, 4))
    unit_price: Mapped[Decimal] = mapped_column(MONEY)
    amount: Mapped[Decimal] = mapped_column(MONEY)
    account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"))  # akun pendapatan
    item_id: Mapped[Optional[int]] = mapped_column(ForeignKey("items.id"))
    warehouse_id: Mapped[Optional[int]] = mapped_column(ForeignKey("warehouses.id"))
    cogs_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"), server_default=text("0"))
    returned_qty: Mapped[Decimal] = mapped_column(Numeric(18, 4), default=Decimal("0"), server_default=text("0"))

    invoice: Mapped[SalesInvoice] = relationship(back_populates="lines")


class SalesReceipt(Base):
    """Penerimaan pembayaran piutang dari pelanggan."""
    __tablename__ = "sales_receipts"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(30), unique=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    receipt_date: Mapped[date] = mapped_column(Date, index=True)
    cash_account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"))
    amount: Mapped[Decimal] = mapped_column(MONEY)
    description: Mapped[Optional[str]] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(10), default="POSTED")  # POSTED / VOID
    journal_id: Mapped[int] = mapped_column(ForeignKey("journals.id"))
    void_journal_id: Mapped[Optional[int]] = mapped_column(ForeignKey("journals.id"))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    customer: Mapped[Customer] = relationship()
    cash_account: Mapped[Account] = relationship()
    allocations: Mapped[list["ReceiptAllocation"]] = relationship(
        back_populates="receipt", cascade="all, delete-orphan"
    )


class ReceiptAllocation(Base):
    __tablename__ = "receipt_allocations"
    id: Mapped[int] = mapped_column(primary_key=True)
    receipt_id: Mapped[int] = mapped_column(ForeignKey("sales_receipts.id"), index=True)
    invoice_id: Mapped[int] = mapped_column(ForeignKey("sales_invoices.id"), index=True)
    amount: Mapped[Decimal] = mapped_column(MONEY)

    receipt: Mapped[SalesReceipt] = relationship(back_populates="allocations")
    invoice: Mapped[SalesInvoice] = relationship()



# ====================================================================== persediaan
class Warehouse(Base):
    __tablename__ = "warehouses"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True)
    name: Mapped[str] = mapped_column(String(100))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class Item(Base):
    """Barang/jasa. Barang dinilai dengan metode rata-rata bergerak (moving average)."""
    __tablename__ = "items"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), unique=True)
    name: Mapped[str] = mapped_column(String(150))
    unit: Mapped[str] = mapped_column(String(20), default="pcs")
    sell_price: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    is_service: Mapped[bool] = mapped_column(Boolean, default=False)  # jasa: tidak punya stok
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    qty_on_hand: Mapped[Decimal] = mapped_column(Numeric(18, 4), default=Decimal("0"))
    stock_value: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    __mapper_args__ = {"version_id_col": version}


class StockMovement(Base):
    """Buku stok: qty dan nilai bertanda (+ masuk, - keluar)."""
    __tablename__ = "stock_movements"
    id: Mapped[int] = mapped_column(primary_key=True)
    item_id: Mapped[int] = mapped_column(ForeignKey("items.id"), index=True)
    warehouse_id: Mapped[int] = mapped_column(ForeignKey("warehouses.id"), index=True)
    move_date: Mapped[date] = mapped_column(Date, index=True)
    qty: Mapped[Decimal] = mapped_column(Numeric(18, 4))
    value: Mapped[Decimal] = mapped_column(MONEY)
    kind: Mapped[str] = mapped_column(String(20))  # PURCHASE/SALE/ADJUST/TRANSFER/RETURN/VOID
    ref_type: Mapped[Optional[str]] = mapped_column(String(30))
    ref_id: Mapped[Optional[int]] = mapped_column(Integer, index=True)
    note: Mapped[Optional[str]] = mapped_column(String(255))
    created_by: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


# ====================================================================== pembelian & hutang
class Supplier(Base):
    __tablename__ = "suppliers"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(20), unique=True)
    name: Mapped[str] = mapped_column(String(150))
    address: Mapped[Optional[str]] = mapped_column(Text)
    phone: Mapped[Optional[str]] = mapped_column(String(50))
    email: Mapped[Optional[str]] = mapped_column(String(100))
    term_days: Mapped[int] = mapped_column(Integer, default=30)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    __mapper_args__ = {"version_id_col": version}


class PurchaseInvoice(Base):
    __tablename__ = "purchase_invoices"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(30), unique=True)
    supplier_invoice_no: Mapped[Optional[str]] = mapped_column(String(50))
    supplier_id: Mapped[int] = mapped_column(ForeignKey("suppliers.id"), index=True)
    invoice_date: Mapped[date] = mapped_column(Date, index=True)
    due_date: Mapped[date] = mapped_column(Date)
    description: Mapped[Optional[str]] = mapped_column(String(255))
    subtotal: Mapped[Decimal] = mapped_column(MONEY)
    tax_rate: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=Decimal("0"))
    tax_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    total: Mapped[Decimal] = mapped_column(MONEY)
    paid_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    returned_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    status: Mapped[str] = mapped_column(String(10), default="OPEN")  # OPEN / PAID / VOID
    journal_id: Mapped[int] = mapped_column(ForeignKey("journals.id"))
    void_journal_id: Mapped[Optional[int]] = mapped_column(ForeignKey("journals.id"))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    supplier: Mapped[Supplier] = relationship()
    lines: Mapped[list["PurchaseInvoiceLine"]] = relationship(
        back_populates="invoice", cascade="all, delete-orphan", order_by="PurchaseInvoiceLine.id"
    )


class PurchaseInvoiceLine(Base):
    __tablename__ = "purchase_invoice_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    invoice_id: Mapped[int] = mapped_column(ForeignKey("purchase_invoices.id"), index=True)
    description: Mapped[str] = mapped_column(String(255))
    quantity: Mapped[Decimal] = mapped_column(Numeric(18, 4))
    unit_price: Mapped[Decimal] = mapped_column(MONEY)
    amount: Mapped[Decimal] = mapped_column(MONEY)
    account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"))  # persediaan / beban / aset
    item_id: Mapped[Optional[int]] = mapped_column(ForeignKey("items.id"))
    warehouse_id: Mapped[Optional[int]] = mapped_column(ForeignKey("warehouses.id"))
    returned_qty: Mapped[Decimal] = mapped_column(Numeric(18, 4), default=Decimal("0"))

    invoice: Mapped[PurchaseInvoice] = relationship(back_populates="lines")


class PurchasePayment(Base):
    """Pembayaran hutang ke pemasok."""
    __tablename__ = "purchase_payments"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(30), unique=True)
    supplier_id: Mapped[int] = mapped_column(ForeignKey("suppliers.id"), index=True)
    payment_date: Mapped[date] = mapped_column(Date, index=True)
    cash_account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"))
    amount: Mapped[Decimal] = mapped_column(MONEY)
    description: Mapped[Optional[str]] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(10), default="POSTED")
    journal_id: Mapped[int] = mapped_column(ForeignKey("journals.id"))
    void_journal_id: Mapped[Optional[int]] = mapped_column(ForeignKey("journals.id"))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    supplier: Mapped[Supplier] = relationship()
    cash_account: Mapped[Account] = relationship()
    allocations: Mapped[list["PaymentAllocation"]] = relationship(
        back_populates="payment", cascade="all, delete-orphan"
    )


class PaymentAllocation(Base):
    __tablename__ = "payment_allocations"
    id: Mapped[int] = mapped_column(primary_key=True)
    payment_id: Mapped[int] = mapped_column(ForeignKey("purchase_payments.id"), index=True)
    invoice_id: Mapped[int] = mapped_column(ForeignKey("purchase_invoices.id"), index=True)
    amount: Mapped[Decimal] = mapped_column(MONEY)

    payment: Mapped[PurchasePayment] = relationship(back_populates="allocations")
    invoice: Mapped[PurchaseInvoice] = relationship()


# ====================================================================== retur
class SalesReturn(Base):
    __tablename__ = "sales_returns"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(30), unique=True)
    invoice_id: Mapped[int] = mapped_column(ForeignKey("sales_invoices.id"), index=True)
    return_date: Mapped[date] = mapped_column(Date, index=True)
    description: Mapped[Optional[str]] = mapped_column(String(255))
    subtotal: Mapped[Decimal] = mapped_column(MONEY)
    tax_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    total: Mapped[Decimal] = mapped_column(MONEY)
    status: Mapped[str] = mapped_column(String(10), default="POSTED")  # POSTED / VOID
    journal_id: Mapped[int] = mapped_column(ForeignKey("journals.id"))
    void_journal_id: Mapped[Optional[int]] = mapped_column(ForeignKey("journals.id"))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    invoice: Mapped[SalesInvoice] = relationship()
    lines: Mapped[list["SalesReturnLine"]] = relationship(
        back_populates="ret", cascade="all, delete-orphan")


class SalesReturnLine(Base):
    __tablename__ = "sales_return_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    return_id: Mapped[int] = mapped_column(ForeignKey("sales_returns.id"), index=True)
    invoice_line_id: Mapped[int] = mapped_column(ForeignKey("sales_invoice_lines.id"))
    quantity: Mapped[Decimal] = mapped_column(Numeric(18, 4))
    unit_price: Mapped[Decimal] = mapped_column(MONEY)
    amount: Mapped[Decimal] = mapped_column(MONEY)
    cogs_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))

    ret: Mapped[SalesReturn] = relationship(back_populates="lines")


class PurchaseReturn(Base):
    __tablename__ = "purchase_returns"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(30), unique=True)
    invoice_id: Mapped[int] = mapped_column(ForeignKey("purchase_invoices.id"), index=True)
    return_date: Mapped[date] = mapped_column(Date, index=True)
    description: Mapped[Optional[str]] = mapped_column(String(255))
    subtotal: Mapped[Decimal] = mapped_column(MONEY)
    tax_amount: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    total: Mapped[Decimal] = mapped_column(MONEY)
    status: Mapped[str] = mapped_column(String(10), default="POSTED")
    journal_id: Mapped[int] = mapped_column(ForeignKey("journals.id"))
    void_journal_id: Mapped[Optional[int]] = mapped_column(ForeignKey("journals.id"))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())

    invoice: Mapped[PurchaseInvoice] = relationship()
    lines: Mapped[list["PurchaseReturnLine"]] = relationship(
        back_populates="ret", cascade="all, delete-orphan")


class PurchaseReturnLine(Base):
    __tablename__ = "purchase_return_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    return_id: Mapped[int] = mapped_column(ForeignKey("purchase_returns.id"), index=True)
    invoice_line_id: Mapped[int] = mapped_column(ForeignKey("purchase_invoice_lines.id"))
    quantity: Mapped[Decimal] = mapped_column(Numeric(18, 4))
    unit_price: Mapped[Decimal] = mapped_column(MONEY)
    amount: Mapped[Decimal] = mapped_column(MONEY)

    ret: Mapped[PurchaseReturn] = relationship(back_populates="lines")


# ====================================================================== aset tetap
class FixedAsset(Base):
    """Daftar aset tetap; penyusutan garis lurus bulanan."""
    __tablename__ = "fixed_assets"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(30), unique=True)
    name: Mapped[str] = mapped_column(String(150))
    acquisition_date: Mapped[date] = mapped_column(Date)
    cost: Mapped[Decimal] = mapped_column(MONEY)
    salvage_value: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    life_months: Mapped[int] = mapped_column(Integer)
    asset_account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"))
    accum_account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"))
    expense_account_id: Mapped[int] = mapped_column(ForeignKey("accounts.id"))
    accumulated: Mapped[Decimal] = mapped_column(MONEY, default=Decimal("0"))
    months_depreciated: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[str] = mapped_column(String(10), default="ACTIVE")  # ACTIVE / DISPOSED
    disposal_date: Mapped[Optional[date]] = mapped_column(Date)
    disposal_journal_id: Mapped[Optional[int]] = mapped_column(ForeignKey("journals.id"))
    created_by: Mapped[int] = mapped_column(ForeignKey("users.id"))
    version: Mapped[int] = mapped_column(Integer, nullable=False)
    __mapper_args__ = {"version_id_col": version}


class DepreciationEntry(Base):
    __tablename__ = "depreciation_entries"
    id: Mapped[int] = mapped_column(primary_key=True)
    asset_id: Mapped[int] = mapped_column(ForeignKey("fixed_assets.id"), index=True)
    period_end: Mapped[date] = mapped_column(Date, index=True)
    amount: Mapped[Decimal] = mapped_column(MONEY)
    journal_id: Mapped[int] = mapped_column(ForeignKey("journals.id"))
