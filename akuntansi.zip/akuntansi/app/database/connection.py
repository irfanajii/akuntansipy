"""Koneksi database dan session."""
from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.engine import URL
from sqlalchemy.orm import sessionmaker

from app.config import DBConfig, resolve_sqlite_path

_engine = None
_SessionFactory = None


def build_url(cfg: DBConfig) -> URL:
    if cfg.driver == "sqlite":
        return URL.create("sqlite", database=str(resolve_sqlite_path(cfg)))
    return URL.create(
        "mysql+pymysql",
        username=cfg.user,
        password=cfg.password,
        host=cfg.host,
        port=cfg.port,
        database=cfg.name,
        query={"charset": "utf8mb4"},
    )


def make_engine(cfg: DBConfig):
    """Membuat engine tanpa menyimpannya sebagai engine global (dipakai untuk tes koneksi)."""
    kwargs = {"pool_pre_ping": True}
    if cfg.driver != "sqlite":
        kwargs["connect_args"] = {"connect_timeout": 5}  # gagal cepat jika server tidak terjangkau
    return create_engine(build_url(cfg), **kwargs)


def init_engine(cfg: DBConfig):
    global _engine, _SessionFactory
    _engine = make_engine(cfg)
    _SessionFactory = sessionmaker(bind=_engine, expire_on_commit=False)
    return _engine


def get_engine():
    if _engine is None:
        raise RuntimeError("Database belum diinisialisasi (panggil init_engine).")
    return _engine


@contextmanager
def session_scope():
    """Satu blok = satu transaksi: commit jika sukses, rollback jika error."""
    if _SessionFactory is None:
        raise RuntimeError("Database belum diinisialisasi (panggil init_engine).")
    session = _SessionFactory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
