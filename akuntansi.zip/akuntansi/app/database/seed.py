"""Data awal: role, user admin, COA contoh, periode akuntansi tahun berjalan."""
from datetime import date

from sqlalchemy import select

from app.database.models import Account, FiscalPeriod, Role, Setting, User, Warehouse
from app.services.settings import DEFAULTS
from app.services.accounts import NORMAL_BALANCE
from app.services.auth import hash_password
from app.services.permissions import PERMISSIONS  # noqa: F401

ROLES = {
    "Administrator": "*",
    "Akuntan": ("accounts.view,accounts.edit,journals.view,journals.post,journals.void,reports.view,"
                "sales.view,sales.post,sales.void,customers.edit,"
                "purchases.view,purchases.post,purchases.void,suppliers.edit,"
                "inventory.view,inventory.edit,assets.view,assets.edit,periods.close,audit.view"),
    "Viewer": "accounts.view,journals.view,reports.view,sales.view,purchases.view,inventory.view,assets.view",
}

# Akun yang dibutuhkan modul-modul baru; ditambahkan jika kodenya belum ada
# (kode, nama, tipe, kode induk, header?)
REQUIRED_ACCOUNTS = [
    ("1400", "ASET TETAP", "ASSET", "1000", True),
    ("1410", "Peralatan dan Kendaraan", "ASSET", "1400", False),
    ("1420", "Akumulasi Penyusutan", "ASSET", "1400", False),
    ("1500", "Pajak Masukan", "ASSET", "1000", False),
    ("4200", "Retur Penjualan", "REVENUE", "4000", False),
    ("4900", "Pendapatan Lain-lain", "REVENUE", "4000", False),
    ("5400", "Beban Penyusutan", "EXPENSE", "5000", False),
    ("5500", "Selisih Persediaan", "EXPENSE", "5000", False),
    ("5600", "Laba/Rugi Pelepasan Aset", "EXPENSE", "5000", False),
]

# (kode, nama, tipe, kode induk, header?)
DEFAULT_COA = [
    ("1000", "ASET", "ASSET", None, True),
    ("1100", "Kas dan Bank", "ASSET", "1000", True),
    ("1110", "Kas", "ASSET", "1100", False),
    ("1120", "Bank", "ASSET", "1100", False),
    ("1200", "Piutang Usaha", "ASSET", "1000", False),
    ("1300", "Persediaan Barang", "ASSET", "1000", False),
    ("1400", "ASET TETAP", "ASSET", "1000", True),
    ("1410", "Peralatan dan Kendaraan", "ASSET", "1400", False),
    ("1420", "Akumulasi Penyusutan", "ASSET", "1400", False),
    ("1500", "Pajak Masukan", "ASSET", "1000", False),
    ("2000", "KEWAJIBAN", "LIABILITY", None, True),
    ("2100", "Hutang Usaha", "LIABILITY", "2000", False),
    ("2200", "Hutang Pajak", "LIABILITY", "2000", False),
    ("2500", "HUTANG JANGKA PANJANG", "LIABILITY", "2000", True),
    ("2510", "Hutang Bank", "LIABILITY", "2500", False),
    ("3000", "MODAL", "EQUITY", None, True),
    ("3100", "Modal Pemilik", "EQUITY", "3000", False),
    ("3200", "Laba Ditahan", "EQUITY", "3000", False),
    ("4000", "PENDAPATAN", "REVENUE", None, True),
    ("4100", "Penjualan", "REVENUE", "4000", False),
    ("4200", "Retur Penjualan", "REVENUE", "4000", False),
    ("5000", "BEBAN", "EXPENSE", None, True),
    ("5100", "Harga Pokok Penjualan", "EXPENSE", "5000", False),
    ("5200", "Beban Gaji", "EXPENSE", "5000", False),
    ("5300", "Beban Listrik dan Air", "EXPENSE", "5000", False),
    ("5400", "Beban Penyusutan", "EXPENSE", "5000", False),
    ("5500", "Selisih Persediaan", "EXPENSE", "5000", False),
    ("5600", "Laba/Rugi Pelepasan Aset", "EXPENSE", "5000", False),
]


def ensure_required_accounts(session) -> list:
    """Menambah akun yang dibutuhkan modul baru bila kodenya belum ada. Mengembalikan kode yang ditambahkan."""
    added = []
    for code, name, typ, parent, header in REQUIRED_ACCOUNTS:
        if session.scalar(select(Account.id).where(Account.code == code)):
            continue
        parent_acc = session.scalar(select(Account).where(Account.code == parent)) if parent else None
        session.add(Account(code=code, name=name, type=typ, normal_balance=NORMAL_BALANCE[typ],
                            parent_id=parent_acc.id if parent_acc else None, is_header=header))
        session.flush()
        added.append(code)
    return added


def seed(session, admin_password: str) -> None:
    """Idempotent: aman dipanggil berulang."""
    for name, perms in ROLES.items():
        role = session.scalar(select(Role).where(Role.name == name))
        if role is None:
            session.add(Role(name=name, permissions=perms))
        elif role.permissions != "*":
            # tambahkan izin baru dari versi ini (tanpa menghapus izin yang sudah ada)
            have = {p.strip() for p in (role.permissions or "").split(",") if p.strip()}
            want = {p.strip() for p in perms.split(",") if p.strip()}
            role.permissions = ",".join(sorted(have | want))
    session.flush()

    for key, value in DEFAULTS.items():
        if session.get(Setting, key) is None:
            session.add(Setting(key=key, value=value))
    session.flush()

    if not session.scalar(select(User).where(User.username == "admin")):
        admin_role = session.scalar(select(Role).where(Role.name == "Administrator"))
        session.add(User(username="admin", password_hash=hash_password(admin_password),
                         full_name="Administrator", role_id=admin_role.id))

    if not session.scalar(select(Account.id).limit(1)):
        by_code = {}
        for code, name, typ, parent, header in DEFAULT_COA:
            acc = Account(code=code, name=name, type=typ, normal_balance=NORMAL_BALANCE[typ],
                          parent_id=by_code[parent].id if parent else None, is_header=header)
            session.add(acc)
            session.flush()
            by_code[code] = acc

    ensure_required_accounts(session)
    if not session.scalar(select(Warehouse.id).limit(1)):
        session.add(Warehouse(code="GD-UTAMA", name="Gudang Utama"))

    year = date.today().year
    if not session.scalar(select(FiscalPeriod.id).limit(1)):
        session.add(FiscalPeriod(name=f"Tahun {year}", start_date=date(year, 1, 1),
                                 end_date=date(year, 12, 31)))
    session.flush()
