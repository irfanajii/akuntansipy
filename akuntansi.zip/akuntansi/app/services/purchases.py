"""Pembelian dan hutang: pemasok, faktur (stok masuk otomatis), pembayaran hutang, retur."""
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.database.models import (
    Account, Journal, PaymentAllocation, PurchaseInvoice, PurchaseInvoiceLine, PurchasePayment,
    PurchaseReturn, PurchaseReturnLine, Supplier,
)
from app.services import audit, inventory
from app.services.auth import require
from app.services.errors import AccountingError, flush_checked
from app.services.journals import LineInput, post_system_journal, reverse_system_journal
from app.services.sequences import next_number
from app.services.trade_common import (  # noqa: F401
    CENT, QTY, ZERO, InvoiceLineInput, dec, outstanding, party_create, party_list, party_update,
    refresh_status, setting_account, status_label,
)


# ------------------------------------------------------------------ pemasok
def list_suppliers(session, user, include_inactive=True):
    return party_list(session, user, Supplier, "purchases.view", include_inactive)


def create_supplier(session, user, *, code, name, address="", phone="", email="", term_days=30):
    return party_create(session, user, Supplier, "suppliers.edit", "pemasok", code=code, name=name,
                        address=address, phone=phone, email=email, term_days=term_days)


def update_supplier(session, user, supplier_id, *, name, address, phone, email, term_days, is_active,
                    expected_version):
    return party_update(session, user, Supplier, "suppliers.edit", "pemasok", supplier_id, name=name,
                        address=address, phone=phone, email=email, term_days=term_days,
                        is_active=is_active, expected_version=expected_version)


# ------------------------------------------------------------------ faktur pembelian
def create_invoice(session, user, supplier_id, invoice_date: date, lines, tax_rate=0,
                   due_date: date = None, description="", warehouse_id: int = None,
                   supplier_invoice_no=""):
    """Faktur pembelian kredit.

    Jurnal otomatis: Dr Persediaan (barang berstok) / Dr akun beban-aset (baris lain) / Dr Pajak Masukan;
    Cr Hutang Usaha. Barang berstok masuk gudang bernilai sesuai harga beli (tanpa pajak).
    """
    require(user, "purchases.post")
    supplier = session.get(Supplier, supplier_id)
    if supplier is None or not supplier.is_active:
        raise AccountingError("Pemasok tidak ditemukan atau tidak aktif.")
    if not lines:
        raise AccountingError("Faktur minimal terdiri dari satu baris.")

    payable = setting_account(session, "payable_account", "Hutang Usaha")
    rate = dec(tax_rate, CENT, "Tarif pajak")
    if not (ZERO <= rate <= Decimal("100")):
        raise AccountingError("Tarif pajak harus antara 0 dan 100.")

    items = inventory.lock_items(session, [ln.item_id for ln in lines if ln.item_id])
    default_wh = warehouse_id or inventory.default_warehouse_id(session)
    inv_acc = None
    norm, debit_by_acc = [], {}
    for i, ln in enumerate(lines, 1):
        item = items.get(ln.item_id) if ln.item_id else None
        if ln.item_id and (item is None or not item.is_active):
            raise AccountingError(f"Baris {i}: barang tidak valid atau tidak aktif.")
        desc = (ln.description or "").strip() or (item.name if item else "")
        qty, price = dec(ln.quantity, QTY, "Jumlah"), dec(ln.unit_price, CENT, "Harga")
        if not desc:
            raise AccountingError(f"Baris {i}: deskripsi wajib diisi.")
        if qty <= 0 or price <= 0:
            raise AccountingError(f"Baris {i}: jumlah dan harga harus lebih dari nol.")
        wh = None
        if item is not None and not item.is_service:
            inv_acc = inv_acc or setting_account(session, "inventory_account", "Persediaan Barang")
            acc = inv_acc
            wh = ln.warehouse_id or default_wh
            if wh is None:
                raise AccountingError(f"Baris {i}: gudang belum dipilih.")
        else:
            acc = session.get(Account, ln.account_id) if ln.account_id else None
            if acc is None or acc.is_header or not acc.is_active or acc.type not in ("ASSET", "EXPENSE"):
                raise AccountingError(f"Baris {i}: pilih akun beban/aset yang valid.")
        amount = (qty * price).quantize(CENT, rounding=ROUND_HALF_UP)
        norm.append((desc, qty, price, amount, acc, item, wh))
        debit_by_acc[acc.id] = debit_by_acc.get(acc.id, ZERO) + amount

    subtotal = sum((n[3] for n in norm), ZERO)
    tax_amount = (subtotal * rate / 100).quantize(CENT, rounding=ROUND_HALF_UP)
    total = subtotal + tax_amount
    due = due_date or invoice_date + timedelta(days=supplier.term_days)
    if due < invoice_date:
        raise AccountingError("Tanggal jatuh tempo tidak boleh sebelum tanggal faktur.")

    number = next_number(session, "PUR", invoice_date.year)
    moves = []
    for desc, qty, price, amount, acc, item, wh in norm:
        if wh is not None:
            moves.append(inventory.apply_movement(
                session, item, wh, qty, amount, invoice_date, "PURCHASE", "PURCHASE_INVOICE", None,
                f"Faktur {number}", user.id))

    jlines = [LineInput(acc_id, debit=amt, description=f"Faktur {number}") for acc_id, amt in debit_by_acc.items()]
    if tax_amount > 0:
        tax_acc = setting_account(session, "purchase_tax_account", "Pajak Masukan")
        jlines.append(LineInput(tax_acc.id, debit=tax_amount, description=f"Pajak faktur {number}"))
    jlines.append(LineInput(payable.id, credit=total, description=f"Faktur {number}"))
    journal = post_system_journal(
        session, user, invoice_date, f"Faktur pembelian {number} - {supplier.name}", jlines, source="PURCHASE")

    inv = PurchaseInvoice(
        number=number, supplier_invoice_no=(supplier_invoice_no or "").strip() or None,
        supplier_id=supplier.id, invoice_date=invoice_date, due_date=due,
        description=(description or "").strip() or None, subtotal=subtotal, tax_rate=rate,
        tax_amount=tax_amount, total=total, paid_amount=ZERO, returned_amount=ZERO, status="OPEN",
        journal_id=journal.id, created_by=user.id)
    for desc, qty, price, amount, acc, item, wh in norm:
        inv.lines.append(PurchaseInvoiceLine(
            description=desc, quantity=qty, unit_price=price, amount=amount, account_id=acc.id,
            item_id=item.id if item is not None else None, warehouse_id=wh, returned_qty=ZERO))
    session.add(inv)
    flush_checked(session)
    for m in moves:
        m.ref_id = inv.id
    flush_checked(session)
    audit.log(session, user, "CREATE", "purchase_invoice", inv.id, f"{number} total {total}")
    return inv


def void_invoice(session, user, invoice_id: int, reason="", void_date: date = None):
    require(user, "purchases.void")
    inv = session.get(PurchaseInvoice, invoice_id, with_for_update=True)
    if inv is None:
        raise AccountingError("Faktur tidak ditemukan.")
    if inv.status == "VOID":
        raise AccountingError(f"Faktur {inv.number} sudah dibatalkan.")
    if inv.paid_amount > 0:
        raise AccountingError(f"Faktur {inv.number} sudah ada pembayaran. Batalkan pembayarannya terlebih dahulu.")
    if (inv.returned_amount or 0) > 0:
        raise AccountingError(f"Faktur {inv.number} sudah ada retur. Batalkan returnya terlebih dahulu.")
    when = void_date or date.today()
    original = session.get(Journal, inv.journal_id, with_for_update=True)
    reversal = reverse_system_journal(
        session, user, original, f"faktur {inv.number} {reason or ''}".strip(), when)
    inventory.reverse_movements(session, user.id, "PURCHASE_INVOICE", inv.id, when)
    inv.status, inv.void_journal_id = "VOID", reversal.id
    flush_checked(session)
    audit.log(session, user, "VOID", "purchase_invoice", inv.id, inv.number)
    return inv


def _invoice_row(inv):
    return {
        "id": inv.id, "number": inv.number, "date": inv.invoice_date, "due_date": inv.due_date,
        "supplier_id": inv.supplier_id, "party_id": inv.supplier_id, "supplier": inv.supplier.name,
        "party": inv.supplier.name, "subtotal": inv.subtotal, "tax_amount": inv.tax_amount,
        "total": inv.total, "paid": inv.paid_amount, "returned": inv.returned_amount or ZERO,
        "outstanding": outstanding(inv) if inv.status != "VOID" else ZERO,
        "status": inv.status, "status_label": status_label(inv),
        "supplier_invoice_no": inv.supplier_invoice_no or "",
    }


def list_invoices(session, user, limit=300):
    require(user, "purchases.view")
    stmt = (select(PurchaseInvoice).options(selectinload(PurchaseInvoice.supplier))
            .order_by(PurchaseInvoice.invoice_date.desc(), PurchaseInvoice.id.desc()).limit(limit))
    return [_invoice_row(i) for i in session.scalars(stmt)]


def outstanding_invoices(session, user, supplier_id: int):
    require(user, "purchases.view")
    stmt = (select(PurchaseInvoice).options(selectinload(PurchaseInvoice.supplier))
            .where(PurchaseInvoice.supplier_id == supplier_id, PurchaseInvoice.status == "OPEN")
            .order_by(PurchaseInvoice.due_date, PurchaseInvoice.id))
    return [_invoice_row(i) for i in session.scalars(stmt) if outstanding(i) > 0]


def invoice_detail(session, user, invoice_id: int) -> dict:
    require(user, "purchases.view")
    inv = session.scalar(
        select(PurchaseInvoice).where(PurchaseInvoice.id == invoice_id)
        .options(selectinload(PurchaseInvoice.lines), selectinload(PurchaseInvoice.supplier)))
    if inv is None:
        raise AccountingError("Faktur tidak ditemukan.")
    row = _invoice_row(inv)
    row.update({
        "customer": {"name": inv.supplier.name, "address": inv.supplier.address or "",
                     "phone": inv.supplier.phone or ""},  # kunci 'customer' dipakai pencetak PDF
        "description": inv.description or "", "tax_rate": inv.tax_rate,
        "lines": [{"id": l.id, "description": l.description, "quantity": l.quantity,
                   "unit_price": l.unit_price, "amount": l.amount, "returned_qty": l.returned_qty}
                  for l in inv.lines],
    })
    return row


# ------------------------------------------------------------------ pembayaran hutang
def create_payment(session, user, supplier_id, payment_date: date, cash_account_id: int,
                   allocations, description=""):
    """allocations: daftar (invoice_id, jumlah). Jurnal: Dr Hutang Usaha; Cr Kas/Bank."""
    require(user, "purchases.post")
    supplier = session.get(Supplier, supplier_id)
    if supplier is None:
        raise AccountingError("Pemasok tidak ditemukan.")
    cash = session.get(Account, cash_account_id)
    if cash is None or cash.is_header or not cash.is_active or cash.type != "ASSET":
        raise AccountingError("Akun kas/bank tidak valid.")
    payable = setting_account(session, "payable_account", "Hutang Usaha")

    alloc = {}
    for inv_id, amount in allocations:
        amount = dec(amount)
        if amount <= 0:
            continue
        if inv_id in alloc:
            raise AccountingError("Satu faktur tidak boleh dialokasikan dua kali.")
        alloc[inv_id] = amount
    if not alloc:
        raise AccountingError("Isi jumlah pembayaran pada minimal satu faktur.")

    invoices = {i.id: i for i in session.scalars(
        select(PurchaseInvoice).where(PurchaseInvoice.id.in_(list(alloc))).with_for_update())}
    for inv_id, amount in alloc.items():
        inv = invoices.get(inv_id)
        if inv is None or inv.supplier_id != supplier.id:
            raise AccountingError("Ada faktur yang tidak ditemukan atau bukan milik pemasok ini.")
        if inv.status != "OPEN":
            raise AccountingError(f"Faktur {inv.number} berstatus {status_label(inv)}.")
        if payment_date < inv.invoice_date:
            raise AccountingError(f"Tanggal pembayaran tidak boleh sebelum tanggal faktur {inv.number}.")
        if amount > outstanding(inv):
            raise AccountingError(
                f"Pembayaran faktur {inv.number} melebihi sisa hutang ({outstanding(inv)}).")

    total = sum(alloc.values(), ZERO)
    number = next_number(session, "PAY", payment_date.year)
    journal = post_system_journal(
        session, user, payment_date, f"Pembayaran {number} - {supplier.name}",
        [LineInput(payable.id, debit=total, description=f"Pembayaran {number}"),
         LineInput(cash.id, credit=total, description=f"Pembayaran {number}")],
        source="PAYMENT")

    pay = PurchasePayment(number=number, supplier_id=supplier.id, payment_date=payment_date,
                          cash_account_id=cash.id, amount=total,
                          description=(description or "").strip() or None, status="POSTED",
                          journal_id=journal.id, created_by=user.id)
    for inv_id, amount in alloc.items():
        inv = invoices[inv_id]
        inv.paid_amount = inv.paid_amount + amount
        refresh_status(inv)
        pay.allocations.append(PaymentAllocation(invoice_id=inv_id, amount=amount))
    session.add(pay)
    flush_checked(session)
    audit.log(session, user, "CREATE", "purchase_payment", pay.id, f"{number} total {total}")
    return pay


def void_payment(session, user, payment_id: int, reason="", void_date: date = None):
    require(user, "purchases.void")
    pay = session.get(PurchasePayment, payment_id, with_for_update=True)
    if pay is None:
        raise AccountingError("Pembayaran tidak ditemukan.")
    if pay.status == "VOID":
        raise AccountingError(f"Pembayaran {pay.number} sudah dibatalkan.")
    original = session.get(Journal, pay.journal_id, with_for_update=True)
    reversal = reverse_system_journal(
        session, user, original, f"pembayaran {pay.number} {reason or ''}".strip(), void_date)
    ids = [a.invoice_id for a in pay.allocations]
    invoices = {i.id: i for i in session.scalars(
        select(PurchaseInvoice).where(PurchaseInvoice.id.in_(ids)).with_for_update())}
    for a in pay.allocations:
        inv = invoices[a.invoice_id]
        inv.paid_amount = inv.paid_amount - a.amount
        refresh_status(inv)
    pay.status, pay.void_journal_id = "VOID", reversal.id
    flush_checked(session)
    audit.log(session, user, "VOID", "purchase_payment", pay.id, pay.number)
    return pay


def list_payments(session, user, limit=300):
    require(user, "purchases.view")
    stmt = (select(PurchasePayment)
            .options(selectinload(PurchasePayment.supplier), selectinload(PurchasePayment.cash_account))
            .order_by(PurchasePayment.payment_date.desc(), PurchasePayment.id.desc()).limit(limit))
    return [{"id": r.id, "number": r.number, "date": r.payment_date, "party": r.supplier.name,
             "cash_account": f"{r.cash_account.code} - {r.cash_account.name}", "amount": r.amount,
             "status": r.status, "description": r.description or ""} for r in session.scalars(stmt)]


# ------------------------------------------------------------------ retur pembelian
def returnable_lines(session, user, invoice_id: int):
    require(user, "purchases.view")
    inv = session.scalar(select(PurchaseInvoice).where(PurchaseInvoice.id == invoice_id)
                         .options(selectinload(PurchaseInvoice.lines)))
    if inv is None:
        raise AccountingError("Faktur tidak ditemukan.")
    return [{"line_id": l.id, "description": l.description, "quantity": l.quantity,
             "returned_qty": l.returned_qty, "remaining": l.quantity - l.returned_qty,
             "unit_price": l.unit_price} for l in inv.lines]


def create_return(session, user, invoice_id: int, return_date: date, lines, description=""):
    """Retur pembelian. lines: daftar (invoice_line_id, jumlah).

    Jurnal: Dr Hutang Usaha / Cr Persediaan (atau akun baris asal) / Cr Pajak Masukan.
    Barang berstok keluar dari gudang bernilai harga beli aslinya.
    """
    require(user, "purchases.post")
    inv = session.get(PurchaseInvoice, invoice_id, with_for_update=True)
    if inv is None or inv.status == "VOID":
        raise AccountingError("Faktur tidak ditemukan atau sudah dibatalkan.")
    if return_date < inv.invoice_date:
        raise AccountingError("Tanggal retur tidak boleh sebelum tanggal faktur.")
    by_id = {l.id: l for l in inv.lines}
    wanted = {}
    for line_id, qty in lines:
        qty = dec(qty, QTY, "Jumlah retur")
        if qty <= 0:
            continue
        if line_id in wanted:
            raise AccountingError("Satu baris faktur tidak boleh diretur dua kali dalam satu dokumen.")
        ln = by_id.get(line_id)
        if ln is None:
            raise AccountingError("Ada baris faktur yang tidak ditemukan.")
        if qty > ln.quantity - ln.returned_qty:
            raise AccountingError(f"Retur '{ln.description}' melebihi jumlah yang masih bisa diretur.")
        wanted[line_id] = qty
    if not wanted:
        raise AccountingError("Isi jumlah retur pada minimal satu baris.")

    items = inventory.lock_items(session, [by_id[i].item_id for i in wanted])
    rows, credit_by_acc = [], {}
    for line_id, qty in wanted.items():
        ln = by_id[line_id]
        amount = (qty * ln.unit_price).quantize(CENT, rounding=ROUND_HALF_UP)
        rows.append((ln, qty, amount))
        credit_by_acc[ln.account_id] = credit_by_acc.get(ln.account_id, ZERO) + amount
    subtotal = sum((r[2] for r in rows), ZERO)
    tax = (subtotal * inv.tax_rate / 100).quantize(CENT, rounding=ROUND_HALF_UP)
    total = subtotal + tax
    if total > outstanding(inv):
        raise AccountingError(
            f"Nilai retur ({total}) melebihi sisa hutang faktur ({outstanding(inv)}). "
            "Batalkan atau sesuaikan pembayaran faktur terlebih dahulu.")

    payable = setting_account(session, "payable_account", "Hutang Usaha")
    number = next_number(session, "PRT", return_date.year)
    moves = []
    for ln, qty, amount in rows:
        item = items.get(ln.item_id) if ln.item_id else None
        if item is not None and not item.is_service:
            moves.append(inventory.apply_movement(
                session, item, ln.warehouse_id, -qty, -amount, return_date, "RETURN", "PURCHASE_RETURN",
                None, f"Retur {number}", user.id))
    jlines = [LineInput(payable.id, debit=total, description=f"Retur {number}")]
    for acc_id, amt in credit_by_acc.items():
        jlines.append(LineInput(acc_id, credit=amt, description=f"Retur {number}"))
    if tax > 0:
        tax_acc = setting_account(session, "purchase_tax_account", "Pajak Masukan")
        jlines.append(LineInput(tax_acc.id, credit=tax, description=f"Pajak retur {number}"))
    journal = post_system_journal(
        session, user, return_date, f"Retur pembelian {number} - {inv.supplier.name}", jlines,
        source="PURCHASE_RETURN")

    ret = PurchaseReturn(number=number, invoice_id=inv.id, return_date=return_date,
                         description=(description or "").strip() or None, subtotal=subtotal,
                         tax_amount=tax, total=total, status="POSTED", journal_id=journal.id,
                         created_by=user.id)
    for ln, qty, amount in rows:
        ret.lines.append(PurchaseReturnLine(invoice_line_id=ln.id, quantity=qty, unit_price=ln.unit_price,
                                            amount=amount))
        ln.returned_qty = ln.returned_qty + qty
    inv.returned_amount = (inv.returned_amount or ZERO) + total
    refresh_status(inv)
    session.add(ret)
    flush_checked(session)
    for m in moves:
        m.ref_id = ret.id
    flush_checked(session)
    audit.log(session, user, "CREATE", "purchase_return", ret.id, f"{number} total {total}")
    return ret


def void_return(session, user, return_id: int, reason="", void_date: date = None):
    require(user, "purchases.void")
    ret = session.get(PurchaseReturn, return_id, with_for_update=True)
    if ret is None:
        raise AccountingError("Retur tidak ditemukan.")
    if ret.status == "VOID":
        raise AccountingError(f"Retur {ret.number} sudah dibatalkan.")
    inv = session.get(PurchaseInvoice, ret.invoice_id, with_for_update=True)
    when = void_date or date.today()
    original = session.get(Journal, ret.journal_id, with_for_update=True)
    reversal = reverse_system_journal(
        session, user, original, f"retur {ret.number} {reason or ''}".strip(), when)
    inventory.reverse_movements(session, user.id, "PURCHASE_RETURN", ret.id, when)
    for rl in ret.lines:
        line = session.get(PurchaseInvoiceLine, rl.invoice_line_id)
        line.returned_qty = line.returned_qty - rl.quantity
    inv.returned_amount = (inv.returned_amount or ZERO) - ret.total
    refresh_status(inv)
    ret.status, ret.void_journal_id = "VOID", reversal.id
    flush_checked(session)
    audit.log(session, user, "VOID", "purchase_return", ret.id, ret.number)
    return ret


def list_returns(session, user, limit=300):
    require(user, "purchases.view")
    stmt = (select(PurchaseReturn)
            .options(selectinload(PurchaseReturn.invoice).selectinload(PurchaseInvoice.supplier))
            .order_by(PurchaseReturn.return_date.desc(), PurchaseReturn.id.desc()).limit(limit))
    return [{"id": r.id, "number": r.number, "date": r.return_date, "invoice": r.invoice.number,
             "party": r.invoice.supplier.name, "total": r.total, "status": r.status}
            for r in session.scalars(stmt)]


# ------------------------------------------------------------------ nama seragam untuk layar generik
list_parties = list_suppliers
create_settlement = create_payment
void_settlement = void_payment
list_settlements = list_payments
