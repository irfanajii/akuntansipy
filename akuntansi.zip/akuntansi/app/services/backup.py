"""Backup database (mysqldump untuk MariaDB/MySQL, salin untuk SQLite)."""
import os
import shutil
import sqlite3
import subprocess
from datetime import datetime
from pathlib import Path

from app.config import DBConfig, resolve_sqlite_path, user_data_dir
from app.services.auth import require
from app.services.errors import AccountingError


def backup_database(cfg: DBConfig, out_dir=None, keep: int = 0) -> Path:
    """Membuat file backup dan mengembalikan path-nya. keep > 0: simpan hanya N backup terbaru."""
    out = Path(out_dir or cfg.backup_dir)
    if not out.is_absolute():
        out = user_data_dir() / out  # folder yang pasti bisa ditulis (bukan Program Files)
    out.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if cfg.driver == "sqlite":
        target = out / f"akuntansi_{stamp}.db"
        src = sqlite3.connect(str(resolve_sqlite_path(cfg)))
        dst = sqlite3.connect(target)
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        pattern = "akuntansi_*.db"
    else:
        target = out / f"akuntansi_{stamp}.sql"
        cmd = [cfg.mysqldump_path, f"--host={cfg.host}", f"--port={cfg.port}", f"--user={cfg.user}",
               "--single-transaction", "--routines", "--default-character-set=utf8mb4",
               f"--result-file={target}", cfg.name]
        env = dict(os.environ, MYSQL_PWD=cfg.password)  # tidak lewat argumen perintah
        try:
            res = subprocess.run(cmd, env=env, capture_output=True, text=True)
        except FileNotFoundError as exc:
            raise AccountingError(
                f"Program mysqldump tidak ditemukan ({cfg.mysqldump_path}). "
                "Isi mysqldump_path di config.ini atau jalankan backup dari komputer server.") from exc
        if res.returncode != 0:
            if target.exists():
                target.unlink()
            raise AccountingError("Backup gagal: " + (res.stderr or "kesalahan tidak diketahui").strip())
        pattern = "akuntansi_*.sql"
    if keep and keep > 0:
        for old in sorted(out.glob(pattern))[:-keep]:
            old.unlink()
    return target


def backup_with_permission(user, cfg: DBConfig, out_dir=None) -> Path:
    require(user, "backup.run")
    return backup_database(cfg, out_dir)
