"""Helper bersama modul penjualan dan pembelian."""
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from sqlalchemy import select

from app.database.models import Account
from app.services import audit, settings
from app.services.auth import require
from app.services.errors import AccountingError, ConflictError, flush_checked

CENT = Decimal("0.01")
QTY = Decimal("0.0001")
ZERO = Decimal("0.00")
STATUS_LABELS = {"OPEN": "Belum lunas", "PAID": "Lunas", "VOID": "Dibatalkan"}


@dataclass
class InvoiceLineInput:
    description: str
    quantity: object
    unit_price: object
    account_id: int = None    # akun pendapatan (penjualan) / akun beban-aset-persediaan (pembelian)
    item_id: int = None       # barang (opsional)
    warehouse_id: int = None  # gudang untuk barang; kosong = gudang pada faktur


def dec(value, quant=CENT, what="Nominal") -> Decimal:
    try:
        d = Decimal(str(value if value not in (None, "") else 0))
    except InvalidOperation as exc:
        raise AccountingError(f"{what} tidak valid: {value!r}") from exc
    if not d.is_finite():
        raise AccountingError(f"{what} tidak valid: {value!r}")
    return d.quantize(quant, rounding=ROUND_HALF_UP)


def setting_account(session, key: str, label: str) -> Account:
    code = settings.get(session, key)
    acc = session.scalar(select(Account).where(Account.code == code))
    if acc is None or acc.is_header or not acc.is_active:
        raise AccountingError(
            f"Akun {label} (kode {code}) belum diatur atau tidak valid. Periksa menu Pengaturan.")
    return acc


def outstanding(doc) -> Decimal:
    """Sisa tagihan faktur (penjualan/pembelian): total - dibayar - diretur."""
    return doc.total - doc.paid_amount - (doc.returned_amount or ZERO)


def status_label(doc) -> str:
    if doc.status == "OPEN" and (doc.paid_amount > 0 or (doc.returned_amount or 0) > 0):
        return "Dibayar sebagian" if doc.paid_amount > 0 else "Sebagian diretur"
    return STATUS_LABELS[doc.status]


def refresh_status(doc):
    """Setelah pembayaran/retur: lunas bila sisa nol, selain itu terbuka."""
    if doc.status == "VOID":
        return
    doc.status = "PAID" if outstanding(doc) <= 0 else "OPEN"


# ------------------------------------------------------------------ pelanggan / pemasok
def party_list(session, user, model, view_perm, include_inactive=True):
    require(user, view_perm)
    stmt = select(model).order_by(model.code)
    if not include_inactive:
        stmt = stmt.where(model.is_active.is_(True))
    return list(session.scalars(stmt))


def _clean_party(label, code, name, term_days):
    code, name = (code or "").strip(), (name or "").strip()
    if not code or not name:
        raise AccountingError(f"Kode dan nama {label} wajib diisi.")
    try:
        term = int(term_days)
    except (TypeError, ValueError):
        raise AccountingError("Termin pembayaran harus berupa angka (hari).")
    if not (0 <= term <= 365):
        raise AccountingError("Termin pembayaran harus antara 0 dan 365 hari.")
    return code, name, term


def party_create(session, user, model, edit_perm, label, *, code, name, address="", phone="",
                 email="", term_days=30):
    require(user, edit_perm)
    code, name, term = _clean_party(label, code, name, term_days)
    if session.scalar(select(model.id).where(model.code == code)):
        raise AccountingError(f"Kode {label} {code} sudah dipakai.")
    p = model(code=code, name=name, address=(address or "").strip() or None,
              phone=(phone or "").strip() or None, email=(email or "").strip() or None,
              term_days=term, is_active=True)
    session.add(p)
    flush_checked(session)
    audit.log(session, user, "CREATE", label, p.id, f"{code} {name}")
    return p


def party_update(session, user, model, edit_perm, label, party_id, *, name, address, phone, email,
                 term_days, is_active, expected_version):
    require(user, edit_perm)
    p = session.get(model, party_id, with_for_update=True)
    if p is None:
        raise AccountingError(f"{label.capitalize()} tidak ditemukan.")
    if p.version != expected_version:
        raise ConflictError(f"Data {label} ini sudah diubah pengguna lain. Muat ulang data lalu coba lagi.")
    _code, name, term = _clean_party(label, p.code, name, term_days)
    p.name, p.term_days, p.is_active = name, term, is_active
    p.address = (address or "").strip() or None
    p.phone = (phone or "").strip() or None
    p.email = (email or "").strip() or None
    flush_checked(session)
    audit.log(session, user, "UPDATE", label, p.id, f"{p.code} {name}")
    return p
