from sqlalchemy.orm.exc import StaleDataError


class AccountingError(Exception):
    """Kesalahan aturan akuntansi/bisnis; pesannya aman ditampilkan ke user."""


class PermissionDenied(AccountingError):
    pass


class ConflictError(AccountingError):
    pass


def flush_checked(session):
    """flush() yang mengubah konflik edit (optimistic lock) jadi pesan ramah."""
    try:
        session.flush()
    except StaleDataError as exc:
        raise ConflictError(
            "Data sudah diubah oleh pengguna lain. Muat ulang data lalu coba lagi."
        ) from exc
