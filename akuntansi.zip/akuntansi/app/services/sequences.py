"""Penomoran dokumen yang aman untuk multi-user."""
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.database.models import Sequence


def next_number(session, prefix: str, year: int) -> str:
    """Contoh hasil: JU-2026-00001.

    Baris sequence dikunci (SELECT ... FOR UPDATE) sampai transaksi selesai,
    sehingga dua user yang menyimpan bersamaan tidak akan mendapat nomor kembar.
    Harus dipanggil di dalam transaksi yang sama dengan penyimpanan dokumen.
    """
    key = f"{prefix}-{year}"
    stmt = (
        select(Sequence)
        .where(Sequence.key == key)
        .with_for_update()
        .execution_options(populate_existing=True)
    )
    seq = session.execute(stmt).scalar_one_or_none()
    if seq is None:
        try:
            with session.begin_nested():  # savepoint, jika bentrok dengan user lain
                session.add(Sequence(key=key, last_number=0))
        except IntegrityError:
            pass
        seq = session.execute(stmt).scalar_one()
    seq.last_number += 1
    session.flush()
    return f"{key}-{seq.last_number:05d}"
