"""Daftar izin yang bisa diatur per role."""

PERMISSIONS = {
    "accounts.view": "Lihat daftar akun", "accounts.edit": "Ubah daftar akun",
    "journals.view": "Lihat jurnal", "journals.post": "Buat jurnal manual", "journals.void": "Batalkan jurnal manual",
    "reports.view": "Lihat laporan",
    "sales.view": "Lihat penjualan", "sales.post": "Buat faktur/penerimaan/retur penjualan",
    "sales.void": "Batalkan dokumen penjualan", "customers.edit": "Ubah data pelanggan",
    "purchases.view": "Lihat pembelian", "purchases.post": "Buat faktur/pembayaran/retur pembelian",
    "purchases.void": "Batalkan dokumen pembelian", "suppliers.edit": "Ubah data pemasok",
    "inventory.view": "Lihat persediaan", "inventory.edit": "Ubah barang, gudang, penyesuaian stok",
    "assets.view": "Lihat aset tetap", "assets.edit": "Ubah aset tetap & penyusutan",
    "periods.close": "Tutup/buka periode akuntansi", "audit.view": "Lihat log audit",
    "settings.edit": "Ubah pengaturan", "users.manage": "Kelola user dan role", "backup.run": "Backup database",
}
