"""Jurnal umum: posting, pembatalan (jurnal pembalik), neraca saldo."""
from dataclasses import dataclass
from datetime import date
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from sqlalchemy import func, select
from sqlalchemy.orm import selectinload

from app.database.models import Account, FiscalPeriod, Journal, JournalLine
from app.services import audit
from app.services.auth import require
from app.services.errors import AccountingError, flush_checked
from app.services.sequences import next_number

CENT = Decimal("0.01")
ZERO = Decimal("0.00")
JOURNAL_PREFIX = "JU"


@dataclass
class LineInput:
    account_id: int
    debit: object = 0
    credit: object = 0
    description: str = ""


def _money(value) -> Decimal:
    try:
        d = Decimal(str(value if value not in (None, "") else 0))
    except InvalidOperation as exc:
        raise AccountingError(f"Nominal tidak valid: {value!r}") from exc
    if not d.is_finite():
        raise AccountingError(f"Nominal tidak valid: {value!r}")
    return d.quantize(CENT, rounding=ROUND_HALF_UP)


def _check_period(session, entry_date: date) -> FiscalPeriod:
    period = session.scalar(
        select(FiscalPeriod).where(
            FiscalPeriod.start_date <= entry_date, FiscalPeriod.end_date >= entry_date
        )
    )
    if period is None:
        raise AccountingError(f"Tidak ada periode akuntansi untuk tanggal {entry_date:%d/%m/%Y}.")
    if period.is_closed:
        raise AccountingError(f"Periode {period.name} sudah ditutup. Transaksi tidak bisa disimpan.")
    return period


SYSTEM_SOURCES = ("SALES", "RECEIPT", "SALES_RETURN", "PURCHASE", "PAYMENT", "PURCHASE_RETURN",
                  "STOCK", "ASSET", "CLOSING")  # jurnal otomatis dari modul lain


def post_journal(session, user, entry_date: date, description: str, lines, source="MANUAL"):
    require(user, "journals.post")
    return post_system_journal(session, user, entry_date, description, lines, source)


def post_system_journal(session, user, entry_date: date, description: str, lines, source="MANUAL"):
    """Posting jurnal tanpa cek izin journals.post: dipakai modul lain (penjualan, dll).

    Pemanggil WAJIB sudah memeriksa izin modulnya sendiri. Semua validasi akuntansi tetap berlaku.
    """
    description = (description or "").strip()
    if not description:
        raise AccountingError("Keterangan jurnal wajib diisi.")

    norm = []
    for i, ln in enumerate(lines, 1):
        debit, credit = _money(ln.debit), _money(ln.credit)
        if debit < 0 or credit < 0:
            raise AccountingError(f"Baris {i}: nominal tidak boleh negatif.")
        if debit > 0 and credit > 0:
            raise AccountingError(f"Baris {i}: debit dan kredit tidak boleh diisi bersamaan.")
        if debit == 0 and credit == 0:
            raise AccountingError(f"Baris {i}: nominal debit/kredit masih kosong.")
        norm.append((ln, debit, credit))
    if len(norm) < 2:
        raise AccountingError("Jurnal minimal terdiri dari dua baris.")

    total_debit = sum((d for _, d, _ in norm), ZERO)
    total_credit = sum((c for _, _, c in norm), ZERO)
    if total_debit != total_credit:
        raise AccountingError(
            f"Jurnal tidak seimbang: total debit {total_debit} ≠ total kredit {total_credit}."
        )

    ids = {ln.account_id for ln, _, _ in norm}
    found = {a.id: a for a in session.scalars(select(Account).where(Account.id.in_(ids)))}
    for ln, _, _ in norm:
        acc = found.get(ln.account_id)
        if acc is None:
            raise AccountingError("Ada akun yang tidak ditemukan.")
        if acc.is_header:
            raise AccountingError(f"Akun {acc.code} adalah header dan tidak bisa dipakai di jurnal.")
        if not acc.is_active:
            raise AccountingError(f"Akun {acc.code} tidak aktif.")

    _check_period(session, entry_date)

    # nomor diambil terakhir (setelah semua validasi) agar tidak ada nomor bolong
    journal = Journal(
        number=next_number(session, JOURNAL_PREFIX, entry_date.year),
        entry_date=entry_date,
        description=description,
        status="POSTED",
        source=source,
        created_by=user.id,
    )
    for ln, debit, credit in norm:
        journal.lines.append(
            JournalLine(
                account_id=ln.account_id, description=(ln.description or "").strip() or None,
                debit=debit, credit=credit,
            )
        )
    session.add(journal)
    flush_checked(session)
    audit.log(session, user, "POST", "journal", journal.id, f"{journal.number} total {total_debit}")
    return journal


def void_journal(session, user, journal_id: int, reason: str = "", entry_date: date = None):
    """Jurnal diposting tidak dihapus; dibatalkan dengan jurnal pembalik."""
    require(user, "journals.void")
    original = session.get(Journal, journal_id, with_for_update=True)
    if original is None:
        raise AccountingError("Jurnal tidak ditemukan.")
    if original.source in SYSTEM_SOURCES:
        raise AccountingError(
            f"Jurnal {original.number} dibuat otomatis oleh modul lain (penjualan, pembelian, persediaan, aset tetap, atau penutupan periode). "
            "Batalkan lewat dokumen atau menu terkait."
        )
    return reverse_system_journal(session, user, original, reason, entry_date)


def reverse_system_journal(session, user, original, reason: str = "", entry_date: date = None,
                           source: str = "REVERSAL"):
    """Membuat jurnal pembalik untuk jurnal yang sudah dikunci pemanggil (tanpa cek izin)."""
    if original.status == "REVERSED":
        raise AccountingError(f"Jurnal {original.number} sudah dibatalkan sebelumnya.")
    if original.source == "REVERSAL":
        raise AccountingError("Jurnal pembalik tidak dapat dibatalkan lagi.")

    entry_date = entry_date or date.today()
    _check_period(session, entry_date)

    text = f"Pembatalan {original.number}" + (f": {reason.strip()}" if reason and reason.strip() else "")
    reversal = Journal(
        number=next_number(session, JOURNAL_PREFIX, entry_date.year),
        entry_date=entry_date,
        description=text[:255],
        status="POSTED",
        source=source,
        reversed_of_id=original.id,
        created_by=user.id,
    )
    for ln in original.lines:
        reversal.lines.append(
            JournalLine(account_id=ln.account_id, description=ln.description,
                        debit=ln.credit, credit=ln.debit)
        )
    original.status = "REVERSED"
    session.add(reversal)
    flush_checked(session)
    audit.log(session, user, "REVERSE", "journal", original.id, f"{original.number} -> {reversal.number}")
    return reversal


def list_journals(session, user, limit: int = 200):
    require(user, "journals.view")
    stmt = (
        select(Journal)
        .options(selectinload(Journal.lines))
        .order_by(Journal.entry_date.desc(), Journal.id.desc())
        .limit(limit)
    )
    return [
        {
            "id": j.id, "number": j.number, "date": j.entry_date, "description": j.description,
            "status": j.status, "source": j.source,
            "total": sum((l.debit for l in j.lines), ZERO),
        }
        for j in session.scalars(stmt)
    ]


def journal_detail(session, user, journal_id: int):
    require(user, "journals.view")
    j = session.scalar(
        select(Journal).where(Journal.id == journal_id)
        .options(selectinload(Journal.lines).selectinload(JournalLine.account))
    )
    if j is None:
        raise AccountingError("Jurnal tidak ditemukan.")
    return {
        "number": j.number, "date": j.entry_date, "description": j.description,
        "status": j.status, "source": j.source,
        "lines": [
            {"account": f"{l.account.code} - {l.account.name}", "description": l.description or "",
             "debit": l.debit, "credit": l.credit}
            for l in j.lines
        ],
    }


def trial_balance(session, user, date_to: date):
    """Neraca saldo s.d. tanggal tertentu.

    Semua jurnal ikut dihitung, termasuk jurnal asli yang sudah dibatalkan beserta
    jurnal pembaliknya (keduanya saling meniadakan).
    """
    require(user, "reports.view")
    sub = (
        select(
            JournalLine.account_id.label("aid"),
            func.sum(JournalLine.debit).label("d"),
            func.sum(JournalLine.credit).label("k"),
        )
        .join(Journal, Journal.id == JournalLine.journal_id)
        .where(Journal.entry_date <= date_to)
        .group_by(JournalLine.account_id)
        .subquery()
    )
    stmt = (
        select(Account.code, Account.name, sub.c.d, sub.c.k)
        .join(sub, sub.c.aid == Account.id)
        .order_by(Account.code)
    )
    rows, tot_d, tot_k = [], ZERO, ZERO
    for code, name, d, k in session.execute(stmt):
        d, k = Decimal(d or 0), Decimal(k or 0)
        net = d - k
        sd, sk = (net, ZERO) if net > 0 else (ZERO, -net)
        rows.append({"code": code, "name": name, "debit": d, "credit": k,
                     "balance_debit": sd, "balance_credit": sk})
        tot_d += sd
        tot_k += sk
    return {"rows": rows, "total_debit": tot_d, "total_credit": tot_k}
