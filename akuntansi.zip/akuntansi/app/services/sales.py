"""Penjualan dan piutang: pelanggan, faktur (dengan stok dan HPP otomatis), penerimaan pembayaran, retur."""
from datetime import date, timedelta
from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.database.models import (
    Account, Customer, Journal, ReceiptAllocation, SalesInvoice, SalesInvoiceLine, SalesReceipt,
    SalesReturn, SalesReturnLine,
)
from app.services import audit, inventory
from app.services.auth import require
from app.services.errors import AccountingError, flush_checked
from app.services.journals import LineInput, post_system_journal, reverse_system_journal
from app.services.sequences import next_number
from app.services.trade_common import (  # noqa: F401  (sebagian diekspor untuk pemanggil lain)
    CENT, QTY, STATUS_LABELS, ZERO, InvoiceLineInput, dec, outstanding, party_create, party_list,
    party_update, refresh_status, setting_account, status_label,
)


# ------------------------------------------------------------------ pelanggan
def list_customers(session, user, include_inactive=True):
    return party_list(session, user, Customer, "sales.view", include_inactive)


def create_customer(session, user, *, code, name, address="", phone="", email="", term_days=30):
    return party_create(session, user, Customer, "customers.edit", "pelanggan", code=code, name=name,
                        address=address, phone=phone, email=email, term_days=term_days)


def update_customer(session, user, customer_id, *, name, address, phone, email, term_days, is_active,
                    expected_version):
    return party_update(session, user, Customer, "customers.edit", "pelanggan", customer_id, name=name,
                        address=address, phone=phone, email=email, term_days=term_days,
                        is_active=is_active, expected_version=expected_version)


# ------------------------------------------------------------------ faktur
def create_invoice(session, user, customer_id, invoice_date: date, lines, tax_rate=0,
                   due_date: date = None, description="", warehouse_id: int = None):
    """Faktur penjualan kredit.

    Jurnal otomatis: Dr Piutang; Cr Pendapatan (+ Cr Pajak). Untuk barang berstok ditambah
    Dr HPP / Cr Persediaan sebesar nilai rata-rata barang yang keluar.
    """
    require(user, "sales.post")
    customer = session.get(Customer, customer_id)
    if customer is None or not customer.is_active:
        raise AccountingError("Pelanggan tidak ditemukan atau tidak aktif.")
    if not lines:
        raise AccountingError("Faktur minimal terdiri dari satu baris.")

    receivable = setting_account(session, "receivable_account", "Piutang Usaha")
    rate = dec(tax_rate, CENT, "Tarif pajak")
    if not (ZERO <= rate <= Decimal("100")):
        raise AccountingError("Tarif pajak harus antara 0 dan 100.")

    items = inventory.lock_items(session, [ln.item_id for ln in lines if ln.item_id])
    default_wh = warehouse_id or inventory.default_warehouse_id(session)
    default_rev = None
    norm, revenue_by_acc = [], {}
    for i, ln in enumerate(lines, 1):
        item = items.get(ln.item_id) if ln.item_id else None
        if ln.item_id and (item is None or not item.is_active):
            raise AccountingError(f"Baris {i}: barang tidak valid atau tidak aktif.")
        desc = (ln.description or "").strip() or (item.name if item else "")
        qty, price = dec(ln.quantity, QTY, "Jumlah"), dec(ln.unit_price, CENT, "Harga")
        if not desc:
            raise AccountingError(f"Baris {i}: deskripsi wajib diisi.")
        if qty <= 0 or price <= 0:
            raise AccountingError(f"Baris {i}: jumlah dan harga harus lebih dari nol.")
        if ln.account_id:
            acc = session.get(Account, ln.account_id)
            if acc is None or acc.is_header or not acc.is_active or acc.type != "REVENUE":
                raise AccountingError(f"Baris {i}: akun pendapatan tidak valid.")
        else:
            default_rev = default_rev or setting_account(session, "sales_account", "Penjualan")
            acc = default_rev
        wh = None
        if item is not None and not item.is_service:
            wh = ln.warehouse_id or default_wh
            if wh is None:
                raise AccountingError(f"Baris {i}: gudang belum dipilih.")
        amount = (qty * price).quantize(CENT, rounding=ROUND_HALF_UP)
        norm.append((desc, qty, price, amount, acc, item, wh))
        revenue_by_acc[acc.id] = revenue_by_acc.get(acc.id, ZERO) + amount

    subtotal = sum((n[3] for n in norm), ZERO)
    tax_amount = (subtotal * rate / 100).quantize(CENT, rounding=ROUND_HALF_UP)
    total = subtotal + tax_amount
    due = due_date or invoice_date + timedelta(days=customer.term_days)
    if due < invoice_date:
        raise AccountingError("Tanggal jatuh tempo tidak boleh sebelum tanggal faktur.")

    number = next_number(session, "INV", invoice_date.year)

    moves, cogs_by_line, cogs_total = [], [], ZERO
    for desc, qty, price, amount, acc, item, wh in norm:
        cogs = ZERO
        if wh is not None:
            m = inventory.issue_at_average(session, item, wh, qty, invoice_date, "SALE", "SALES_INVOICE",
                                           None, f"Faktur {number}", user.id)
            moves.append(m)
            cogs = -m.value
        cogs_by_line.append(cogs)
        cogs_total += cogs

    jlines = [LineInput(receivable.id, debit=total, description=f"Faktur {number}")]
    for acc_id, amt in revenue_by_acc.items():
        jlines.append(LineInput(acc_id, credit=amt, description=f"Faktur {number}"))
    if tax_amount > 0:
        tax_acc = setting_account(session, "tax_payable_account", "Pajak Keluaran")
        jlines.append(LineInput(tax_acc.id, credit=tax_amount, description=f"Pajak faktur {number}"))
    if cogs_total > 0:
        cogs_acc = setting_account(session, "cogs_account", "Harga Pokok Penjualan")
        inv_acc = setting_account(session, "inventory_account", "Persediaan Barang")
        jlines.append(LineInput(cogs_acc.id, debit=cogs_total, description=f"HPP {number}"))
        jlines.append(LineInput(inv_acc.id, credit=cogs_total, description=f"HPP {number}"))
    journal = post_system_journal(
        session, user, invoice_date, f"Faktur penjualan {number} - {customer.name}", jlines, source="SALES")

    inv = SalesInvoice(
        number=number, customer_id=customer.id, invoice_date=invoice_date, due_date=due,
        description=(description or "").strip() or None, subtotal=subtotal, tax_rate=rate,
        tax_amount=tax_amount, total=total, paid_amount=ZERO, returned_amount=ZERO, status="OPEN",
        journal_id=journal.id, created_by=user.id,
    )
    for (desc, qty, price, amount, acc, item, wh), cogs in zip(norm, cogs_by_line):
        inv.lines.append(SalesInvoiceLine(
            description=desc, quantity=qty, unit_price=price, amount=amount, account_id=acc.id,
            item_id=item.id if item is not None else None, warehouse_id=wh, cogs_amount=cogs,
            returned_qty=ZERO))
    session.add(inv)
    flush_checked(session)
    for m in moves:
        m.ref_id = inv.id
    flush_checked(session)
    audit.log(session, user, "CREATE", "sales_invoice", inv.id, f"{number} total {total}")
    return inv


def void_invoice(session, user, invoice_id: int, reason="", void_date: date = None):
    require(user, "sales.void")
    inv = session.get(SalesInvoice, invoice_id, with_for_update=True)
    if inv is None:
        raise AccountingError("Faktur tidak ditemukan.")
    if inv.status == "VOID":
        raise AccountingError(f"Faktur {inv.number} sudah dibatalkan.")
    if inv.paid_amount > 0:
        raise AccountingError(
            f"Faktur {inv.number} sudah ada pembayaran. Batalkan penerimaan pembayarannya terlebih dahulu.")
    if (inv.returned_amount or 0) > 0:
        raise AccountingError(f"Faktur {inv.number} sudah ada retur. Batalkan returnya terlebih dahulu.")
    when = void_date or date.today()
    original = session.get(Journal, inv.journal_id, with_for_update=True)
    reversal = reverse_system_journal(
        session, user, original, f"faktur {inv.number} {reason or ''}".strip(), when)
    inventory.reverse_movements(session, user.id, "SALES_INVOICE", inv.id, when)
    inv.status, inv.void_journal_id = "VOID", reversal.id
    flush_checked(session)
    audit.log(session, user, "VOID", "sales_invoice", inv.id, inv.number)
    return inv


def _invoice_row(inv):
    return {
        "id": inv.id, "number": inv.number, "date": inv.invoice_date, "due_date": inv.due_date,
        "customer_id": inv.customer_id, "party_id": inv.customer_id, "customer": inv.customer.name,
        "party": inv.customer.name, "subtotal": inv.subtotal, "tax_amount": inv.tax_amount,
        "total": inv.total, "paid": inv.paid_amount, "returned": inv.returned_amount or ZERO,
        "outstanding": outstanding(inv) if inv.status != "VOID" else ZERO,
        "status": inv.status, "status_label": status_label(inv),
    }


def list_invoices(session, user, limit=300):
    require(user, "sales.view")
    stmt = (select(SalesInvoice).options(selectinload(SalesInvoice.customer))
            .order_by(SalesInvoice.invoice_date.desc(), SalesInvoice.id.desc()).limit(limit))
    return [_invoice_row(i) for i in session.scalars(stmt)]


def outstanding_invoices(session, user, customer_id: int):
    """Faktur pelanggan yang masih punya sisa tagihan (untuk penerimaan pembayaran)."""
    require(user, "sales.view")
    stmt = (select(SalesInvoice).options(selectinload(SalesInvoice.customer))
            .where(SalesInvoice.customer_id == customer_id, SalesInvoice.status == "OPEN")
            .order_by(SalesInvoice.due_date, SalesInvoice.id))
    return [_invoice_row(i) for i in session.scalars(stmt) if outstanding(i) > 0]


def invoice_detail(session, user, invoice_id: int) -> dict:
    require(user, "sales.view")
    inv = session.scalar(
        select(SalesInvoice).where(SalesInvoice.id == invoice_id)
        .options(selectinload(SalesInvoice.lines), selectinload(SalesInvoice.customer)))
    if inv is None:
        raise AccountingError("Faktur tidak ditemukan.")
    row = _invoice_row(inv)
    row.update({
        "customer": {"name": inv.customer.name, "address": inv.customer.address or "",
                     "phone": inv.customer.phone or ""},
        "description": inv.description or "", "tax_rate": inv.tax_rate,
        "lines": [{"id": l.id, "description": l.description, "quantity": l.quantity,
                   "unit_price": l.unit_price, "amount": l.amount, "returned_qty": l.returned_qty}
                  for l in inv.lines],
    })
    return row


# ------------------------------------------------------------------ penerimaan pembayaran
def create_receipt(session, user, customer_id, receipt_date: date, cash_account_id: int,
                   allocations, description=""):
    """allocations: daftar (invoice_id, jumlah). Jurnal: Dr Kas/Bank; Cr Piutang."""
    require(user, "sales.post")
    customer = session.get(Customer, customer_id)
    if customer is None:
        raise AccountingError("Pelanggan tidak ditemukan.")
    cash = session.get(Account, cash_account_id)
    if cash is None or cash.is_header or not cash.is_active or cash.type != "ASSET":
        raise AccountingError("Akun kas/bank tidak valid.")
    receivable = setting_account(session, "receivable_account", "Piutang Usaha")

    alloc = {}
    for inv_id, amount in allocations:
        amount = dec(amount)
        if amount <= 0:
            continue
        if inv_id in alloc:
            raise AccountingError("Satu faktur tidak boleh dialokasikan dua kali.")
        alloc[inv_id] = amount
    if not alloc:
        raise AccountingError("Isi jumlah pembayaran pada minimal satu faktur.")

    invoices = {i.id: i for i in session.scalars(
        select(SalesInvoice).where(SalesInvoice.id.in_(list(alloc))).with_for_update())}
    for inv_id, amount in alloc.items():
        inv = invoices.get(inv_id)
        if inv is None or inv.customer_id != customer.id:
            raise AccountingError("Ada faktur yang tidak ditemukan atau bukan milik pelanggan ini.")
        if inv.status != "OPEN":
            raise AccountingError(f"Faktur {inv.number} berstatus {status_label(inv)}.")
        if receipt_date < inv.invoice_date:
            raise AccountingError(f"Tanggal pembayaran tidak boleh sebelum tanggal faktur {inv.number}.")
        if amount > outstanding(inv):
            raise AccountingError(
                f"Pembayaran faktur {inv.number} melebihi sisa tagihan ({outstanding(inv)}).")

    total = sum(alloc.values(), ZERO)
    number = next_number(session, "RCV", receipt_date.year)
    journal = post_system_journal(
        session, user, receipt_date, f"Penerimaan {number} - {customer.name}",
        [LineInput(cash.id, debit=total, description=f"Penerimaan {number}"),
         LineInput(receivable.id, credit=total, description=f"Penerimaan {number}")],
        source="RECEIPT")

    rc = SalesReceipt(number=number, customer_id=customer.id, receipt_date=receipt_date,
                      cash_account_id=cash.id, amount=total,
                      description=(description or "").strip() or None, status="POSTED",
                      journal_id=journal.id, created_by=user.id)
    for inv_id, amount in alloc.items():
        inv = invoices[inv_id]
        inv.paid_amount = inv.paid_amount + amount
        refresh_status(inv)
        rc.allocations.append(ReceiptAllocation(invoice_id=inv_id, amount=amount))
    session.add(rc)
    flush_checked(session)
    audit.log(session, user, "CREATE", "sales_receipt", rc.id, f"{number} total {total}")
    return rc


def void_receipt(session, user, receipt_id: int, reason="", void_date: date = None):
    require(user, "sales.void")
    rc = session.get(SalesReceipt, receipt_id, with_for_update=True)
    if rc is None:
        raise AccountingError("Penerimaan tidak ditemukan.")
    if rc.status == "VOID":
        raise AccountingError(f"Penerimaan {rc.number} sudah dibatalkan.")
    original = session.get(Journal, rc.journal_id, with_for_update=True)
    reversal = reverse_system_journal(
        session, user, original, f"penerimaan {rc.number} {reason or ''}".strip(), void_date)
    ids = [a.invoice_id for a in rc.allocations]
    invoices = {i.id: i for i in session.scalars(
        select(SalesInvoice).where(SalesInvoice.id.in_(ids)).with_for_update())}
    for a in rc.allocations:
        inv = invoices[a.invoice_id]
        inv.paid_amount = inv.paid_amount - a.amount
        refresh_status(inv)
    rc.status, rc.void_journal_id = "VOID", reversal.id
    flush_checked(session)
    audit.log(session, user, "VOID", "sales_receipt", rc.id, rc.number)
    return rc


def list_receipts(session, user, limit=300):
    require(user, "sales.view")
    stmt = (select(SalesReceipt)
            .options(selectinload(SalesReceipt.customer), selectinload(SalesReceipt.cash_account))
            .order_by(SalesReceipt.receipt_date.desc(), SalesReceipt.id.desc()).limit(limit))
    return [{"id": r.id, "number": r.number, "date": r.receipt_date, "party": r.customer.name,
             "customer": r.customer.name, "cash_account": f"{r.cash_account.code} - {r.cash_account.name}",
             "amount": r.amount, "status": r.status, "description": r.description or ""}
            for r in session.scalars(stmt)]


# ------------------------------------------------------------------ retur penjualan
def returnable_lines(session, user, invoice_id: int):
    require(user, "sales.view")
    inv = session.scalar(select(SalesInvoice).where(SalesInvoice.id == invoice_id)
                         .options(selectinload(SalesInvoice.lines)))
    if inv is None:
        raise AccountingError("Faktur tidak ditemukan.")
    return [{"line_id": l.id, "description": l.description, "quantity": l.quantity,
             "returned_qty": l.returned_qty, "remaining": l.quantity - l.returned_qty,
             "unit_price": l.unit_price} for l in inv.lines]


def create_return(session, user, invoice_id: int, return_date: date, lines, description=""):
    """Retur penjualan atas faktur. lines: daftar (invoice_line_id, jumlah).

    Jurnal: Dr Retur Penjualan (+ Dr Pajak) / Cr Piutang; barang berstok kembali masuk gudang
    pada nilai HPP aslinya (Dr Persediaan / Cr HPP). Nilai retur tidak boleh melebihi sisa tagihan.
    """
    require(user, "sales.post")
    inv = session.get(SalesInvoice, invoice_id, with_for_update=True)
    if inv is None or inv.status == "VOID":
        raise AccountingError("Faktur tidak ditemukan atau sudah dibatalkan.")
    if return_date < inv.invoice_date:
        raise AccountingError("Tanggal retur tidak boleh sebelum tanggal faktur.")
    by_id = {l.id: l for l in inv.lines}
    wanted = {}
    for line_id, qty in lines:
        qty = dec(qty, QTY, "Jumlah retur")
        if qty <= 0:
            continue
        if line_id in wanted:
            raise AccountingError("Satu baris faktur tidak boleh diretur dua kali dalam satu dokumen.")
        ln = by_id.get(line_id)
        if ln is None:
            raise AccountingError("Ada baris faktur yang tidak ditemukan.")
        if qty > ln.quantity - ln.returned_qty:
            raise AccountingError(f"Retur '{ln.description}' melebihi jumlah yang masih bisa diretur.")
        wanted[line_id] = qty
    if not wanted:
        raise AccountingError("Isi jumlah retur pada minimal satu baris.")

    items = inventory.lock_items(session, [by_id[i].item_id for i in wanted])
    rows = []
    for line_id, qty in wanted.items():
        ln = by_id[line_id]
        amount = (qty * ln.unit_price).quantize(CENT, rounding=ROUND_HALF_UP)
        cogs = ZERO
        if ln.cogs_amount and ln.quantity:
            cogs = (ln.cogs_amount * qty / ln.quantity).quantize(CENT, rounding=ROUND_HALF_UP)
        rows.append((ln, qty, amount, cogs))
    subtotal = sum((r[2] for r in rows), ZERO)
    tax = (subtotal * inv.tax_rate / 100).quantize(CENT, rounding=ROUND_HALF_UP)
    total = subtotal + tax
    if total > outstanding(inv):
        raise AccountingError(
            f"Nilai retur ({total}) melebihi sisa tagihan faktur ({outstanding(inv)}). "
            "Batalkan atau sesuaikan pembayaran faktur terlebih dahulu.")

    return_acc = setting_account(session, "sales_return_account", "Retur Penjualan")
    receivable = setting_account(session, "receivable_account", "Piutang Usaha")
    number = next_number(session, "SRT", return_date.year)
    jlines = [LineInput(return_acc.id, debit=subtotal, description=f"Retur {number}")]
    if tax > 0:
        tax_acc = setting_account(session, "tax_payable_account", "Pajak Keluaran")
        jlines.append(LineInput(tax_acc.id, debit=tax, description=f"Pajak retur {number}"))
    jlines.append(LineInput(receivable.id, credit=total, description=f"Retur {number}"))

    moves, cogs_total = [], ZERO
    for ln, qty, amount, cogs in rows:
        item = items.get(ln.item_id) if ln.item_id else None
        if item is not None and not item.is_service:
            moves.append(inventory.apply_movement(session, item, ln.warehouse_id, qty, cogs, return_date,
                                                  "RETURN", "SALES_RETURN", None, f"Retur {number}", user.id))
            cogs_total += cogs
    if cogs_total > 0:
        jlines.append(LineInput(setting_account(session, "inventory_account", "Persediaan Barang").id,
                                debit=cogs_total, description=f"Retur {number}"))
        jlines.append(LineInput(setting_account(session, "cogs_account", "Harga Pokok Penjualan").id,
                                credit=cogs_total, description=f"Retur {number}"))
    journal = post_system_journal(
        session, user, return_date, f"Retur penjualan {number} - {inv.customer.name}", jlines,
        source="SALES_RETURN")

    ret = SalesReturn(number=number, invoice_id=inv.id, return_date=return_date,
                      description=(description or "").strip() or None, subtotal=subtotal, tax_amount=tax,
                      total=total, status="POSTED", journal_id=journal.id, created_by=user.id)
    for ln, qty, amount, cogs in rows:
        ret.lines.append(SalesReturnLine(invoice_line_id=ln.id, quantity=qty, unit_price=ln.unit_price,
                                         amount=amount, cogs_amount=cogs))
        ln.returned_qty = ln.returned_qty + qty
    inv.returned_amount = (inv.returned_amount or ZERO) + total
    refresh_status(inv)
    session.add(ret)
    flush_checked(session)
    for m in moves:
        m.ref_id = ret.id
    flush_checked(session)
    audit.log(session, user, "CREATE", "sales_return", ret.id, f"{number} total {total}")
    return ret


def void_return(session, user, return_id: int, reason="", void_date: date = None):
    require(user, "sales.void")
    ret = session.get(SalesReturn, return_id, with_for_update=True)
    if ret is None:
        raise AccountingError("Retur tidak ditemukan.")
    if ret.status == "VOID":
        raise AccountingError(f"Retur {ret.number} sudah dibatalkan.")
    inv = session.get(SalesInvoice, ret.invoice_id, with_for_update=True)
    when = void_date or date.today()
    original = session.get(Journal, ret.journal_id, with_for_update=True)
    reversal = reverse_system_journal(
        session, user, original, f"retur {ret.number} {reason or ''}".strip(), when)
    inventory.reverse_movements(session, user.id, "SALES_RETURN", ret.id, when)
    for rl in ret.lines:
        line = session.get(SalesInvoiceLine, rl.invoice_line_id)
        line.returned_qty = line.returned_qty - rl.quantity
    inv.returned_amount = (inv.returned_amount or ZERO) - ret.total
    refresh_status(inv)
    ret.status, ret.void_journal_id = "VOID", reversal.id
    flush_checked(session)
    audit.log(session, user, "VOID", "sales_return", ret.id, ret.number)
    return ret


def list_returns(session, user, limit=300):
    require(user, "sales.view")
    stmt = (select(SalesReturn).options(selectinload(SalesReturn.invoice).selectinload(SalesInvoice.customer))
            .order_by(SalesReturn.return_date.desc(), SalesReturn.id.desc()).limit(limit))
    return [{"id": r.id, "number": r.number, "date": r.return_date, "invoice": r.invoice.number,
             "party": r.invoice.customer.name, "total": r.total, "status": r.status}
            for r in session.scalars(stmt)]


# ------------------------------------------------------------------ nama seragam untuk layar generik
list_parties = list_customers
create_settlement = create_receipt
void_settlement = void_receipt
list_settlements = list_receipts
