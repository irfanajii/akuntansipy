"""Laporan keuangan. Setiap fungsi mengembalikan ReportSpec (tampil, cetak PDF, atau export Excel)."""
from collections import defaultdict
from datetime import date
from decimal import Decimal

from sqlalchemy import func, select
from sqlalchemy.orm import selectinload

from app.database.models import (
    Account, Journal, JournalLine, PaymentAllocation, PurchaseInvoice, PurchasePayment, PurchaseReturn,
    ReceiptAllocation, SalesInvoice, SalesReceipt, SalesReturn,
)
from app.reports.table_report import Column, ReportSpec, Row, fmt_date, fmt_money
from app.services import journals, settings
from app.services.auth import require
from app.services.errors import AccountingError

ZERO = Decimal("0.00")


# ------------------------------------------------------------------ helper
def _spec(session, title, subtitle, columns):
    return ReportSpec(title=title, subtitle=subtitle, company=settings.get(session, "company_name"),
                      columns=columns)


def _check_range(date_from, date_to):
    if date_from > date_to:
        raise AccountingError("Tanggal awal tidak boleh setelah tanggal akhir.")


def _all_accounts(session):
    return list(session.scalars(select(Account).order_by(Account.code)))


def _movements(session, date_from, date_to, exclude_closing=False):
    """{account_id: (total_debit, total_credit)} untuk jurnal dalam rentang (None = tanpa batas).

    exclude_closing=True mengabaikan jurnal penutup (untuk laporan laba rugi)."""
    stmt = (select(JournalLine.account_id, func.sum(JournalLine.debit), func.sum(JournalLine.credit))
            .join(Journal, Journal.id == JournalLine.journal_id))
    if date_from is not None:
        stmt = stmt.where(Journal.entry_date >= date_from)
    if date_to is not None:
        stmt = stmt.where(Journal.entry_date <= date_to)
    if exclude_closing:
        stmt = stmt.where(Journal.source != "CLOSING")
    stmt = stmt.group_by(JournalLine.account_id)
    return {aid: (Decimal(d or 0), Decimal(k or 0)) for aid, d, k in session.execute(stmt)}


def _net(acc, mv) -> Decimal:
    """Saldo/mutasi bersih menurut sisi normal akun."""
    d, k = mv.get(acc.id, (ZERO, ZERO))
    return d - k if acc.normal_balance == "D" else k - d


def _descendant_ids(accounts, codes) -> set:
    """ID akun yang kodenya ada di `codes` beserta semua turunannya."""
    by_parent = defaultdict(list)
    for a in accounts:
        by_parent[a.parent_id].append(a)
    result, stack = set(), [a for a in accounts if a.code in set(codes)]
    while stack:
        a = stack.pop()
        if a.id not in result:
            result.add(a.id)
            stack.extend(by_parent[a.id])
    return result


# ------------------------------------------------------------------ neraca saldo
def trial_balance_report(session, user, date_to: date) -> ReportSpec:
    tb = journals.trial_balance(session, user, date_to)  # cek izin reports.view
    spec = _spec(session, "Neraca Saldo", f"Per {fmt_date(date_to)}", [
        Column("Kode", 1.2), Column("Nama Akun", 5), Column("Mutasi Debit", 2, "money"),
        Column("Mutasi Kredit", 2, "money"), Column("Saldo Debit", 2, "money"),
        Column("Saldo Kredit", 2, "money")])
    for r in tb["rows"]:
        spec.rows.append(Row([r["code"], r["name"], r["debit"], r["credit"],
                              r["balance_debit"], r["balance_credit"]]))
    spec.rows.append(Row(["", "TOTAL", None, None, tb["total_debit"], tb["total_credit"]], "total"))
    spec.meta = {"balanced": tb["total_debit"] == tb["total_credit"]}
    if not spec.meta["balanced"]:
        spec.notes.append("PERHATIAN: total saldo debit dan kredit tidak sama.")
    return spec


# ------------------------------------------------------------------ buku besar
def general_ledger(session, user, account_id: int, date_from: date, date_to: date) -> ReportSpec:
    require(user, "reports.view")
    _check_range(date_from, date_to)
    acc = session.get(Account, account_id)
    if acc is None:
        raise AccountingError("Akun tidak ditemukan.")
    sign = 1 if acc.normal_balance == "D" else -1

    opening_row = session.execute(
        select(func.sum(JournalLine.debit), func.sum(JournalLine.credit))
        .join(Journal, Journal.id == JournalLine.journal_id)
        .where(JournalLine.account_id == acc.id, Journal.entry_date < date_from)).one()
    opening = sign * (Decimal(opening_row[0] or 0) - Decimal(opening_row[1] or 0))

    spec = _spec(session, f"Buku Besar - {acc.code} {acc.name}",
                 f"Periode {fmt_date(date_from)} s.d. {fmt_date(date_to)}", [
                     Column("Tanggal", 1.4, "date"), Column("Nomor", 2), Column("Keterangan", 5),
                     Column("Debit", 2, "money"), Column("Kredit", 2, "money"), Column("Saldo", 2, "money")])
    spec.rows.append(Row(["", "", "Saldo awal", None, None, opening], "subtotal"))

    stmt = (select(Journal.entry_date, Journal.number, Journal.description, JournalLine.description,
                   JournalLine.debit, JournalLine.credit)
            .join(Journal, Journal.id == JournalLine.journal_id)
            .where(JournalLine.account_id == acc.id, Journal.entry_date >= date_from,
                   Journal.entry_date <= date_to)
            .order_by(Journal.entry_date, Journal.id, JournalLine.id))
    balance, tot_d, tot_k = opening, ZERO, ZERO
    for d, number, jdesc, ldesc, debit, credit in session.execute(stmt):
        debit, credit = Decimal(debit or 0), Decimal(credit or 0)
        balance += sign * (debit - credit)
        tot_d += debit
        tot_k += credit
        spec.rows.append(Row([d, number, ldesc or jdesc, debit or None, credit or None, balance]))
    spec.rows.append(Row(["", "", "Total mutasi / saldo akhir", tot_d, tot_k, balance], "total"))
    spec.meta = {"opening": opening, "closing": balance}
    return spec


# ------------------------------------------------------------------ laba rugi
def income_statement(session, user, date_from: date, date_to: date) -> ReportSpec:
    require(user, "reports.view")
    _check_range(date_from, date_to)
    accounts = _all_accounts(session)
    mv = _movements(session, date_from, date_to, exclude_closing=True)
    cogs_ids = _descendant_ids(accounts, settings.get_list(session, "cogs_parents"))

    revenue, cogs, expenses = [], [], []
    for a in accounts:
        if a.is_header or a.type not in ("REVENUE", "EXPENSE"):
            continue
        amount = _net(a, mv)
        if amount == 0:
            continue
        if a.type == "REVENUE":
            revenue.append((a, amount))
        else:
            (cogs if a.id in cogs_ids else expenses).append((a, amount))

    spec = _spec(session, "Laporan Laba Rugi", f"Periode {fmt_date(date_from)} s.d. {fmt_date(date_to)}",
                 [Column("Kode", 1.2), Column("Keterangan", 6), Column("Jumlah", 2.5, "money")])

    def section(title, items, total_label):
        spec.rows.append(Row(["", title, None], "section"))
        for a, amt in items:
            spec.rows.append(Row([a.code, a.name, amt], "normal", 1))
        total = sum((amt for _, amt in items), ZERO)
        spec.rows.append(Row(["", total_label, total], "subtotal"))
        return total

    total_rev = section("PENDAPATAN", revenue, "Total Pendapatan")
    total_cogs = ZERO
    if cogs:
        total_cogs = section("HARGA POKOK PENJUALAN", cogs, "Total Harga Pokok Penjualan")
        spec.rows.append(Row(["", "LABA KOTOR", total_rev - total_cogs], "total"))
    total_exp = section("BEBAN", expenses, "Total Beban")
    net = total_rev - total_cogs - total_exp
    spec.rows.append(Row(["", "LABA (RUGI) BERSIH", net], "total"))
    spec.meta = {"revenue": total_rev, "cogs": total_cogs, "expenses": total_exp, "net_income": net}
    return spec


# ------------------------------------------------------------------ neraca
def balance_sheet(session, user, as_of: date) -> ReportSpec:
    require(user, "reports.view")
    accounts = _all_accounts(session)
    mv = _movements(session, None, as_of)
    children = defaultdict(list)
    for a in accounts:
        children[a.parent_id].append(a)

    def build(acc, level, out) -> Decimal:
        kids = children[acc.id]
        if acc.is_header or kids:
            sub, total = [], ZERO
            for k in kids:
                total += build(k, level + 1, sub)
            if not sub:
                return ZERO
            out.append(Row([acc.code, acc.name, None], "section", level))
            out.extend(sub)
            out.append(Row(["", f"Total {acc.name}", total], "subtotal", level))
            return total
        amount = _net(acc, mv)
        if amount == 0:
            return ZERO
        out.append(Row([acc.code, acc.name, amount], "normal", level))
        return amount

    spec = _spec(session, "Neraca", f"Per {fmt_date(as_of)}",
                 [Column("Kode", 1.2), Column("Keterangan", 6), Column("Jumlah", 2.5, "money")])

    def section(typ, title):
        out, total = [], ZERO
        for root in [a for a in accounts if a.type == typ and a.parent_id is None]:
            total += build(root, 1, out)
        spec.rows.append(Row(["", title, None], "section"))
        spec.rows.extend(out)
        return total

    total_assets = section("ASSET", "ASET")
    spec.rows.append(Row(["", "TOTAL ASET", total_assets], "total"))
    total_liab = section("LIABILITY", "KEWAJIBAN")
    spec.rows.append(Row(["", "TOTAL KEWAJIBAN", total_liab], "subtotal"))
    equity_start = len(spec.rows)
    total_equity = section("EQUITY", "MODAL")

    earnings = ZERO
    for a in accounts:
        if not a.is_header and a.type in ("REVENUE", "EXPENSE"):
            amount = _net(a, mv)
            earnings += amount if a.type == "REVENUE" else -amount
    spec.rows.append(Row(["", "Laba (Rugi) Berjalan (kumulatif)", earnings], "normal", 1))
    total_equity += earnings
    spec.rows.append(Row(["", "TOTAL MODAL", total_equity], "subtotal"))
    spec.rows.append(Row(["", "TOTAL KEWAJIBAN DAN MODAL", total_liab + total_equity], "total"))

    balanced = total_assets == total_liab + total_equity
    spec.meta = {"total_assets": total_assets, "total_liabilities": total_liab,
                 "total_equity": total_equity, "earnings": earnings, "balanced": balanced}
    spec.notes.append("Laba (rugi) berjalan dihitung kumulatif dari seluruh jurnal sampai tanggal laporan "
                      "(belum ada proses tutup buku tahunan).")
    if not balanced:
        spec.notes.append(f"PERHATIAN: neraca tidak seimbang, selisih "
                          f"{fmt_money(total_assets - total_liab - total_equity)}. Periksa jurnal dan "
                          "klasifikasi akun.")
    return spec


# ------------------------------------------------------------------ arus kas
def cash_flow(session, user, date_from: date, date_to: date) -> ReportSpec:
    """Metode langsung sederhana: setiap jurnal yang menyentuh akun kas/bank dibagi ke akun lawannya."""
    require(user, "reports.view")
    _check_range(date_from, date_to)
    accounts = _all_accounts(session)
    by_id = {a.id: a for a in accounts}
    cash_ids = {i for i in _descendant_ids(accounts, settings.get_list(session, "cash_parent"))
                if not by_id[i].is_header}
    if not cash_ids:
        raise AccountingError("Akun Kas dan Bank belum diatur. Periksa 'Header Kas & Bank' di Pengaturan.")
    cash_list = sorted(cash_ids)
    investing = _descendant_ids(accounts, settings.get_list(session, "investing_parents"))
    financing = _descendant_ids(accounts, settings.get_list(session, "financing_parents"))

    def cash_sum(where):
        row = session.execute(
            select(func.sum(JournalLine.debit), func.sum(JournalLine.credit))
            .join(Journal, Journal.id == JournalLine.journal_id)
            .where(JournalLine.account_id.in_(cash_list), *where)).one()
        return Decimal(row[0] or 0) - Decimal(row[1] or 0)

    opening = cash_sum([Journal.entry_date < date_from])
    net_change = cash_sum([Journal.entry_date >= date_from, Journal.entry_date <= date_to])

    touching = select(JournalLine.journal_id).where(JournalLine.account_id.in_(cash_list))
    stmt = (select(JournalLine.account_id, func.sum(JournalLine.debit), func.sum(JournalLine.credit))
            .join(Journal, Journal.id == JournalLine.journal_id)
            .where(Journal.entry_date >= date_from, Journal.entry_date <= date_to,
                   JournalLine.journal_id.in_(touching), JournalLine.account_id.not_in(cash_list))
            .group_by(JournalLine.account_id))
    groups = {"OPERATING": [], "INVESTING": [], "FINANCING": []}
    for aid, d, k in session.execute(stmt):
        effect = Decimal(k or 0) - Decimal(d or 0)  # kredit di akun lawan = kas masuk
        if effect == 0:
            continue
        kind = "INVESTING" if aid in investing else "FINANCING" if aid in financing else "OPERATING"
        groups[kind].append((by_id[aid], effect))

    spec = _spec(session, "Laporan Arus Kas", f"Periode {fmt_date(date_from)} s.d. {fmt_date(date_to)}",
                 [Column("Kode", 1.2), Column("Keterangan", 6), Column("Jumlah", 2.5, "money")])
    titles = {"OPERATING": "ARUS KAS DARI AKTIVITAS OPERASI", "INVESTING": "ARUS KAS DARI AKTIVITAS INVESTASI",
              "FINANCING": "ARUS KAS DARI AKTIVITAS PENDANAAN"}
    subtotal_titles = {"OPERATING": "Kas bersih dari aktivitas operasi",
                       "INVESTING": "Kas bersih dari aktivitas investasi",
                       "FINANCING": "Kas bersih dari aktivitas pendanaan"}
    total_effect = ZERO
    for kind in ("OPERATING", "INVESTING", "FINANCING"):
        spec.rows.append(Row(["", titles[kind], None], "section"))
        items = sorted(groups[kind], key=lambda x: x[0].code)
        for a, eff in items:
            spec.rows.append(Row([a.code, a.name, eff], "normal", 1))
        subtotal = sum((e for _, e in items), ZERO)
        total_effect += subtotal
        spec.rows.append(Row(["", subtotal_titles[kind], subtotal], "subtotal"))
    spec.rows.append(Row(["", "KENAIKAN (PENURUNAN) KAS BERSIH", net_change], "total"))
    spec.rows.append(Row(["", "Saldo kas awal periode", opening], "normal"))
    spec.rows.append(Row(["", "SALDO KAS AKHIR PERIODE", opening + net_change], "total"))
    spec.meta = {"opening": opening, "net_change": net_change, "closing": opening + net_change,
                 "reconciled": total_effect == net_change}
    spec.notes.append("Klasifikasi aktivitas mengikuti pengaturan header akun investasi dan pendanaan; "
                      "akun lainnya dianggap aktivitas operasi. Angka positif = kas masuk.")
    if total_effect != net_change:
        spec.notes.append("PERHATIAN: rincian tidak sama dengan perubahan kas "
                          f"(selisih {fmt_money(net_change - total_effect)}). Periksa jurnal.")
    return spec


# ------------------------------------------------------------------ piutang/hutang & penjualan/pembelian
_TRADE = {
    "sales": dict(invoice=SalesInvoice, alloc=ReceiptAllocation, alloc_fk="receipt_id", settle=SalesReceipt,
                  settle_date="receipt_date", ret=SalesReturn, party="customer", gl_key="receivable_account",
                  aging_title="Umur Piutang", total_label="TOTAL PIUTANG", gl_label="piutang",
                  report_title="Laporan Penjualan", party_col="Pelanggan"),
    "purchase": dict(invoice=PurchaseInvoice, alloc=PaymentAllocation, alloc_fk="payment_id",
                     settle=PurchasePayment, settle_date="payment_date", ret=PurchaseReturn, party="supplier",
                     gl_key="payable_account", aging_title="Umur Hutang", total_label="TOTAL HUTANG",
                     gl_label="hutang", report_title="Laporan Pembelian", party_col="Pemasok"),
}


def _aging(session, user, as_of: date, kind: str) -> ReportSpec:
    require(user, "reports.view")
    cfg = _TRADE[kind]
    A, S, R, Inv = cfg["alloc"], cfg["settle"], cfg["ret"], cfg["invoice"]
    paid_stmt = (select(A.invoice_id, func.sum(A.amount)).join(S, S.id == getattr(A, cfg["alloc_fk"]))
                 .where(S.status == "POSTED", getattr(S, cfg["settle_date"]) <= as_of).group_by(A.invoice_id))
    paid = {iid: Decimal(v or 0) for iid, v in session.execute(paid_stmt)}
    ret_stmt = (select(R.invoice_id, func.sum(R.total))
                .where(R.status == "POSTED", R.return_date <= as_of).group_by(R.invoice_id))
    returned = {iid: Decimal(v or 0) for iid, v in session.execute(ret_stmt)}
    invoices = list(session.scalars(
        select(Inv).options(selectinload(getattr(Inv, cfg["party"])))
        .where(Inv.status != "VOID", Inv.invoice_date <= as_of).order_by(Inv.due_date, Inv.id)))

    spec = _spec(session, cfg["aging_title"], f"Per {fmt_date(as_of)}", [
        Column("Faktur", 2.2), Column("Tgl Faktur", 1.6, "date"), Column("Jatuh Tempo", 1.6, "date"),
        Column("Belum JT", 2, "money"), Column("1-30 hari", 2, "money"), Column("31-60 hari", 2, "money"),
        Column("61-90 hari", 2, "money"), Column(">90 hari", 2, "money"), Column("Total", 2.2, "money")])

    by_party, grand = defaultdict(list), [ZERO] * 5
    for inv in invoices:
        out = inv.total - paid.get(inv.id, ZERO) - returned.get(inv.id, ZERO)
        if out > 0:
            by_party[getattr(inv, cfg["party"]).name].append((inv, out))
    for name in sorted(by_party):
        spec.rows.append(Row([name] + [None] * 8, "section"))
        sums = [ZERO] * 5
        for inv, out in by_party[name]:
            days = (as_of - inv.due_date).days
            b = 0 if days <= 0 else 1 if days <= 30 else 2 if days <= 60 else 3 if days <= 90 else 4
            buckets = [None] * 5
            buckets[b] = out
            sums[b] += out
            spec.rows.append(Row([inv.number, inv.invoice_date, inv.due_date] + buckets + [out], "normal", 1))
        spec.rows.append(Row([f"Subtotal {name}", None, None] + sums + [sum(sums, ZERO)], "subtotal"))
        grand = [g + s_ for g, s_ in zip(grand, sums)]
    spec.rows.append(Row([cfg["total_label"], None, None] + grand + [sum(grand, ZERO)], "total"))

    gl_acc = session.scalar(select(Account).where(Account.code == settings.get(session, cfg["gl_key"])))
    spec.meta = {"total": sum(grand, ZERO)}
    if gl_acc is not None:
        gl_balance = _net(gl_acc, _movements(session, None, as_of))
        spec.meta["gl_balance"] = gl_balance
        if gl_balance != spec.meta["total"]:
            spec.notes.append(
                f"PERHATIAN: saldo akun {cfg['gl_label']} di buku besar ({fmt_money(gl_balance)}) berbeda dengan "
                f"total rincian faktur ({fmt_money(spec.meta['total'])}). Kemungkinan ada jurnal manual ke akun tersebut.")
    return spec


def _trade_report(session, user, date_from: date, date_to: date, kind: str) -> ReportSpec:
    require(user, "reports.view")
    _check_range(date_from, date_to)
    cfg = _TRADE[kind]
    Inv = cfg["invoice"]
    invoices = session.scalars(
        select(Inv).options(selectinload(getattr(Inv, cfg["party"])))
        .where(Inv.invoice_date >= date_from, Inv.invoice_date <= date_to)
        .order_by(Inv.invoice_date, Inv.id))
    spec = _spec(session, cfg["report_title"], f"Periode {fmt_date(date_from)} s.d. {fmt_date(date_to)}", [
        Column("Faktur", 2.2), Column("Tanggal", 1.5, "date"), Column(cfg["party_col"], 4),
        Column("Subtotal", 2.2, "money"), Column("Pajak", 2, "money"), Column("Total", 2.2, "money"),
        Column("Status", 2)])
    tot_s = tot_t = tot_all = ZERO
    for inv in invoices:
        spec.rows.append(Row([inv.number, inv.invoice_date, getattr(inv, cfg["party"]).name, inv.subtotal,
                              inv.tax_amount, inv.total, "Dibatalkan" if inv.status == "VOID" else
                              ("Lunas" if inv.status == "PAID" else "Belum lunas")]))
        if inv.status != "VOID":
            tot_s += inv.subtotal
            tot_t += inv.tax_amount
            tot_all += inv.total
    spec.rows.append(Row(["TOTAL", None, None, tot_s, tot_t, tot_all, None], "total"))
    spec.notes.append("Faktur yang dibatalkan tidak dihitung dalam total. Retur tidak mengurangi total ini.")
    spec.meta = {"subtotal": tot_s, "tax": tot_t, "total": tot_all}
    return spec


def receivable_aging(session, user, as_of: date) -> ReportSpec:
    return _aging(session, user, as_of, "sales")


def payable_aging(session, user, as_of: date) -> ReportSpec:
    return _aging(session, user, as_of, "purchase")


def sales_report(session, user, date_from: date, date_to: date) -> ReportSpec:
    return _trade_report(session, user, date_from, date_to, "sales")


def purchase_report(session, user, date_from: date, date_to: date) -> ReportSpec:
    return _trade_report(session, user, date_from, date_to, "purchase")
