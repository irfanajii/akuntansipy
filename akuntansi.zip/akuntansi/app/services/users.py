"""Manajemen user, role, dan log audit."""
import re

from sqlalchemy import func, select

from app.database.models import AuditLog, Role, User
from app.services import audit
from app.services.auth import CurrentUser, hash_password, require, verify_password
from app.services.errors import AccountingError, flush_checked
from app.services.permissions import PERMISSIONS

USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,50}$")


def _check_password(pw: str):
    if len(pw or "") < 8:
        raise AccountingError("Password minimal 8 karakter.")


def list_users(session, user):
    require(user, "users.manage")
    return [{"id": u.id, "username": u.username, "full_name": u.full_name, "role_id": u.role_id,
             "role": u.role.name, "is_active": u.is_active}
            for u in session.scalars(select(User).order_by(User.username))]


def list_roles(session, user):
    require(user, "users.manage")
    return [{"id": r.id, "name": r.name,
             "permissions": ["*"] if r.permissions == "*" else
             sorted(p.strip() for p in (r.permissions or "").split(",") if p.strip())}
            for r in session.scalars(select(Role).order_by(Role.name))]


def _active_admins(session) -> int:
    return session.scalar(
        select(func.count()).select_from(User).join(Role, Role.id == User.role_id)
        .where(User.is_active.is_(True), Role.permissions == "*"))


def create_user(session, user, *, username, full_name, password, role_id):
    require(user, "users.manage")
    username = (username or "").strip()
    if not USERNAME_RE.match(username):
        raise AccountingError("Username 3-50 karakter: huruf, angka, titik, garis bawah, atau strip.")
    if not (full_name or "").strip():
        raise AccountingError("Nama lengkap wajib diisi.")
    _check_password(password)
    if session.get(Role, role_id) is None:
        raise AccountingError("Role tidak ditemukan.")
    if session.scalar(select(User.id).where(func.lower(User.username) == username.lower())):
        raise AccountingError(f"Username {username} sudah dipakai.")
    u = User(username=username, full_name=full_name.strip(), password_hash=hash_password(password),
             role_id=role_id, is_active=True)
    session.add(u)
    flush_checked(session)
    audit.log(session, user, "CREATE", "user", u.id, username)
    return u


def update_user(session, user, user_id, *, full_name, role_id, is_active, new_password=None):
    require(user, "users.manage")
    u = session.get(User, user_id)
    if u is None:
        raise AccountingError("User tidak ditemukan.")
    if not (full_name or "").strip():
        raise AccountingError("Nama lengkap wajib diisi.")
    role = session.get(Role, role_id)
    if role is None:
        raise AccountingError("Role tidak ditemukan.")
    if u.id == user.id and not is_active:
        raise AccountingError("Anda tidak bisa menonaktifkan akun Anda sendiri.")
    was_admin = u.is_active and u.role.permissions == "*"
    u.full_name, u.role, u.is_active = full_name.strip(), role, is_active
    session.flush()
    if was_admin and _active_admins(session) < 1:
        raise AccountingError("Minimal harus ada satu user Administrator yang aktif.")
    if new_password:
        _check_password(new_password)
        u.password_hash = hash_password(new_password)
    flush_checked(session)
    audit.log(session, user, "UPDATE", "user", u.id, u.username)
    return u


def change_password(session, user: CurrentUser, old_password: str, new_password: str):
    u = session.get(User, user.id)
    if u is None or not verify_password(old_password or "", u.password_hash):
        raise AccountingError("Password lama salah.")
    _check_password(new_password)
    u.password_hash = hash_password(new_password)
    flush_checked(session)
    audit.log(session, user, "PASSWORD", "user", u.id, u.username)


def save_role(session, user, *, name, permissions, role_id=None):
    """Membuat/mengubah role. Role Administrator ('*') tidak bisa diubah."""
    require(user, "users.manage")
    name = (name or "").strip()
    if not name:
        raise AccountingError("Nama role wajib diisi.")
    unknown = [p for p in permissions if p not in PERMISSIONS]
    if unknown:
        raise AccountingError("Izin tidak dikenal: " + ", ".join(unknown))
    perms = ",".join(sorted(set(permissions)))
    if role_id is None:
        if session.scalar(select(Role.id).where(Role.name == name)):
            raise AccountingError(f"Role {name} sudah ada.")
        role = Role(name=name, permissions=perms)
        session.add(role)
    else:
        role = session.get(Role, role_id)
        if role is None:
            raise AccountingError("Role tidak ditemukan.")
        if role.permissions == "*":
            raise AccountingError("Role Administrator tidak bisa diubah.")
        clash = session.scalar(select(Role.id).where(Role.name == name, Role.id != role.id))
        if clash:
            raise AccountingError(f"Role {name} sudah ada.")
        role.name, role.permissions = name, perms
    flush_checked(session)
    audit.log(session, user, "SAVE", "role", role.id, f"{name}: {perms}")
    return role


def list_audit(session, user, limit=500, entity=None):
    require(user, "audit.view")
    stmt = (select(AuditLog, User.username).join(User, User.id == AuditLog.user_id, isouter=True)
            .order_by(AuditLog.id.desc()).limit(limit))
    if entity:
        stmt = stmt.where(AuditLog.entity == entity)
    return [{"id": a.id, "time": a.created_at, "user": uname or "-", "action": a.action,
             "entity": a.entity, "entity_id": a.entity_id or "", "detail": a.detail or ""}
            for a, uname in session.execute(stmt)]
