"""Login, hash password, dan pengecekan hak akses."""
import hashlib
import hmac
import os
from dataclasses import dataclass

from sqlalchemy import select

from app.database.models import User
from app.services.errors import PermissionDenied

_ITERATIONS = 200_000


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, _ITERATIONS)
    return f"pbkdf2_sha256${_ITERATIONS}${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, iters, salt_hex, hash_hex = stored.split("$")
        dk = hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iters)
        )
        return hmac.compare_digest(dk.hex(), hash_hex)
    except (ValueError, AttributeError):
        return False


@dataclass(frozen=True)
class CurrentUser:
    id: int
    username: str
    full_name: str
    role: str
    permissions: frozenset

    def can(self, permission: str) -> bool:
        return "*" in self.permissions or permission in self.permissions


def require(user: CurrentUser, permission: str) -> None:
    """Dicek di service (bukan hanya di tampilan)."""
    if not user.can(permission):
        raise PermissionDenied(f"Anda tidak memiliki hak akses: {permission}")


def authenticate(session, username: str, password: str):
    user = session.scalar(select(User).where(User.username == username.strip()))
    if user is None or not user.is_active or not verify_password(password, user.password_hash):
        return None
    perms = frozenset(p.strip() for p in (user.role.permissions or "").split(",") if p.strip())
    return CurrentUser(user.id, user.username, user.full_name, user.role.name, perms)


def require_any(user: CurrentUser, *permissions: str) -> None:
    if not any(user.can(p) for p in permissions):
        raise PermissionDenied("Anda tidak memiliki hak akses: " + " / ".join(permissions))
