"""Laporan tambahan: kartu stok, nilai persediaan, daftar aset tetap, rekap pajak."""
from datetime import date
from decimal import Decimal

from sqlalchemy import func, select

from app.database.models import (
    Account, DepreciationEntry, FixedAsset, Item, PurchaseInvoice, SalesInvoice, StockMovement, Warehouse,
)
from app.reports.table_report import Column, ReportSpec, Row, fmt_date, fmt_money
from app.services import settings
from app.services.auth import require
from app.services.errors import AccountingError
from app.services.reports import _check_range, _movements, _net, _spec

ZERO = Decimal("0.00")
KIND_LABELS = {"PURCHASE": "Pembelian", "SALE": "Penjualan", "ADJUST": "Penyesuaian", "TRANSFER": "Transfer",
               "RETURN": "Retur", "VOID": "Pembatalan"}


def stock_card(session, user, item_id: int, date_from: date, date_to: date, warehouse_id: int = None) -> ReportSpec:
    require(user, "reports.view")
    _check_range(date_from, date_to)
    item = session.get(Item, item_id)
    if item is None:
        raise AccountingError("Barang tidak ditemukan.")
    base = [StockMovement.item_id == item.id]
    scope = "semua gudang"
    if warehouse_id:
        wh = session.get(Warehouse, warehouse_id)
        base.append(StockMovement.warehouse_id == warehouse_id)
        scope = f"gudang {wh.name}" if wh else scope
    row = session.execute(select(func.sum(StockMovement.qty), func.sum(StockMovement.value)).where(
        *base, StockMovement.move_date < date_from)).one()
    qty, val = Decimal(row[0] or 0), Decimal(row[1] or 0)

    spec = _spec(session, f"Kartu Stok - {item.code} {item.name}",
                 f"Periode {fmt_date(date_from)} s.d. {fmt_date(date_to)} ({scope})", [
                     Column("Tanggal", 1.4, "date"), Column("Jenis", 1.6), Column("Keterangan", 4),
                     Column("Masuk", 1.5, "qty"), Column("Keluar", 1.5, "qty"), Column("Nilai", 2, "money"),
                     Column("Saldo Qty", 1.7, "qty"), Column("Saldo Nilai", 2.2, "money")])
    spec.rows.append(Row(["", "", "Saldo awal", None, None, None, qty, val], "subtotal"))
    stmt = (select(StockMovement).where(*base, StockMovement.move_date >= date_from,
                                        StockMovement.move_date <= date_to)
            .order_by(StockMovement.move_date, StockMovement.id))
    tot_in = tot_out = ZERO
    for m in session.scalars(stmt):
        qty += m.qty
        val += m.value
        if m.qty > 0:
            tot_in += m.qty
        else:
            tot_out += -m.qty
        spec.rows.append(Row([m.move_date, KIND_LABELS.get(m.kind, m.kind), m.note or m.ref_type or "",
                              m.qty if m.qty > 0 else None, -m.qty if m.qty < 0 else None, m.value, qty, val]))
    spec.rows.append(Row(["", "", "Total / saldo akhir", tot_in, tot_out, None, qty, val], "total"))
    spec.meta = {"closing_qty": qty, "closing_value": val}
    return spec


def stock_valuation(session, user, as_of: date) -> ReportSpec:
    require(user, "reports.view")
    stmt = (select(Item.code, Item.name, Item.unit, func.sum(StockMovement.qty), func.sum(StockMovement.value))
            .join(StockMovement, StockMovement.item_id == Item.id)
            .where(StockMovement.move_date <= as_of).group_by(Item.id, Item.code, Item.name, Item.unit)
            .order_by(Item.code))
    spec = _spec(session, "Nilai Persediaan", f"Per {fmt_date(as_of)}", [
        Column("Kode", 1.6), Column("Nama Barang", 5), Column("Satuan", 1.2), Column("Qty", 1.8, "qty"),
        Column("Harga Rata-rata", 2.2, "money"), Column("Nilai", 2.4, "money")])
    total = ZERO
    for code, name, unit, q, v in session.execute(stmt):
        q, v = Decimal(q or 0), Decimal(v or 0)
        if q == 0 and v == 0:
            continue
        avg = (v / q).quantize(Decimal("0.01")) if q else None
        spec.rows.append(Row([code, name, unit, q, avg, v]))
        total += v
    spec.rows.append(Row(["", "TOTAL NILAI PERSEDIAAN", "", None, None, total], "total"))
    spec.meta = {"total": total}
    acc = session.scalar(select(Account).where(Account.code == settings.get(session, "inventory_account")))
    if acc is not None:
        gl = _net(acc, _movements(session, None, as_of))
        spec.meta["gl_balance"] = gl
        if gl != total:
            spec.notes.append(f"PERHATIAN: saldo akun persediaan di buku besar ({fmt_money(gl)}) berbeda dengan "
                              f"nilai rincian stok ({fmt_money(total)}). Kemungkinan ada jurnal manual ke akun persediaan.")
    return spec


def asset_register(session, user, as_of: date) -> ReportSpec:
    require(user, "reports.view")
    dep = {aid: Decimal(v or 0) for aid, v in session.execute(
        select(DepreciationEntry.asset_id, func.sum(DepreciationEntry.amount))
        .where(DepreciationEntry.period_end <= as_of).group_by(DepreciationEntry.asset_id))}
    spec = _spec(session, "Daftar Aset Tetap", f"Per {fmt_date(as_of)}", [
        Column("Kode", 1.6), Column("Nama Aset", 4), Column("Tgl Perolehan", 1.7, "date"),
        Column("Harga Perolehan", 2.2, "money"), Column("Akum. Penyusutan", 2.2, "money"),
        Column("Nilai Buku", 2.2, "money")])
    tc = ta = ZERO
    stmt = select(FixedAsset).where(FixedAsset.acquisition_date <= as_of).order_by(FixedAsset.code)
    for a in session.scalars(stmt):
        if a.status == "DISPOSED" and a.disposal_date and a.disposal_date <= as_of:
            continue
        acc = dep.get(a.id, ZERO)
        spec.rows.append(Row([a.code, a.name, a.acquisition_date, a.cost, acc, a.cost - acc]))
        tc += a.cost
        ta += acc
    spec.rows.append(Row(["", "TOTAL", None, tc, ta, tc - ta], "total"))
    spec.meta = {"cost": tc, "accumulated": ta, "book_value": tc - ta}
    return spec


def tax_summary(session, user, date_from: date, date_to: date) -> ReportSpec:
    """Rekap pajak keluaran (penjualan) dan pajak masukan (pembelian). Bukan SPT/e-Faktur."""
    require(user, "reports.view")
    _check_range(date_from, date_to)
    spec = _spec(session, "Rekap Pajak Keluaran dan Masukan",
                 f"Periode {fmt_date(date_from)} s.d. {fmt_date(date_to)}", [
                     Column("Faktur", 2.2), Column("Tanggal", 1.5, "date"), Column("Lawan Transaksi", 4),
                     Column("DPP (Subtotal)", 2.4, "money"), Column("Pajak", 2.2, "money")])

    def section(title, model, party_attr, label):
        spec.rows.append(Row([title, None, None, None, None], "section"))
        stmt = (select(model).where(model.invoice_date >= date_from, model.invoice_date <= date_to,
                                    model.status != "VOID", model.tax_amount > 0)
                .order_by(model.invoice_date, model.id))
        dpp = tax = ZERO
        for inv in session.scalars(stmt):
            spec.rows.append(Row([inv.number, inv.invoice_date, getattr(inv, party_attr).name, inv.subtotal,
                                  inv.tax_amount], "normal", 1))
            dpp += inv.subtotal
            tax += inv.tax_amount
        spec.rows.append(Row([f"Total {label}", None, None, dpp, tax], "subtotal"))
        return tax

    out_tax = section("PAJAK KELUARAN (PENJUALAN)", SalesInvoice, "customer", "pajak keluaran")
    in_tax = section("PAJAK MASUKAN (PEMBELIAN)", PurchaseInvoice, "supplier", "pajak masukan")
    spec.rows.append(Row(["KURANG / (LEBIH) BAYAR", None, None, None, out_tax - in_tax], "total"))
    spec.meta = {"output": out_tax, "input": in_tax, "payable": out_tax - in_tax}
    spec.notes.append("Rekap dari faktur yang dicatat di aplikasi (belum memperhitungkan retur). Gunakan sebagai "
                      "bahan rekonsiliasi; bukan pengganti pelaporan pajak resmi.")
    return spec
