"""Aset tetap: daftar aset, penyusutan garis lurus bulanan, dan pelepasan aset."""
import calendar
from datetime import date
from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy import select

from app.database.models import Account, DepreciationEntry, FixedAsset, Journal
from app.services import audit
from app.services.auth import require
from app.services.errors import AccountingError, flush_checked
from app.services.journals import LineInput, post_system_journal, reverse_system_journal
from app.services.sequences import next_number
from app.services.trade_common import CENT, ZERO, dec, setting_account


def month_end(d: date) -> date:
    return date(d.year, d.month, calendar.monthrange(d.year, d.month)[1])


def _add_months(d: date, n: int) -> date:
    idx = d.year * 12 + (d.month - 1) + n
    return date(idx // 12, idx % 12 + 1, 1)


def period_end_for(asset, k: int) -> date:
    """Akhir bulan penyusutan ke-k (k=1 adalah bulan setelah bulan perolehan)."""
    return month_end(_add_months(asset.acquisition_date, k))


def monthly_amount(asset, k: int) -> Decimal:
    base = asset.cost - asset.salvage_value
    if k >= asset.life_months:
        return max(base - asset.accumulated, ZERO)
    return min((base / asset.life_months).quantize(CENT, rounding=ROUND_HALF_UP), max(base - asset.accumulated, ZERO))


def list_assets(session, user):
    require(user, "assets.view")
    return list(session.scalars(select(FixedAsset).order_by(FixedAsset.code)))


def _account(session, acc_id, setting_key, label, types):
    acc = session.get(Account, acc_id) if acc_id else setting_account(session, setting_key, label)
    if acc is None or acc.is_header or not acc.is_active or acc.type not in types:
        raise AccountingError(f"Akun {label} tidak valid.")
    return acc


def create_asset(session, user, *, code, name, acquisition_date: date, cost, salvage_value=0, life_months,
                 asset_account_id=None, accum_account_id=None, expense_account_id=None):
    """Mendaftarkan aset. Tidak membuat jurnal perolehan: catat perolehannya lewat faktur pembelian
    (baris akun aset tetap) atau jurnal manual."""
    require(user, "assets.edit")
    code, name = (code or "").strip(), (name or "").strip()
    if not code or not name:
        raise AccountingError("Kode dan nama aset wajib diisi.")
    if session.scalar(select(FixedAsset.id).where(FixedAsset.code == code)):
        raise AccountingError(f"Kode aset {code} sudah dipakai.")
    cost, salvage = dec(cost, CENT, "Harga perolehan"), dec(salvage_value, CENT, "Nilai sisa")
    if cost <= 0:
        raise AccountingError("Harga perolehan harus lebih dari nol.")
    if not (ZERO <= salvage < cost):
        raise AccountingError("Nilai sisa harus antara nol dan harga perolehan.")
    try:
        life = int(life_months)
    except (TypeError, ValueError):
        raise AccountingError("Umur ekonomis harus berupa angka (bulan).")
    if not (1 <= life <= 600):
        raise AccountingError("Umur ekonomis harus antara 1 dan 600 bulan.")
    a_acc = _account(session, asset_account_id, "fixed_asset_account", "aset tetap", ("ASSET",))
    ac_acc = _account(session, accum_account_id, "accum_depreciation_account", "akumulasi penyusutan", ("ASSET",))
    ex_acc = _account(session, expense_account_id, "depreciation_expense_account", "beban penyusutan", ("EXPENSE",))
    asset = FixedAsset(code=code, name=name, acquisition_date=acquisition_date, cost=cost, salvage_value=salvage,
                       life_months=life, asset_account_id=a_acc.id, accum_account_id=ac_acc.id,
                       expense_account_id=ex_acc.id, accumulated=ZERO, months_depreciated=0, status="ACTIVE",
                       created_by=user.id)
    session.add(asset)
    flush_checked(session)
    audit.log(session, user, "CREATE", "fixed_asset", asset.id, f"{code} {name} cost {cost}")
    return asset


def run_depreciation(session, user, through: date):
    """Posting penyusutan semua aset aktif sampai akhir bulan `through` (satu jurnal per bulan)."""
    require(user, "assets.edit")
    limit = month_end(through)
    assets = list(session.scalars(select(FixedAsset).where(FixedAsset.status == "ACTIVE")
                                  .order_by(FixedAsset.id).with_for_update()))
    pending = {}  # akhir bulan -> [(asset, k)]
    for a in assets:
        k = a.months_depreciated + 1
        while k <= a.life_months and period_end_for(a, k) <= limit:
            pending.setdefault(period_end_for(a, k), []).append((a, k))
            k += 1
    results = []
    for pend in sorted(pending):
        by_pair, total, rows = {}, ZERO, []
        for a, k in pending[pend]:
            amt = monthly_amount(a, k)
            if amt <= 0:
                a.months_depreciated = k
                continue
            by_pair[(a.expense_account_id, a.accum_account_id)] = by_pair.get(
                (a.expense_account_id, a.accum_account_id), ZERO) + amt
            rows.append((a, k, amt))
            a.accumulated = a.accumulated + amt
            a.months_depreciated = k
            total += amt
        if not rows:
            continue
        jlines = []
        for (ex_id, ac_id), amt in by_pair.items():
            jlines.append(LineInput(ex_id, debit=amt, description="Penyusutan"))
            jlines.append(LineInput(ac_id, credit=amt, description="Penyusutan"))
        try:
            journal = post_system_journal(session, user, pend, f"Penyusutan aset {pend:%m/%Y}", jlines,
                                          source="ASSET")
        except AccountingError as exc:
            raise AccountingError(f"Penyusutan {pend:%m/%Y}: {exc}") from exc
        for a, k, amt in rows:
            session.add(DepreciationEntry(asset_id=a.id, period_end=pend, amount=amt, journal_id=journal.id))
        results.append({"period_end": pend, "total": total, "journal": journal.number, "assets": len(rows)})
    flush_checked(session)
    if results:
        audit.log(session, user, "DEPRECIATE", "fixed_asset", None, f"s.d. {limit:%m/%Y}: {len(results)} bulan")
    return results


def reverse_depreciation(session, user, period_end: date):
    """Membatalkan penyusutan satu bulan. Hanya boleh untuk bulan terakhir dari setiap aset yang terlibat."""
    require(user, "assets.edit")
    entries = list(session.scalars(select(DepreciationEntry).where(DepreciationEntry.period_end == period_end)))
    if not entries:
        raise AccountingError("Tidak ada penyusutan pada bulan tersebut.")
    asset_ids = [e.asset_id for e in entries]
    later = session.scalar(select(DepreciationEntry.id).where(
        DepreciationEntry.asset_id.in_(asset_ids), DepreciationEntry.period_end > period_end).limit(1))
    if later:
        raise AccountingError("Batalkan dulu penyusutan bulan-bulan setelahnya (urut dari yang terbaru).")
    assets = {a.id: a for a in session.scalars(select(FixedAsset).where(FixedAsset.id.in_(asset_ids)).with_for_update())}
    for jid in {e.journal_id for e in entries}:
        original = session.get(Journal, jid, with_for_update=True)
        reverse_system_journal(session, user, original, f"penyusutan {period_end:%m/%Y}", period_end)
    for e in entries:
        a = assets[e.asset_id]
        a.accumulated = a.accumulated - e.amount
        a.months_depreciated = a.months_depreciated - 1
        session.delete(e)
    flush_checked(session)
    audit.log(session, user, "REVERSE", "fixed_asset", None, f"penyusutan {period_end:%m/%Y}")
    return len(entries)


def dispose_asset(session, user, asset_id: int, disposal_date: date, proceeds=0, cash_account_id=None):
    """Pelepasan aset (dijual/dihapuskan). Penyusutan harus sudah diposting sampai bulan sebelumnya."""
    require(user, "assets.edit")
    a = session.get(FixedAsset, asset_id, with_for_update=True)
    if a is None:
        raise AccountingError("Aset tidak ditemukan.")
    if a.status != "ACTIVE":
        raise AccountingError("Aset sudah dilepas.")
    if disposal_date < a.acquisition_date:
        raise AccountingError("Tanggal pelepasan tidak boleh sebelum tanggal perolehan.")
    k = a.months_depreciated + 1
    if k <= a.life_months and period_end_for(a, k) < disposal_date:
        raise AccountingError(
            f"Jalankan dulu penyusutan sampai {period_end_for(a, k):%m/%Y} sebelum melepas aset.")
    proceeds = dec(proceeds, CENT, "Hasil penjualan")
    if proceeds < 0:
        raise AccountingError("Hasil penjualan tidak boleh negatif.")
    lines = []
    if proceeds > 0:
        cash = session.get(Account, cash_account_id) if cash_account_id else None
        if cash is None or cash.is_header or not cash.is_active or cash.type != "ASSET":
            raise AccountingError("Pilih akun kas/bank untuk hasil penjualan.")
        lines.append(LineInput(cash.id, debit=proceeds, description=f"Pelepasan {a.code}"))
    if a.accumulated > 0:
        lines.append(LineInput(a.accum_account_id, debit=a.accumulated, description=f"Pelepasan {a.code}"))
    lines.append(LineInput(a.asset_account_id, credit=a.cost, description=f"Pelepasan {a.code}"))
    gain = proceeds - (a.cost - a.accumulated)
    if gain != 0:
        gl = setting_account(session, "disposal_gain_loss_account", "Laba/Rugi Pelepasan Aset")
        if gain > 0:
            lines.append(LineInput(gl.id, credit=gain, description=f"Laba pelepasan {a.code}"))
        else:
            lines.append(LineInput(gl.id, debit=-gain, description=f"Rugi pelepasan {a.code}"))
    journal = post_system_journal(session, user, disposal_date, f"Pelepasan aset {a.code} - {a.name}", lines,
                                  source="ASSET")
    a.status, a.disposal_date, a.disposal_journal_id = "DISPOSED", disposal_date, journal.id
    flush_checked(session)
    audit.log(session, user, "DISPOSE", "fixed_asset", a.id, f"{a.code} hasil {proceeds} laba/rugi {gain}")
    return a, gain
