"""Periode akuntansi: buat, tutup (opsional dengan jurnal penutup tahunan), dan buka kembali."""
from datetime import date, timedelta
from decimal import Decimal

from sqlalchemy import func, select

from app.database.models import Account, FiscalPeriod, Journal, JournalLine
from app.services import audit
from app.services.auth import require, require_any
from app.services.errors import AccountingError, flush_checked
from app.services.journals import LineInput, post_system_journal, reverse_system_journal
from app.services.trade_common import ZERO, setting_account


def list_periods(session, user):
    require_any(user, "reports.view", "periods.close")
    return [{"id": p.id, "name": p.name, "start": p.start_date, "end": p.end_date, "closed": p.is_closed,
             "has_closing": p.closing_journal_id is not None}
            for p in session.scalars(select(FiscalPeriod).order_by(FiscalPeriod.start_date))]


def create_period(session, user, name, start: date, end: date):
    require(user, "periods.close")
    name = (name or "").strip()
    if not name:
        raise AccountingError("Nama periode wajib diisi.")
    if start > end:
        raise AccountingError("Tanggal awal tidak boleh setelah tanggal akhir.")
    clash = session.scalar(select(FiscalPeriod).where(FiscalPeriod.start_date <= end, FiscalPeriod.end_date >= start))
    if clash is not None:
        raise AccountingError(f"Rentang tanggal bertabrakan dengan periode '{clash.name}'.")
    p = FiscalPeriod(name=name, start_date=start, end_date=end, is_closed=False)
    session.add(p)
    flush_checked(session)
    audit.log(session, user, "CREATE", "fiscal_period", p.id, name)
    return p


def _closing_journal(session, user, period):
    """Jurnal penutup: menolkan semua akun pendapatan/beban pada periode ke Laba Ditahan."""
    re_acc = setting_account(session, "retained_earnings_account", "Laba Ditahan")
    stmt = (select(JournalLine.account_id, func.sum(JournalLine.debit), func.sum(JournalLine.credit))
            .join(Journal, Journal.id == JournalLine.journal_id)
            .join(Account, Account.id == JournalLine.account_id)
            .where(Journal.entry_date >= period.start_date, Journal.entry_date <= period.end_date,
                   Journal.source != "CLOSING", Account.type.in_(("REVENUE", "EXPENSE")))
            .group_by(JournalLine.account_id))
    lines, debit, credit = [], ZERO, ZERO
    for aid, d, k in session.execute(stmt):
        bal = Decimal(d or 0) - Decimal(k or 0)
        if bal > 0:
            lines.append(LineInput(aid, credit=bal, description="Penutupan"))
            credit += bal
        elif bal < 0:
            lines.append(LineInput(aid, debit=-bal, description="Penutupan"))
            debit += -bal
    if not lines:
        return None
    diff = debit - credit  # > 0: laba (pendapatan > beban) -> kredit Laba Ditahan
    if diff > 0:
        lines.append(LineInput(re_acc.id, credit=diff, description="Laba/rugi periode"))
    elif diff < 0:
        lines.append(LineInput(re_acc.id, debit=-diff, description="Laba/rugi periode"))
    return post_system_journal(session, user, period.end_date, f"Jurnal penutup {period.name}", lines,
                               source="CLOSING")


def close_period(session, user, period_id: int, post_closing: bool = False):
    """Kunci periode. Dengan post_closing=True dibuat jurnal penutup (untuk akhir tahun buku)."""
    require(user, "periods.close")
    period = session.get(FiscalPeriod, period_id, with_for_update=True)
    if period is None:
        raise AccountingError("Periode tidak ditemukan.")
    if period.is_closed:
        raise AccountingError(f"Periode {period.name} sudah ditutup.")
    if post_closing:
        journal = _closing_journal(session, user, period)  # harus diposting sebelum periode dikunci
        period.closing_journal_id = journal.id if journal is not None else None
    period.is_closed = True
    flush_checked(session)
    # siapkan tahun berikutnya bila periode ini satu tahun kalender penuh
    if post_closing and period.start_date == date(period.start_date.year, 1, 1) \
            and period.end_date == date(period.start_date.year, 12, 31):
        nxt = period.start_date.year + 1
        if not session.scalar(select(FiscalPeriod.id).where(FiscalPeriod.start_date == date(nxt, 1, 1))):
            session.add(FiscalPeriod(name=f"Tahun {nxt}", start_date=date(nxt, 1, 1), end_date=date(nxt, 12, 31)))
            flush_checked(session)
    audit.log(session, user, "CLOSE", "fiscal_period", period.id, period.name)
    return period


def reopen_period(session, user, period_id: int):
    require(user, "periods.close")
    period = session.get(FiscalPeriod, period_id, with_for_update=True)
    if period is None:
        raise AccountingError("Periode tidak ditemukan.")
    if not period.is_closed:
        raise AccountingError(f"Periode {period.name} belum ditutup.")
    later = session.scalar(select(func.count()).select_from(FiscalPeriod).where(
        FiscalPeriod.start_date > period.end_date, FiscalPeriod.is_closed.is_(True)))
    if later:
        raise AccountingError("Buka dulu periode-periode setelahnya yang sudah ditutup (urut dari yang terbaru).")
    period.is_closed = False
    flush_checked(session)
    if period.closing_journal_id:
        original = session.get(Journal, period.closing_journal_id, with_for_update=True)
        reverse_system_journal(session, user, original, f"pembukaan kembali {period.name}", period.end_date,
                               source="CLOSING")
        period.closing_journal_id = None
        flush_checked(session)
    audit.log(session, user, "REOPEN", "fiscal_period", period.id, period.name)
    return period
