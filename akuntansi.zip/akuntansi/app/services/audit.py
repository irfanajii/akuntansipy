from app.database.models import AuditLog


def log(session, user, action, entity, entity_id=None, detail=None):
    session.add(
        AuditLog(
            user_id=user.id if user else None,
            action=action,
            entity=entity,
            entity_id=str(entity_id) if entity_id is not None else None,
            detail=detail,
        )
    )
