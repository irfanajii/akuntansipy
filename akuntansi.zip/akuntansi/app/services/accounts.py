"""Daftar akun (COA)."""
from sqlalchemy import func, select

from app.database.models import Account, JournalLine
from app.services import audit
from app.services.auth import require
from app.services.errors import AccountingError, ConflictError, flush_checked

NORMAL_BALANCE = {
    "ASSET": "D",
    "EXPENSE": "D",
    "LIABILITY": "K",
    "EQUITY": "K",
    "REVENUE": "K",
}


def list_accounts(session, user):
    require(user, "accounts.view")
    return list(session.scalars(select(Account).order_by(Account.code)))


def _validate_parent(session, parent_id, own_id=None):
    if parent_id is None:
        return
    parent = session.get(Account, parent_id)
    if parent is None or not parent.is_header:
        raise AccountingError("Akun induk harus berupa akun header.")
    # cegah lingkaran induk
    cur = parent
    while cur is not None:
        if own_id is not None and cur.id == own_id:
            raise AccountingError("Akun induk tidak valid (membentuk lingkaran).")
        cur = session.get(Account, cur.parent_id) if cur.parent_id else None


def _has_lines(session, account_id) -> bool:
    n = session.scalar(
        select(func.count()).select_from(JournalLine).where(JournalLine.account_id == account_id)
    )
    return bool(n)


def create_account(session, user, *, code, name, type, parent_id=None, is_header=False):
    require(user, "accounts.edit")
    code, name = (code or "").strip(), (name or "").strip()
    if not code or not name:
        raise AccountingError("Kode dan nama akun wajib diisi.")
    if type not in NORMAL_BALANCE:
        raise AccountingError("Tipe akun tidak valid.")
    if session.scalar(select(Account.id).where(Account.code == code)):
        raise AccountingError(f"Kode akun {code} sudah dipakai.")
    _validate_parent(session, parent_id)
    acc = Account(
        code=code, name=name, type=type, normal_balance=NORMAL_BALANCE[type],
        parent_id=parent_id, is_header=is_header, is_active=True,
    )
    session.add(acc)
    flush_checked(session)
    audit.log(session, user, "CREATE", "account", acc.id, f"{code} {name}")
    return acc


def update_account(session, user, account_id, *, name, type, parent_id, is_header,
                   is_active, expected_version):
    require(user, "accounts.edit")
    acc = session.get(Account, account_id, with_for_update=True)
    if acc is None:
        raise AccountingError("Akun tidak ditemukan.")
    if acc.version != expected_version:
        raise ConflictError("Akun ini sudah diubah pengguna lain. Muat ulang data lalu coba lagi.")
    name = (name or "").strip()
    if not name:
        raise AccountingError("Nama akun wajib diisi.")
    if type not in NORMAL_BALANCE:
        raise AccountingError("Tipe akun tidak valid.")
    if (type != acc.type or is_header != acc.is_header) and _has_lines(session, acc.id):
        raise AccountingError("Tipe/jenis akun tidak bisa diubah karena sudah dipakai di jurnal.")
    _validate_parent(session, parent_id, own_id=acc.id)
    acc.name, acc.type, acc.normal_balance = name, type, NORMAL_BALANCE[type]
    acc.parent_id, acc.is_header, acc.is_active = parent_id, is_header, is_active
    flush_checked(session)
    audit.log(session, user, "UPDATE", "account", acc.id, f"{acc.code} {name}")
    return acc
