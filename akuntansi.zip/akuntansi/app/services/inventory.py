"""Persediaan: barang, gudang, buku stok (rata-rata bergerak), penyesuaian, dan transfer.

Nilai persediaan dihitung dengan metode rata-rata bergerak berdasarkan URUTAN INPUT transaksi
(bukan tanggal). Qty dan nilai per barang disimpan di tabel items dan dikunci (SELECT ... FOR UPDATE)
saat berubah, sehingga aman dipakai beberapa komputer sekaligus.
"""
from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy import func, select

from app.database.models import Account, Item, StockMovement, Warehouse
from app.services import audit
from app.services.auth import require, require_any
from app.services.errors import AccountingError, ConflictError, flush_checked
from app.services.journals import LineInput, post_system_journal
from app.services.sequences import next_number
from app.services.trade_common import CENT, QTY, ZERO, dec, setting_account

TRADE_VIEW = ("inventory.view", "sales.view", "purchases.view")


# ------------------------------------------------------------------ gudang
def list_warehouses(session, user, include_inactive=True):
    require_any(user, *TRADE_VIEW)
    stmt = select(Warehouse).order_by(Warehouse.code)
    if not include_inactive:
        stmt = stmt.where(Warehouse.is_active.is_(True))
    return list(session.scalars(stmt))


def default_warehouse_id(session):
    return session.scalar(select(Warehouse.id).where(Warehouse.is_active.is_(True)).order_by(Warehouse.id).limit(1))


def create_warehouse(session, user, *, code, name):
    require(user, "inventory.edit")
    code, name = (code or "").strip(), (name or "").strip()
    if not code or not name:
        raise AccountingError("Kode dan nama gudang wajib diisi.")
    if session.scalar(select(Warehouse.id).where(Warehouse.code == code)):
        raise AccountingError(f"Kode gudang {code} sudah dipakai.")
    w = Warehouse(code=code, name=name, is_active=True)
    session.add(w)
    flush_checked(session)
    audit.log(session, user, "CREATE", "warehouse", w.id, f"{code} {name}")
    return w


def update_warehouse(session, user, warehouse_id, *, name, is_active):
    require(user, "inventory.edit")
    w = session.get(Warehouse, warehouse_id)
    if w is None:
        raise AccountingError("Gudang tidak ditemukan.")
    if not (name or "").strip():
        raise AccountingError("Nama gudang wajib diisi.")
    if not is_active and w.is_active and session.scalar(
            select(func.count()).select_from(Warehouse).where(Warehouse.is_active.is_(True))) <= 1:
        raise AccountingError("Minimal harus ada satu gudang aktif.")
    w.name, w.is_active = name.strip(), is_active
    flush_checked(session)
    audit.log(session, user, "UPDATE", "warehouse", w.id, w.code)
    return w


# ------------------------------------------------------------------ barang
def list_items(session, user, include_inactive=True):
    require_any(user, *TRADE_VIEW)
    stmt = select(Item).order_by(Item.code)
    if not include_inactive:
        stmt = stmt.where(Item.is_active.is_(True))
    return list(session.scalars(stmt))


def create_item(session, user, *, code, name, unit="pcs", sell_price=0, is_service=False):
    require(user, "inventory.edit")
    code, name = (code or "").strip(), (name or "").strip()
    if not code or not name:
        raise AccountingError("Kode dan nama barang wajib diisi.")
    if session.scalar(select(Item.id).where(Item.code == code)):
        raise AccountingError(f"Kode barang {code} sudah dipakai.")
    price = dec(sell_price, CENT, "Harga jual")
    if price < 0:
        raise AccountingError("Harga jual tidak boleh negatif.")
    item = Item(code=code, name=name, unit=(unit or "pcs").strip() or "pcs", sell_price=price,
                is_service=bool(is_service), is_active=True, qty_on_hand=ZERO, stock_value=ZERO)
    session.add(item)
    flush_checked(session)
    audit.log(session, user, "CREATE", "item", item.id, f"{code} {name}")
    return item


def update_item(session, user, item_id, *, name, unit, sell_price, is_service, is_active, expected_version):
    require(user, "inventory.edit")
    item = session.get(Item, item_id, with_for_update=True)
    if item is None:
        raise AccountingError("Barang tidak ditemukan.")
    if item.version != expected_version:
        raise ConflictError("Barang ini sudah diubah pengguna lain. Muat ulang data lalu coba lagi.")
    if not (name or "").strip():
        raise AccountingError("Nama barang wajib diisi.")
    price = dec(sell_price, CENT, "Harga jual")
    if price < 0:
        raise AccountingError("Harga jual tidak boleh negatif.")
    if bool(is_service) != item.is_service and session.scalar(
            select(func.count()).select_from(StockMovement).where(StockMovement.item_id == item.id)):
        raise AccountingError("Jenis barang/jasa tidak bisa diubah karena sudah ada mutasi stok.")
    item.name, item.unit, item.sell_price = name.strip(), (unit or "pcs").strip() or "pcs", price
    item.is_service, item.is_active = bool(is_service), is_active
    flush_checked(session)
    audit.log(session, user, "UPDATE", "item", item.id, item.code)
    return item


# ------------------------------------------------------------------ mutasi stok (tanpa cek izin: dipanggil modul lain)
def lock_items(session, ids) -> dict:
    """Kunci baris barang (urut ID agar tidak saling mengunci) dan muat nilai terbarunya."""
    session.flush()
    out = {}
    for iid in sorted({i for i in ids if i}):
        item = session.execute(
            select(Item).where(Item.id == iid).with_for_update()
            .execution_options(populate_existing=True)).scalar_one_or_none()
        if item is None:
            raise AccountingError("Barang tidak ditemukan.")
        out[iid] = item
    return out


def warehouse_qty(session, item_id, warehouse_id) -> Decimal:
    v = session.scalar(select(func.coalesce(func.sum(StockMovement.qty), 0)).where(
        StockMovement.item_id == item_id, StockMovement.warehouse_id == warehouse_id))
    return Decimal(str(v))


def apply_movement(session, item, warehouse_id, qty, value, move_date, kind, ref_type=None, ref_id=None,
                   note=None, user_id=None) -> StockMovement:
    """qty dan value bertanda (+ masuk, - keluar). `item` harus sudah dikunci lewat lock_items."""
    if item.is_service:
        raise AccountingError(f"{item.name} adalah jasa dan tidak memiliki stok.")
    if warehouse_id is None or session.get(Warehouse, warehouse_id) is None:
        raise AccountingError("Gudang tidak ditemukan.")
    if qty < 0:
        have = warehouse_qty(session, item.id, warehouse_id)
        if have + qty < 0:
            raise AccountingError(
                f"Stok {item.code} di gudang tidak cukup (tersedia {have.normalize():f}, diminta {(-qty).normalize():f}).")
    item.qty_on_hand = item.qty_on_hand + qty
    item.stock_value = item.stock_value + value
    m = StockMovement(item_id=item.id, warehouse_id=warehouse_id, move_date=move_date, qty=qty, value=value,
                      kind=kind, ref_type=ref_type, ref_id=ref_id, note=note, created_by=user_id)
    session.add(m)
    flush_checked(session)
    return m


def issue_at_average(session, item, warehouse_id, qty, move_date, kind, ref_type=None, ref_id=None,
                     note=None, user_id=None) -> StockMovement:
    """Barang keluar bernilai rata-rata. Mengembalikan mutasi (value negatif)."""
    qty = dec(qty, QTY, "Jumlah")
    if qty <= 0:
        raise AccountingError("Jumlah barang keluar harus lebih dari nol.")
    if qty > item.qty_on_hand:
        raise AccountingError(
            f"Stok {item.code} tidak cukup (total tersedia {item.qty_on_hand.normalize():f}, diminta {qty.normalize():f}).")
    if qty == item.qty_on_hand:
        value = item.stock_value  # habis: ambil seluruh sisa nilai (tanpa sisa pembulatan)
    else:
        value = (item.stock_value * qty / item.qty_on_hand).quantize(CENT, rounding=ROUND_HALF_UP)
    return apply_movement(session, item, warehouse_id, -qty, -value, move_date, kind, ref_type, ref_id,
                          note, user_id)


def reverse_movements(session, user_id, ref_type, ref_id, move_date):
    """Membalik semua mutasi sebuah dokumen persis pada nilai aslinya (untuk pembatalan dokumen)."""
    ms = list(session.scalars(select(StockMovement).where(
        StockMovement.ref_type == ref_type, StockMovement.ref_id == ref_id).order_by(StockMovement.id)))
    items = lock_items(session, [m.item_id for m in ms])
    out = []
    for m in reversed(ms):
        out.append(apply_movement(session, items[m.item_id], m.warehouse_id, -m.qty, -m.value, move_date,
                                  "VOID", f"{ref_type}_VOID", ref_id, f"Pembatalan mutasi #{m.id}", user_id))
    return out


# ------------------------------------------------------------------ penyesuaian & transfer
def adjust_stock(session, user, item_id, warehouse_id, adj_date, qty, unit_cost=None,
                 offset_account_id=None, note=""):
    """qty > 0: stok masuk (wajib unit_cost); qty < 0: stok keluar bernilai rata-rata.

    Jurnal: masuk = Dr Persediaan / Cr akun lawan; keluar = Dr akun lawan / Cr Persediaan.
    Akun lawan default = 'Selisih Persediaan'; untuk saldo awal pilih akun modal.
    """
    require(user, "inventory.edit")
    qty = dec(qty, QTY, "Jumlah")
    if qty == 0:
        raise AccountingError("Jumlah penyesuaian tidak boleh nol.")
    item = lock_items(session, [item_id]).get(item_id)
    if item is None:
        raise AccountingError("Barang tidak ditemukan.")
    inv_acc = setting_account(session, "inventory_account", "Persediaan Barang")
    if offset_account_id:
        offset = session.get(Account, offset_account_id)
        if offset is None or offset.is_header or not offset.is_active:
            raise AccountingError("Akun lawan tidak valid.")
    else:
        offset = setting_account(session, "inventory_adjust_account", "Selisih Persediaan")

    note = (note or "").strip()
    if qty > 0:
        if unit_cost is None or str(unit_cost).strip() == "":
            raise AccountingError("Harga pokok per unit wajib diisi untuk stok masuk.")
        cost = dec(unit_cost, CENT, "Harga pokok")
        if cost < 0:
            raise AccountingError("Harga pokok tidak boleh negatif.")
        value = (qty * cost).quantize(CENT, rounding=ROUND_HALF_UP)
        m = apply_movement(session, item, warehouse_id, qty, value, adj_date, "ADJUST", note=note or None,
                           user_id=user.id)
        lines = [LineInput(inv_acc.id, debit=value), LineInput(offset.id, credit=value)]
    else:
        m = issue_at_average(session, item, warehouse_id, -qty, adj_date, "ADJUST", note=note or None,
                             user_id=user.id)
        value = -m.value
        lines = [LineInput(offset.id, debit=value), LineInput(inv_acc.id, credit=value)]

    number = next_number(session, "ADJ", adj_date.year)
    if value > 0:
        journal = post_system_journal(
            session, user, adj_date, f"Penyesuaian stok {number} - {item.name}", lines, source="STOCK")
        m.ref_type, m.ref_id = "ADJUST", journal.id
    m.note = f"{number} {note}".strip()
    flush_checked(session)
    audit.log(session, user, "ADJUST", "item", item.id, f"{number} qty {qty} nilai {value}")
    return m


def transfer_stock(session, user, item_id, from_warehouse_id, to_warehouse_id, move_date, qty, note=""):
    """Pindah stok antar gudang (tidak mengubah nilai persediaan, tidak ada jurnal)."""
    require(user, "inventory.edit")
    if from_warehouse_id == to_warehouse_id:
        raise AccountingError("Gudang asal dan tujuan tidak boleh sama.")
    item = lock_items(session, [item_id]).get(item_id)
    if item is None:
        raise AccountingError("Barang tidak ditemukan.")
    out = issue_at_average(session, item, from_warehouse_id, qty, move_date, "TRANSFER",
                           note=(note or None), user_id=user.id)
    inn = apply_movement(session, item, to_warehouse_id, -out.qty, -out.value, move_date, "TRANSFER",
                         note=(note or None), user_id=user.id)
    audit.log(session, user, "TRANSFER", "item", item.id, f"qty {-out.qty}")
    return out, inn
