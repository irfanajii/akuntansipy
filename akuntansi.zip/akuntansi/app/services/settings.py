"""Pengaturan perusahaan dan akun default."""
from decimal import Decimal, InvalidOperation

from app.database.models import Setting
from app.services import audit
from app.services.auth import require
from app.services.errors import AccountingError

DEFAULTS = {
    "company_name": "Nama Perusahaan",
    "company_address": "",
    "company_phone": "",
    "receivable_account": "1200",      # Piutang Usaha
    "sales_account": "4100",           # Pendapatan penjualan (default faktur)
    "tax_payable_account": "2200",     # PPN keluaran / hutang pajak
    "default_tax_rate": "0",           # persen; atur sesuai ketentuan perpajakan usaha Anda
    "cash_parent": "1100",             # header Kas & Bank (laporan arus kas)
    "investing_parents": "1400",       # header aset tetap (aktivitas investasi)
    "financing_parents": "2500,3000",  # header hutang jangka panjang & modal (pendanaan)
    "cogs_parents": "5100",             # akun/header HPP (laporan laba rugi)
    # akun otomatis modul pembelian, persediaan, aset tetap, retur, dan tutup buku
    "payable_account": "2100",          # Hutang Usaha
    "purchase_tax_account": "1500",     # Pajak Masukan
    "inventory_account": "1300",        # Persediaan Barang
    "cogs_account": "5100",             # Harga Pokok Penjualan
    "inventory_adjust_account": "5500", # Selisih persediaan (lawan penyesuaian stok)
    "sales_return_account": "4200",     # Retur Penjualan
    "fixed_asset_account": "1410",      # default untuk aset baru
    "accum_depreciation_account": "1420",
    "depreciation_expense_account": "5400",
    "disposal_gain_loss_account": "5600",  # Laba/rugi pelepasan aset
    "retained_earnings_account": "3200",   # Laba ditahan (jurnal penutup)
}


def get(session, key: str) -> str:
    row = session.get(Setting, key)
    return row.value if row is not None else DEFAULTS[key]


def get_list(session, key: str) -> list:
    return [c.strip() for c in get(session, key).split(",") if c.strip()]


def get_all(session) -> dict:
    return {k: get(session, k) for k in DEFAULTS}


def company_info(session) -> dict:
    return {"name": get(session, "company_name"), "address": get(session, "company_address"),
            "phone": get(session, "company_phone")}


def save_many(session, user, values: dict) -> None:
    require(user, "settings.edit")
    for key, value in values.items():
        if key not in DEFAULTS:
            raise AccountingError(f"Pengaturan tidak dikenal: {key}")
        value = str(value).strip()
        if key == "company_name" and not value:
            raise AccountingError("Nama perusahaan wajib diisi.")
        if key == "default_tax_rate":
            try:
                rate = Decimal(value.replace(",", "."))
            except InvalidOperation:
                raise AccountingError("Tarif pajak harus berupa angka.")
            if not (Decimal("0") <= rate <= Decimal("100")):
                raise AccountingError("Tarif pajak harus antara 0 dan 100.")
            value = str(rate)
        row = session.get(Setting, key)
        if row is None:
            session.add(Setting(key=key, value=value))
        else:
            row.value = value
    session.flush()
    audit.log(session, user, "UPDATE", "settings", None, ", ".join(sorted(values)))
