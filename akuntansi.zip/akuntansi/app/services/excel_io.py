"""Import & export Excel (.xlsx) untuk akun, jurnal, dan neraca saldo.

Aturan import: SEMUA ATAU TIDAK SAMA SEKALI. Jika ada satu saja baris yang salah,
tidak ada data yang disimpan dan semua kesalahan dilaporkan sekaligus.
"""
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from app.database.models import Account, Journal, JournalLine
from app.services import journals as jr
from app.services.accounts import NORMAL_BALANCE, create_account, list_accounts
from app.services.auth import require
from app.services.errors import AccountingError

MONEY_FMT = "#,##0.00"
DATE_FMT = "dd/mm/yyyy"
HEADER_FONT = Font(bold=True, color="FFFFFF")
HEADER_FILL = PatternFill("solid", fgColor="305496")

TYPE_LABELS = {
    "ASSET": "Aset", "LIABILITY": "Kewajiban", "EQUITY": "Modal",
    "REVENUE": "Pendapatan", "EXPENSE": "Beban",
}
TYPE_ALIASES = {
    "asset": "ASSET", "aset": "ASSET",
    "liability": "LIABILITY", "kewajiban": "LIABILITY", "hutang": "LIABILITY",
    "equity": "EQUITY", "modal": "EQUITY", "ekuitas": "EQUITY",
    "revenue": "REVENUE", "pendapatan": "REVENUE",
    "expense": "EXPENSE", "beban": "EXPENSE",
}
YES = {"ya", "y", "yes", "true", "1"}

ACCOUNT_COLUMNS = {
    "code": ("kode", "kode akun"),
    "name": ("nama", "nama akun"),
    "type": ("tipe", "tipe akun"),
    "parent": ("kode induk", "induk"),
    "header": ("header",),
}
JOURNAL_COLUMNS = {
    "ref": ("referensi", "ref"),
    "date": ("tanggal",),
    "desc": ("keterangan",),
    "account": ("kode akun", "akun"),
    "line_desc": ("keterangan baris",),
    "debit": ("debit",),
    "credit": ("kredit", "credit"),
}


@dataclass
class ImportResult:
    imported: int = 0
    errors: list = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors


# ---------------------------------------------------------------- helper tulis
def _new_sheet(title, headers, widths):
    wb = Workbook()
    ws = wb.active
    ws.title = title
    for c, h in enumerate(headers, 1):
        cell = ws.cell(1, c, h)
        cell.font, cell.fill = HEADER_FONT, HEADER_FILL
        cell.alignment = Alignment(horizontal="center")
        ws.column_dimensions[get_column_letter(c)].width = widths[c - 1]
    ws.freeze_panes = "A2"
    return wb, ws


def _put(ws, row, values, money_cols=(), date_cols=(), bold=False):
    for c, v in enumerate(values, 1):
        if isinstance(v, Decimal):
            v = float(v)
        cell = ws.cell(row, c, v)
        if isinstance(v, str):
            cell.data_type = "s"  # teks tetap teks; "=..." tidak dijalankan sebagai rumus
        if c in money_cols:
            cell.number_format = MONEY_FMT
        if c in date_cols:
            cell.number_format = DATE_FMT
        if bold:
            cell.font = Font(bold=True)


def _save(wb, path):
    try:
        wb.save(path)
    except PermissionError as exc:
        raise AccountingError(
            "File tidak bisa ditulis. Tutup dulu file tersebut jika sedang dibuka di Excel."
        ) from exc


# ---------------------------------------------------------------- helper baca
def _text(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)  # kode "1110" di Excel sering terbaca 1110.0
    return str(v).strip()


def _num(v) -> Decimal:
    """Sel angka Excel dipakai apa adanya. Teks memakai format Indonesia (1.234,50)."""
    if v is None or (isinstance(v, str) and not v.strip()):
        return Decimal("0")
    if isinstance(v, bool):
        raise ValueError("bukan angka")
    if isinstance(v, (int, float, Decimal)):
        d = Decimal(str(v))
    else:
        d = Decimal(str(v).strip().replace(" ", "").replace(".", "").replace(",", "."))
    if not d.is_finite():
        raise ValueError("bukan angka")
    return d


def _date(v) -> date:
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    t = _text(v)
    for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y"):
        try:
            return datetime.strptime(t, fmt).date()
        except ValueError:
            pass
    raise ValueError(f"tanggal {t!r} tidak valid (pakai dd/mm/yyyy)")


def _read_rows(path, columns, required):
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:
        raise AccountingError("File tidak bisa dibaca. Pastikan formatnya .xlsx.") from exc
    try:
        ws = wb.worksheets[0]
        it = ws.iter_rows(values_only=True)
        header = next(it, None)
        if header is None:
            raise AccountingError("File Excel kosong.")
        names = [_text(h).lower() for h in header]
        idx = {}
        for key, accepted in columns.items():
            for a in accepted:
                if a in names:
                    idx[key] = names.index(a)
                    break
        missing = [columns[k][0] for k in required if k not in idx]
        if missing:
            raise AccountingError(
                "Kolom wajib tidak ditemukan di baris pertama: " + ", ".join(missing)
                + ". Gunakan template import."
            )
        rows = []
        for n, row in enumerate(it, start=2):
            if all(_text(c) == "" for c in row):
                continue
            rows.append((n, {k: (row[i] if i < len(row) else None) for k, i in idx.items()}))
        return rows
    finally:
        wb.close()


# ---------------------------------------------------------------- EXPORT
def export_accounts(session, user, path) -> int:
    accs = list_accounts(session, user)  # sudah cek hak akses accounts.view
    code_of = {a.id: a.code for a in accs}
    wb, ws = _new_sheet(
        "Daftar Akun", ["Kode", "Nama", "Tipe", "Kode Induk", "Header", "Status"],
        [14, 44, 14, 14, 10, 12],
    )
    for r, a in enumerate(accs, 2):
        _put(ws, r, [a.code, a.name, TYPE_LABELS[a.type], code_of.get(a.parent_id, ""),
                     "Ya" if a.is_header else "Tidak", "Aktif" if a.is_active else "Nonaktif"])
    _save(wb, path)
    return len(accs)


def export_journals(session, user, path, date_from: date, date_to: date) -> int:
    require(user, "journals.view")
    if date_from > date_to:
        raise AccountingError("Tanggal awal tidak boleh setelah tanggal akhir.")
    stmt = (
        select(Journal)
        .where(Journal.entry_date >= date_from, Journal.entry_date <= date_to)
        .options(selectinload(Journal.lines).selectinload(JournalLine.account))
        .order_by(Journal.entry_date, Journal.id)
    )
    wb, ws = _new_sheet(
        "Jurnal",
        ["Nomor", "Tanggal", "Keterangan", "Status", "Kode Akun", "Nama Akun",
         "Keterangan Baris", "Debit", "Kredit"],
        [18, 12, 36, 12, 12, 32, 30, 16, 16],
    )
    r = 2
    for j in session.scalars(stmt):
        status = "Dibatalkan" if j.status == "REVERSED" else (
            "Pembalik" if j.source == "REVERSAL" else "Diposting")
        for ln in j.lines:
            _put(ws, r, [j.number, j.entry_date, j.description, status, ln.account.code,
                         ln.account.name, ln.description or "", ln.debit, ln.credit],
                 money_cols=(8, 9), date_cols=(2,))
            r += 1
    _save(wb, path)
    return r - 2


def export_trial_balance(session, user, path, date_to: date) -> int:
    tb = jr.trial_balance(session, user, date_to)  # cek hak akses reports.view
    wb, ws = _new_sheet(
        f"Neraca Saldo {date_to:%d-%m-%Y}",
        ["Kode", "Nama Akun", "Mutasi Debit", "Mutasi Kredit", "Saldo Debit", "Saldo Kredit"],
        [12, 40, 18, 18, 18, 18],
    )
    r = 2
    for row in tb["rows"]:
        _put(ws, r, [row["code"], row["name"], row["debit"], row["credit"],
                     row["balance_debit"], row["balance_credit"]], money_cols=(3, 4, 5, 6))
        r += 1
    _put(ws, r, ["", "TOTAL", None, None, tb["total_debit"], tb["total_credit"]],
         money_cols=(5, 6), bold=True)
    _save(wb, path)
    return len(tb["rows"])


# ---------------------------------------------------------------- TEMPLATE
def _instructions(wb, lines):
    ws = wb.create_sheet("Petunjuk")
    ws.column_dimensions["A"].width = 100
    for i, text in enumerate(lines, 1):
        ws.cell(i, 1, text).data_type = "s"


def template_accounts(path):
    wb, ws = _new_sheet(
        "Daftar Akun", ["Kode", "Nama", "Tipe", "Kode Induk", "Header"], [14, 44, 14, 14, 10])
    _put(ws, 2, ["6000", "BEBAN LAIN-LAIN", "Beban", "", "Ya"])
    _put(ws, 3, ["6100", "Beban Administrasi Bank", "Beban", "6000", "Tidak"])
    _instructions(wb, [
        "Isi data di sheet pertama mulai baris 2. Hapus dua baris contoh sebelum import.",
        "Tipe: Aset, Kewajiban, Modal, Pendapatan, atau Beban.",
        "Kode Induk: kosongkan jika tidak punya induk. Induk harus akun header (boleh di baris lain pada file ini).",
        "Header: Ya untuk akun induk/header, Tidak untuk akun yang dipakai di jurnal.",
        "Jika ada satu baris yang salah, tidak ada akun yang diimport.",
    ])
    _save(wb, path)


def template_journals(path):
    wb, ws = _new_sheet(
        "Jurnal",
        ["Referensi", "Tanggal", "Keterangan", "Kode Akun", "Keterangan Baris", "Debit", "Kredit"],
        [12, 12, 36, 12, 30, 16, 16],
    )
    today = date.today()
    _put(ws, 2, ["A1", today, "Contoh penjualan tunai", "1110", "", 1000000, None],
         money_cols=(6, 7), date_cols=(2,))
    _put(ws, 3, ["A1", None, None, "4100", "", None, 1000000], money_cols=(6, 7))
    _instructions(wb, [
        "Satu jurnal = beberapa baris dengan Referensi yang SAMA (bebas, mis. A1, A2, ...).",
        "Tanggal dan Keterangan cukup diisi di baris pertama tiap referensi.",
        "Kode Akun harus sudah ada di Daftar Akun dan bukan akun header.",
        "Isi Debit ATAU Kredit pada tiap baris. Total debit harus sama dengan total kredit per referensi.",
        "Tanggal: dd/mm/yyyy. Angka: sebaiknya sel angka Excel; jika berupa teks pakai format 1.234,50.",
        "Nomor jurnal dibuat otomatis oleh aplikasi. Hapus baris contoh sebelum import.",
        "Jika ada satu referensi yang salah, tidak ada jurnal yang diimport.",
    ])
    _save(wb, path)


# ---------------------------------------------------------------- IMPORT
def import_accounts(session, user, path) -> ImportResult:
    require(user, "accounts.edit")
    rows = _read_rows(path, ACCOUNT_COLUMNS, required=("code", "name", "type"))
    if not rows:
        raise AccountingError("Tidak ada data di file.")

    errors, pending, seen = [], [], set()
    for n, r in rows:
        code, name = _text(r["code"]), _text(r["name"])
        typ = TYPE_ALIASES.get(_text(r["type"]).lower())
        parent = _text(r.get("parent")) or None
        header = _text(r.get("header")).lower() in YES
        if not code or not name:
            errors.append(f"Baris {n}: kode dan nama wajib diisi.")
        elif typ is None:
            errors.append(f"Baris {n} ({code}): tipe {_text(r['type'])!r} tidak dikenal.")
        elif code in seen:
            errors.append(f"Baris {n} ({code}): kode ganda di dalam file.")
        else:
            seen.add(code)
            pending.append((n, code, name, typ, parent, header))
    if errors:
        return ImportResult(0, errors)

    outer = session.begin_nested()
    created, remaining = 0, pending
    while remaining:  # induk boleh muncul setelah anaknya di file
        deferred, progressed = [], False
        for item in remaining:
            n, code, name, typ, parent, header = item
            parent_id = None
            if parent:
                parent_id = session.scalar(select(Account.id).where(Account.code == parent))
                if parent_id is None:
                    deferred.append(item)
                    continue
            try:
                with session.begin_nested():
                    create_account(session, user, code=code, name=name, type=typ,
                                   parent_id=parent_id, is_header=header)
                created += 1
            except AccountingError as exc:
                errors.append(f"Baris {n} ({code}): {exc}")
            progressed = True
        if not progressed:
            break
        remaining = deferred
    for n, code, _name, _typ, parent, _h in remaining:
        errors.append(f"Baris {n} ({code}): kode induk {parent} tidak ditemukan.")

    if errors:
        outer.rollback()
        return ImportResult(0, errors)
    outer.commit()
    return ImportResult(created, [])


def import_journals(session, user, path) -> ImportResult:
    require(user, "journals.post")
    rows = _read_rows(path, JOURNAL_COLUMNS,
                      required=("ref", "date", "desc", "account", "debit", "credit"))
    if not rows:
        raise AccountingError("Tidak ada data di file.")

    acc_ids = {code: aid for code, aid in session.execute(select(Account.code, Account.id))}
    errors, groups = [], {}
    for n, r in rows:
        ref = _text(r["ref"])
        if not ref:
            errors.append(f"Baris {n}: kolom Referensi kosong.")
            continue
        g = groups.setdefault(ref, {"row": n, "date": None, "desc": "", "lines": [], "bad": False})
        try:
            if _text(r["date"]) != "":
                d = _date(r["date"])
                if g["date"] is not None and g["date"] != d:
                    raise ValueError("tanggal berbeda dalam satu referensi")
                g["date"] = d
            if _text(r["desc"]) and not g["desc"]:
                g["desc"] = _text(r["desc"])
            code = _text(r["account"])
            if code not in acc_ids:
                raise ValueError(f"kode akun {code!r} tidak ditemukan")
            g["lines"].append(jr.LineInput(
                account_id=acc_ids[code], debit=_num(r["debit"]), credit=_num(r["credit"]),
                description=_text(r.get("line_desc"))))
        except (ValueError, InvalidOperation) as exc:
            g["bad"] = True
            errors.append(f"Referensi {ref} (baris {n}): {exc}")

    outer = session.begin_nested()
    posted = 0
    for ref, g in groups.items():
        if g["bad"]:
            continue
        if g["date"] is None:
            errors.append(f"Referensi {ref} (baris {g['row']}): tanggal belum diisi.")
            continue
        try:
            with session.begin_nested():
                jr.post_journal(session, user, g["date"], g["desc"], g["lines"], source="IMPORT")
            posted += 1
        except AccountingError as exc:
            errors.append(f"Referensi {ref} (baris {g['row']}): {exc}")

    if errors:
        outer.rollback()
        return ImportResult(0, errors)
    outer.commit()
    return ImportResult(posted, [])


# ---------------------------------------------------------------- PELANGGAN
CUSTOMER_COLUMNS = {
    "code": ("kode", "kode pelanggan"),
    "name": ("nama", "nama pelanggan"),
    "address": ("alamat",),
    "phone": ("telepon", "telp"),
    "email": ("email",),
    "term": ("termin (hari)", "termin"),
}


def export_customers(session, user, path) -> int:
    from app.services import sales  # import lokal: menghindari impor melingkar
    customers = sales.list_customers(session, user)
    wb, ws = _new_sheet(
        "Pelanggan", ["Kode", "Nama", "Alamat", "Telepon", "Email", "Termin (hari)", "Status"],
        [14, 36, 40, 18, 28, 14, 12])
    for r, c in enumerate(customers, 2):
        _put(ws, r, [c.code, c.name, c.address or "", c.phone or "", c.email or "", c.term_days,
                     "Aktif" if c.is_active else "Nonaktif"])
    _save(wb, path)
    return len(customers)


def template_customers(path):
    wb, ws = _new_sheet(
        "Pelanggan", ["Kode", "Nama", "Alamat", "Telepon", "Email", "Termin (hari)"],
        [14, 36, 40, 18, 28, 14])
    _put(ws, 2, ["C001", "CV Contoh Jaya", "Jl. Contoh No. 1, Madiun", "0351-000000", "", 30])
    _instructions(wb, [
        "Isi data mulai baris 2 di sheet pertama; hapus baris contoh sebelum import.",
        "Kode dan Nama wajib. Kode harus unik. Termin = lama pembayaran dalam hari (kosong = 30).",
        "Jika ada satu baris yang salah, tidak ada pelanggan yang diimport.",
    ])
    _save(wb, path)


def import_customers(session, user, path) -> ImportResult:
    from app.services import sales
    require(user, "customers.edit")
    rows = _read_rows(path, CUSTOMER_COLUMNS, required=("code", "name"))
    if not rows:
        raise AccountingError("Tidak ada data di file.")
    outer = session.begin_nested()
    created, errors, seen = 0, [], set()
    for n, r in rows:
        code = _text(r["code"])
        try:
            if code in seen:
                raise AccountingError("kode ganda di dalam file.")
            seen.add(code)
            term = _num(r.get("term")) if _text(r.get("term")) else Decimal(30)
            with session.begin_nested():
                sales.create_customer(
                    session, user, code=code, name=_text(r["name"]), address=_text(r.get("address")),
                    phone=_text(r.get("phone")), email=_text(r.get("email")), term_days=int(term))
            created += 1
        except (AccountingError, ValueError, InvalidOperation) as exc:
            errors.append(f"Baris {n} ({code or '-'}): {exc}")
    if errors:
        outer.rollback()
        return ImportResult(0, errors)
    outer.commit()
    return ImportResult(created, [])


# ---------------------------------------------------------------- PEMASOK
def export_suppliers(session, user, path) -> int:
    from app.services import purchases  # import lokal: menghindari impor melingkar
    customers = purchases.list_suppliers(session, user)
    wb, ws = _new_sheet(
        "Pemasok", ["Kode", "Nama", "Alamat", "Telepon", "Email", "Termin (hari)", "Status"],
        [14, 36, 40, 18, 28, 14, 12])
    for r, c in enumerate(customers, 2):
        _put(ws, r, [c.code, c.name, c.address or "", c.phone or "", c.email or "", c.term_days,
                     "Aktif" if c.is_active else "Nonaktif"])
    _save(wb, path)
    return len(customers)


def template_suppliers(path):
    wb, ws = _new_sheet(
        "Pemasok", ["Kode", "Nama", "Alamat", "Telepon", "Email", "Termin (hari)"],
        [14, 36, 40, 18, 28, 14])
    _put(ws, 2, ["S001", "PT Contoh Pemasok", "Jl. Contoh No. 1, Madiun", "0351-000000", "", 30])
    _instructions(wb, [
        "Isi data mulai baris 2 di sheet pertama; hapus baris contoh sebelum import.",
        "Kode dan Nama wajib. Kode harus unik. Termin = lama pembayaran dalam hari (kosong = 30).",
        "Jika ada satu baris yang salah, tidak ada pemasok yang diimport.",
    ])
    _save(wb, path)


def import_suppliers(session, user, path) -> ImportResult:
    from app.services import purchases
    require(user, "suppliers.edit")
    rows = _read_rows(path, CUSTOMER_COLUMNS, required=("code", "name"))
    if not rows:
        raise AccountingError("Tidak ada data di file.")
    outer = session.begin_nested()
    created, errors, seen = 0, [], set()
    for n, r in rows:
        code = _text(r["code"])
        try:
            if code in seen:
                raise AccountingError("kode ganda di dalam file.")
            seen.add(code)
            term = _num(r.get("term")) if _text(r.get("term")) else Decimal(30)
            with session.begin_nested():
                purchases.create_supplier(
                    session, user, code=code, name=_text(r["name"]), address=_text(r.get("address")),
                    phone=_text(r.get("phone")), email=_text(r.get("email")), term_days=int(term))
            created += 1
        except (AccountingError, ValueError, InvalidOperation) as exc:
            errors.append(f"Baris {n} ({code or '-'}): {exc}")
    if errors:
        outer.rollback()
        return ImportResult(0, errors)
    outer.commit()
    return ImportResult(created, [])


# ---------------------------------------------------------------- BARANG & SALDO AWAL STOK
ITEM_COLUMNS = {
    "code": ("kode", "kode barang"),
    "name": ("nama", "nama barang"),
    "unit": ("satuan",),
    "price": ("harga jual",),
    "kind": ("jenis",),
}
OPENING_COLUMNS = {
    "item": ("kode barang", "kode"),
    "warehouse": ("kode gudang", "gudang"),
    "qty": ("qty", "jumlah"),
    "cost": ("harga pokok", "harga pokok per unit"),
}


def export_items(session, user, path) -> int:
    from app.services import inventory
    items = inventory.list_items(session, user)
    wb, ws = _new_sheet(
        "Barang", ["Kode", "Nama", "Satuan", "Harga Jual", "Jenis", "Stok", "Nilai Stok", "Status"],
        [16, 40, 10, 16, 10, 12, 16, 12])
    for r, i in enumerate(items, 2):
        _put(ws, r, [i.code, i.name, i.unit, i.sell_price, "Jasa" if i.is_service else "Barang", i.qty_on_hand,
                     i.stock_value, "Aktif" if i.is_active else "Nonaktif"], money_cols=(4, 7))
    _save(wb, path)
    return len(items)


def template_items(path):
    wb, ws = _new_sheet("Barang", ["Kode", "Nama", "Satuan", "Harga Jual", "Jenis"], [16, 40, 10, 16, 10])
    _put(ws, 2, ["BRG-001", "Ban Mobil 205/55R16", "pcs", 850000, "Barang"], money_cols=(4,))
    _put(ws, 3, ["JSA-001", "Jasa Pasang Ban", "kali", 50000, "Jasa"], money_cols=(4,))
    _instructions(wb, [
        "Isi data mulai baris 2 di sheet pertama; hapus baris contoh sebelum import.",
        "Jenis: Barang (punya stok) atau Jasa (tanpa stok). Kosong = Barang. Satuan kosong = pcs.",
        "Stok awal TIDAK diisi di sini: gunakan 'Import Saldo Awal Stok' agar jurnalnya ikut terbentuk.",
        "Jika ada satu baris yang salah, tidak ada barang yang diimport.",
    ])
    _save(wb, path)


def import_items(session, user, path) -> ImportResult:
    from app.services import inventory
    require(user, "inventory.edit")
    rows = _read_rows(path, ITEM_COLUMNS, required=("code", "name"))
    if not rows:
        raise AccountingError("Tidak ada data di file.")
    outer = session.begin_nested()
    created, errors, seen = 0, [], set()
    for n, r in rows:
        code = _text(r["code"])
        try:
            if code in seen:
                raise AccountingError("kode ganda di dalam file.")
            seen.add(code)
            with session.begin_nested():
                inventory.create_item(
                    session, user, code=code, name=_text(r["name"]), unit=_text(r.get("unit")) or "pcs",
                    sell_price=_num(r.get("price")), is_service=_text(r.get("kind")).lower() in ("jasa", "service"))
            created += 1
        except (AccountingError, ValueError, InvalidOperation) as exc:
            errors.append(f"Baris {n} ({code or '-'}): {exc}")
    if errors:
        outer.rollback()
        return ImportResult(0, errors)
    outer.commit()
    return ImportResult(created, [])


def template_opening_stock(path):
    wb, ws = _new_sheet("Saldo Awal Stok", ["Kode Barang", "Kode Gudang", "Qty", "Harga Pokok"], [16, 16, 12, 16])
    _put(ws, 2, ["BRG-001", "GD-UTAMA", 10, 700000], money_cols=(4,))
    _instructions(wb, [
        "Satu baris = satu barang di satu gudang. Harga Pokok = harga per unit.",
        "Saat import, aplikasi membuat jurnal Dr Persediaan / Cr akun lawan (pilih akun modal untuk saldo awal).",
        "Jika ada satu baris yang salah, tidak ada stok yang diimport.",
    ])
    _save(wb, path)


def import_opening_stock(session, user, path, adj_date: date, offset_account_id: int) -> ImportResult:
    from app.database.models import Item, Warehouse
    from app.services import inventory
    require(user, "inventory.edit")
    rows = _read_rows(path, OPENING_COLUMNS, required=("item", "warehouse", "qty", "cost"))
    if not rows:
        raise AccountingError("Tidak ada data di file.")
    items = {i.code: i.id for i in session.scalars(select(Item))}
    whs = {w.code: w.id for w in session.scalars(select(Warehouse))}
    outer = session.begin_nested()
    done, errors = 0, []
    for n, r in rows:
        code, wcode = _text(r["item"]), _text(r["warehouse"])
        try:
            if code not in items:
                raise AccountingError(f"kode barang {code!r} tidak ditemukan.")
            if wcode not in whs:
                raise AccountingError(f"kode gudang {wcode!r} tidak ditemukan.")
            qty = _num(r["qty"])
            if qty <= 0:
                raise AccountingError("qty harus lebih dari nol.")
            with session.begin_nested():
                inventory.adjust_stock(session, user, items[code], whs[wcode], adj_date, qty,
                                       unit_cost=_num(r["cost"]), offset_account_id=offset_account_id,
                                       note="Saldo awal (import)")
            done += 1
        except (AccountingError, ValueError, InvalidOperation) as exc:
            errors.append(f"Baris {n} ({code or '-'}): {exc}")
    if errors:
        outer.rollback()
        return ImportResult(0, errors)
    outer.commit()
    return ImportResult(done, [])
