import logging
import sys
import traceback

from PySide6.QtWidgets import QApplication, QDialog, QMessageBox

from app.config import server_label, user_data_dir
from app.ui.login import LoginDialog
from app.ui.main_window import MainWindow
from app.ui.setup_wizard import prepare_database


def _setup_logging():
    try:
        folder = user_data_dir()
        folder.mkdir(parents=True, exist_ok=True)
        logging.basicConfig(filename=str(folder / "app.log"), level=logging.ERROR,
                            format="%(asctime)s %(levelname)s %(message)s", encoding="utf-8")
    except OSError:
        pass


def _excepthook(exc_type, exc, tb):
    """Kesalahan tak terduga (mis. koneksi database putus) ditampilkan dan dicatat di app.log."""
    logging.error("Kesalahan tak tertangani", exc_info=(exc_type, exc, tb))
    detail = "".join(traceback.format_exception(exc_type, exc, tb))
    box = QMessageBox(QMessageBox.Critical, "Terjadi kesalahan", str(exc) or exc_type.__name__)
    box.setInformativeText(f"Rincian dicatat di: {user_data_dir() / 'app.log'}")
    box.setDetailedText(detail)
    box.exec()


def main() -> int:
    _setup_logging()
    app = QApplication(sys.argv)
    app.setApplicationName("Aplikasi Akuntansi")
    sys.excepthook = _excepthook

    cfg = prepare_database()
    if cfg is None:
        return 0
    login = LoginDialog(server_label(cfg), cfg)
    if login.exec() != QDialog.Accepted:
        return 0
    window = MainWindow(login.user, cfg)
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
