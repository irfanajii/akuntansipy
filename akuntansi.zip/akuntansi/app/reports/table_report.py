"""Struktur laporan generik: dibuat oleh service, ditampilkan di layar, dicetak PDF, atau di-export Excel."""
from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal


def fmt_money(value) -> str:
    """1234567.5 -> 1.234.567,50 (format Indonesia)."""
    s = f"{Decimal(str(value or 0)):,.2f}"
    return s.replace(",", "_").replace(".", ",").replace("_", ".")


def fmt_qty(value) -> str:
    """Jumlah barang: maksimal 4 desimal, tanpa nol di belakang (1.234,5)."""
    text = f"{Decimal(str(value or 0)):,.4f}"
    if "." in text:
        text = text.rstrip("0").rstrip(".")
    return text.replace(",", "_").replace(".", ",").replace("_", ".")


def fmt_date(value) -> str:
    if isinstance(value, (date, datetime)):
        return value.strftime("%d/%m/%Y")
    return "" if value is None else str(value)


@dataclass
class Column:
    title: str
    width: float = 1.0        # lebar relatif
    kind: str = "text"        # text | money | qty | date | number


@dataclass
class Row:
    cells: list
    style: str = "normal"     # normal | section | subtotal | total
    indent: int = 0


@dataclass
class ReportSpec:
    title: str
    subtitle: str = ""
    company: str = ""
    columns: list = field(default_factory=list)
    rows: list = field(default_factory=list)
    notes: list = field(default_factory=list)
    meta: dict = field(default_factory=dict)

    def cell_text(self, row: Row, col_index: int) -> str:
        """Teks sel setelah diformat sesuai jenis kolom."""
        v = row.cells[col_index] if col_index < len(row.cells) else None
        kind = self.columns[col_index].kind
        if v is None or v == "":
            return ""
        if kind == "money":
            return fmt_money(v)
        if kind == "qty":
            return fmt_qty(v)
        if kind == "date":
            return fmt_date(v)
        return str(v)
