"""Export ReportSpec ke Excel (.xlsx)."""
from decimal import Decimal

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from app.reports.table_report import ReportSpec

MONEY_FMT = "#,##0.00"
DATE_FMT = "dd/mm/yyyy"


def render_report_xlsx(spec: ReportSpec, path) -> int:
    wb = Workbook()
    ws = wb.active
    ws.title = spec.title[:31].replace("/", "-")
    r = 1
    for text, font in ((spec.company, Font(bold=True, size=13)), (spec.title, Font(bold=True, size=11)),
                       (spec.subtitle, Font(size=9))):
        if text:
            c = ws.cell(r, 1, text)
            c.data_type, c.font = "s", font
            r += 1
    r += 1
    for ci, col in enumerate(spec.columns, 1):
        c = ws.cell(r, ci, col.title)
        c.font, c.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="305496")
        c.alignment = Alignment(horizontal="center")
        ws.column_dimensions[get_column_letter(ci)].width = max(10, round(col.width * 14))
    ws.freeze_panes = ws.cell(r + 1, 1)
    r += 1
    first_text = next((i for i, c in enumerate(spec.columns) if c.kind == "text" and i > 0), 0)
    for row in spec.rows:
        for ci, col in enumerate(spec.columns):
            v = row.cells[ci] if ci < len(row.cells) else None
            if isinstance(v, Decimal):
                v = float(v)
            if v == "":
                v = None
            c = ws.cell(r, ci + 1, v)
            if isinstance(v, str):
                c.data_type = "s"  # teks tetap teks, bukan rumus
            if col.kind == "money":
                c.number_format = MONEY_FMT
            elif col.kind == "qty":
                c.number_format = "#,##0.####"
            elif col.kind == "date":
                c.number_format = DATE_FMT
            if row.style != "normal":
                c.font = Font(bold=True)
            if row.style in ("section", "total"):
                c.fill = PatternFill("solid", fgColor="EDEDED")
            if ci == first_text and row.indent:
                c.alignment = Alignment(indent=row.indent)
        r += 1
    if spec.notes:
        r += 1
        for n in spec.notes:
            c = ws.cell(r, 1, n)
            c.data_type = "s"
            r += 1
    wb.save(path)
    return len(spec.rows)
