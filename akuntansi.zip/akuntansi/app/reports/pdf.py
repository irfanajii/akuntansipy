"""Cetak PDF memakai ReportLab: laporan generik dan faktur penjualan."""
from datetime import datetime
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from app.reports.table_report import ReportSpec, fmt_date, fmt_money

_BASE = getSampleStyleSheet()["Normal"]
_cache = {}


def _style(bold=False, align="L", indent=0, size=8.5):
    key = (bold, align, indent, size)
    if key not in _cache:
        _cache[key] = ParagraphStyle(
            f"s{len(_cache)}", parent=_BASE, fontName="Helvetica-Bold" if bold else "Helvetica",
            fontSize=size, leading=size + 2.5, alignment={"L": 0, "C": 1, "R": 2}[align],
            leftIndent=indent * 10,
        )
    return _cache[key]


def _p(text, **kw):
    return Paragraph(escape(str(text)).replace("\n", "<br/>"), _style(**kw))


def _footer(company):
    def draw(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(colors.grey)
        w, _h = doc.pagesize
        canvas.drawString(doc.leftMargin, 8 * mm, f"{company} - dicetak {datetime.now():%d/%m/%Y %H:%M}")
        canvas.drawRightString(w - doc.rightMargin, 8 * mm, f"Halaman {doc.page}")
        canvas.restoreState()
    return draw


def render_report_pdf(spec: ReportSpec, path) -> None:
    wide = len(spec.columns) > 5
    pagesize = landscape(A4) if wide else A4
    doc = SimpleDocTemplate(str(path), pagesize=pagesize, leftMargin=14 * mm, rightMargin=14 * mm,
                            topMargin=14 * mm, bottomMargin=16 * mm, title=spec.title)
    avail = pagesize[0] - 28 * mm
    total_w = sum(c.width for c in spec.columns) or 1
    col_w = [avail * c.width / total_w for c in spec.columns]

    story = [
        Paragraph(escape(spec.company or ""), _style(bold=True, size=13)),
        Paragraph(escape(spec.title), _style(bold=True, size=11)),
    ]
    if spec.subtitle:
        story.append(Paragraph(escape(spec.subtitle), _style(size=9)))
    story.append(Spacer(1, 4 * mm))

    right = {"money", "number", "qty"}
    header = [_p(c.title, bold=True, align="R" if c.kind in right else "L") for c in spec.columns]
    data, cmds = [header], [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D9E2F3")),
        ("LINEBELOW", (0, 0), (-1, 0), 0.8, colors.HexColor("#305496")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 2), ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]
    for i, row in enumerate(spec.rows, start=1):
        bold = row.style != "normal"
        cells = []
        for ci, col in enumerate(spec.columns):
            align = "R" if col.kind in right else "L"
            indent = row.indent if ci == _first_text_col(spec) else 0
            cells.append(_p(spec.cell_text(row, ci), bold=bold, align=align, indent=indent))
        data.append(cells)
        if row.style == "section":
            cmds.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#F2F2F2")))
        elif row.style == "subtotal":
            cmds.append(("LINEABOVE", (0, i), (-1, i), 0.5, colors.black))
        elif row.style == "total":
            cmds.append(("LINEABOVE", (0, i), (-1, i), 0.8, colors.black))
            cmds.append(("LINEBELOW", (0, i), (-1, i), 0.8, colors.black))
            cmds.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#EDEDED")))
        else:
            cmds.append(("LINEBELOW", (0, i), (-1, i), 0.25, colors.HexColor("#DDDDDD")))
    table = Table(data, colWidths=col_w, repeatRows=1)
    table.setStyle(TableStyle(cmds))
    story.append(table)

    if spec.notes:
        story.append(Spacer(1, 5 * mm))
        for n in spec.notes:
            story.append(Paragraph(escape(n), _style(size=8)))
    cb = _footer(spec.company or "")
    doc.build(story, onFirstPage=cb, onLaterPages=cb)


def _first_text_col(spec):
    for i, c in enumerate(spec.columns):
        if c.kind == "text" and i > 0:
            return i  # kolom nama/keterangan (kolom 0 biasanya kode)
    return 0


def render_invoice_pdf(invoice: dict, company: dict, path, title="FAKTUR PENJUALAN",
                       party_label="Kepada:") -> None:
    """invoice: hasil sales.invoice_detail(); company: {'name','address','phone'}."""
    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm,
                            topMargin=15 * mm, bottomMargin=16 * mm, title=f"{title} {invoice['number']}")
    avail = A4[0] - 32 * mm
    story = [Paragraph(escape(company.get("name", "")), _style(bold=True, size=14))]
    for key in ("address", "phone"):
        if company.get(key):
            story.append(Paragraph(escape(company[key]), _style(size=8.5)))
    story += [Spacer(1, 4 * mm), Paragraph(escape(title), _style(bold=True, size=13)), Spacer(1, 3 * mm)]

    cust = invoice["customer"]
    left = [[_p(party_label, bold=True)], [_p(cust["name"], bold=True)]]
    if cust.get("address"):
        left.append([_p(cust["address"])])
    if cust.get("phone"):
        left.append([_p(f"Telp: {cust['phone']}")])
    info = [
        [_p("No. Faktur", bold=True), _p(invoice["number"])],
        [_p("Tanggal", bold=True), _p(fmt_date(invoice["date"]))],
        [_p("Jatuh Tempo", bold=True), _p(fmt_date(invoice["due_date"]))],
        [_p("Status", bold=True), _p(invoice["status_label"])],
    ]
    head = Table([[Table(left, colWidths=[avail * 0.55]), Table(info, colWidths=[avail * 0.15, avail * 0.27])]],
                 colWidths=[avail * 0.57, avail * 0.43])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story += [head, Spacer(1, 4 * mm)]

    data = [[_p(t, bold=True, align=a) for t, a in
             (("No", "C"), ("Deskripsi", "L"), ("Qty", "R"), ("Harga", "R"), ("Jumlah", "R"))]]
    for i, ln in enumerate(invoice["lines"], 1):
        qty = f"{ln['quantity']:f}".rstrip("0").rstrip(".") if "." in f"{ln['quantity']:f}" else f"{ln['quantity']}"
        data.append([_p(i, align="C"), _p(ln["description"]), _p(qty, align="R"),
                     _p(fmt_money(ln["unit_price"]), align="R"), _p(fmt_money(ln["amount"]), align="R")])
    cw = [avail * w for w in (0.07, 0.43, 0.10, 0.19, 0.21)]
    t = Table(data, colWidths=cw, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#D9E2F3")),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#999999")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story += [t, Spacer(1, 3 * mm)]

    tot = [[_p("Subtotal", align="R"), _p(fmt_money(invoice["subtotal"]), align="R")]]
    if invoice["tax_amount"]:
        tot.append([_p(f"PPN / Pajak ({invoice['tax_rate']}%)", align="R"),
                    _p(fmt_money(invoice["tax_amount"]), align="R")])
    tot.append([_p("TOTAL", bold=True, align="R"), _p(fmt_money(invoice["total"]), bold=True, align="R")])
    tot.append([_p("Dibayar", align="R"), _p(fmt_money(invoice["paid"]), align="R")])
    tot.append([_p("Sisa Tagihan", bold=True, align="R"), _p(fmt_money(invoice["outstanding"]), bold=True, align="R")])
    tt = Table(tot, colWidths=[avail * 0.30, avail * 0.21], hAlign="RIGHT")
    tt.setStyle(TableStyle([("LINEABOVE", (0, 2 if invoice["tax_amount"] else 1), (-1, -1), 0.5, colors.black)]))
    story.append(tt)

    if invoice.get("description"):
        story += [Spacer(1, 3 * mm), _p(f"Catatan: {invoice['description']}")]
    story.append(Spacer(1, 18 * mm))
    sign = Table([[_p("Dibuat oleh,", align="C"), _p("Diterima oleh,", align="C")],
                  [_p(""), _p("")], [_p("(______________)", align="C"), _p("(______________)", align="C")]],
                 colWidths=[avail * 0.3, avail * 0.3], rowHeights=[None, 16 * mm, None], hAlign="RIGHT")
    story.append(sign)
    cb = _footer(company.get("name", ""))
    doc.build(story, onFirstPage=cb, onLaterPages=cb)
