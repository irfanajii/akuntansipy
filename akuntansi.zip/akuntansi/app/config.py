"""Konfigurasi koneksi database dan lokasi file pengguna.

Lokasi config.ini (urutan):
 1. variabel lingkungan AKUNTANSI_CONFIG (path lengkap),
 2. config.ini di samping aplikasi (mode developer / portabel),
 3. folder data pengguna: %APPDATA%\\AplikasiAkuntansi\\config.ini (Windows). Ini lokasi standar setelah instalasi,
    karena folder Program Files tidak bisa ditulis oleh pengguna biasa.
"""
import configparser
import os
import sys
from dataclasses import dataclass
from pathlib import Path

APP_DIR_NAME = "AplikasiAkuntansi"


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))  # True saat berjalan sebagai .exe (PyInstaller)


def base_dir() -> Path:
    if is_frozen():
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


def user_data_dir() -> Path:
    if sys.platform == "win32":
        root = Path(os.environ.get("APPDATA") or (Path.home() / "AppData" / "Roaming"))
    else:
        root = Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config"))
    return root / APP_DIR_NAME


@dataclass
class DBConfig:
    driver: str = "mysql"
    host: str = "127.0.0.1"
    port: int = 3306
    name: str = "akuntansi"
    user: str = "akuntansi_app"
    password: str = ""
    sqlite_path: str = "akuntansi.db"
    mysqldump_path: str = "mysqldump"
    backup_dir: str = "backup"


def config_path() -> Path:
    env = os.environ.get("AKUNTANSI_CONFIG")
    if env:
        return Path(env)
    local = base_dir() / "config.ini"
    return local if local.exists() else user_data_dir() / "config.ini"


def config_exists(path=None) -> bool:
    return (Path(path) if path else config_path()).exists()


def load_config(path=None) -> DBConfig:
    path = Path(path) if path else config_path()
    if not path.exists():
        raise FileNotFoundError(
            f"File konfigurasi tidak ditemukan: {path}\n"
            "Buka Pengaturan Koneksi untuk mengisi alamat server database."
        )
    cp = configparser.ConfigParser(interpolation=None)  # password boleh mengandung tanda %
    cp.read(path, encoding="utf-8")
    if "database" not in cp:
        raise ValueError(f"File konfigurasi {path} tidak memiliki bagian [database].")
    s = cp["database"]
    return DBConfig(
        driver=s.get("driver", "mysql").strip().lower(),
        host=s.get("host", "127.0.0.1").strip(),
        port=s.getint("port", 3306),
        name=s.get("name", "akuntansi").strip(),
        user=s.get("user", "akuntansi_app").strip(),
        password=s.get("password", ""),
        sqlite_path=s.get("sqlite_path", "akuntansi.db").strip(),
        mysqldump_path=s.get("mysqldump_path", "mysqldump").strip(),
        backup_dir=s.get("backup_dir", "backup").strip(),
    )


def save_config(cfg: DBConfig, path=None) -> Path:
    path = Path(path) if path else config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    cp = configparser.ConfigParser(interpolation=None)
    cp["database"] = {
        "driver": cfg.driver, "host": cfg.host, "port": str(cfg.port), "name": cfg.name, "user": cfg.user,
        "password": cfg.password, "sqlite_path": cfg.sqlite_path, "mysqldump_path": cfg.mysqldump_path,
        "backup_dir": cfg.backup_dir,
    }
    with open(path, "w", encoding="utf-8") as f:
        cp.write(f)
    try:
        os.chmod(path, 0o600)  # berguna di Linux/macOS; di Windows file ada di profil pengguna
    except OSError:
        pass
    return path


def resolve_sqlite_path(cfg: DBConfig) -> Path:
    """Path relatif untuk SQLite ditaruh di folder data pengguna saat berjalan sebagai .exe."""
    p = Path(cfg.sqlite_path)
    if p.is_absolute():
        return p
    return user_data_dir() / p if is_frozen() else p


def server_label(cfg: DBConfig) -> str:
    if cfg.driver == "sqlite":
        return str(resolve_sqlite_path(cfg))
    return f"{cfg.host}:{cfg.port}/{cfg.name}"
