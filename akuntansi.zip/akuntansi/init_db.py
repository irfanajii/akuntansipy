"""Membuat tabel baru dan data awal lewat command line (alternatif dari wizard di aplikasi).
Aman dijalankan ulang setelah pembaruan aplikasi (tidak menghapus data)."""
import getpass
import sys

from sqlalchemy import select

from app.config import load_config
from app.database.connection import init_engine, session_scope
from app.database.models import User
from app.database.setup import initialize_database
from app.services.errors import AccountingError


def main() -> int:
    cfg = load_config()
    engine = init_engine(cfg)
    print(f"Terhubung ke {engine.url.render_as_string(hide_password=True)}")
    pw = None
    try:
        with session_scope() as s:
            has_admin = s.scalar(select(User.id).where(User.username == "admin")) is not None
    except Exception:
        has_admin = False  # tabel belum ada
    if not has_admin:
        pw = getpass.getpass("Password untuk user 'admin' (min. 8 karakter): ")
    try:
        added = initialize_database(pw)
    except AccountingError as exc:
        print(exc)
        return 1
    if added:
        print("Kolom baru ditambahkan: " + ", ".join(added))
    print("Selesai. Tabel dan data awal sudah dibuat/diperbarui.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
