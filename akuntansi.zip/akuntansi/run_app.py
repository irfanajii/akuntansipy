"""Titik masuk program (dipakai PyInstaller).

  AplikasiAkuntansi.exe                      -> menjalankan aplikasi
  AplikasiAkuntansi.exe --backup [folder] [jumlah_disimpan]
                                             -> backup database tanpa jendela (untuk Task Scheduler);
                                                hasilnya dicatat di %APPDATA%\\AplikasiAkuntansi\\backup.log
"""
import sys
from datetime import datetime


def _backup(args) -> int:
    from app.config import load_config, user_data_dir
    from app.services.backup import backup_database

    log = user_data_dir() / "backup.log"
    log.parent.mkdir(parents=True, exist_ok=True)

    def write(msg):
        with open(log, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {msg}\n")

    try:
        out = args[0] if args else None
        keep = int(args[1]) if len(args) > 1 else 14
        path = backup_database(load_config(), out, keep=keep)
        write(f"OK {path}")
        return 0
    except Exception as exc:  # noqa: BLE001 - semua kesalahan dicatat untuk pemeriksaan
        write(f"GAGAL {exc}")
        return 1


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--backup":
        sys.exit(_backup(sys.argv[2:]))
    from app.main import main

    sys.exit(main())
