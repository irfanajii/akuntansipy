from datetime import date
from decimal import Decimal

import pytest
from sqlalchemy import select

from app.database.models import Account, Journal, PurchaseInvoice
from app.services import inventory as inv
from app.services import journals as jr
from app.services import purchases as pu
from app.services import reports as rp
from app.services import reports_ext as rx
from app.services import sales as sv
from app.services.errors import AccountingError, PermissionDenied
from app.services.auth import CurrentUser
from app.services.trade_common import InvoiceLineInput as L
from app.services.trade_common import outstanding

Y = date.today().year
D = Decimal


def acc_id(session, code):
    return session.scalar(select(Account.id).where(Account.code == code))


def wh(session):
    return inv.default_warehouse_id(session)


def mk_item(session, admin, code="BRG1", service=False):
    return inv.create_item(session, admin, code=code, name=f"Barang {code}", sell_price=300, is_service=service)


def supplier(session, admin, code="S1"):
    return pu.create_supplier(session, admin, code=code, name=f"Pemasok {code}")


def customer(session, admin, code="C1"):
    return sv.create_customer(session, admin, code=code, name=f"Pelanggan {code}")


def buy(session, admin, sup, item, qty, price, day=date(Y, 2, 1), tax=0):
    return pu.create_invoice(session, admin, sup.id, day, [L("", qty, price, item_id=item.id)], tax_rate=tax)


def sell(session, admin, cust, item, qty, price=300, day=date(Y, 3, 1), **kw):
    return sv.create_invoice(session, admin, cust.id, day, [L("", qty, price, item_id=item.id)], **kw)


def journal_map(session, journal_id):
    j = session.get(Journal, journal_id)
    out = {}
    for l in j.lines:
        d, k = out.get(l.account_id, (D("0"), D("0")))
        out[l.account_id] = (d + l.debit, k + l.credit)
    return out


def bal(session, code):
    tb = jr.trial_balance(session, CurrentUser(1, "a", "a", "a", frozenset({"*"})), date(Y, 12, 31))
    for r in tb["rows"]:
        if r["code"] == code:
            return r["balance_debit"] - r["balance_credit"]
    return D("0")


# ================================================================= persediaan
def test_opening_stock_adjustment_posts_journal(session, admin):
    item = mk_item(session, admin)
    inv.adjust_stock(session, admin, item.id, wh(session), date(Y, 1, 2), 10, unit_cost=700,
                     offset_account_id=acc_id(session, "3100"))
    assert item.qty_on_hand == 10 and item.stock_value == D("7000.00")
    assert bal(session, "1300") == D("7000.00") and bal(session, "3100") == D("-7000.00")


def test_adjust_out_uses_average_and_default_offset(session, admin):
    item = mk_item(session, admin)
    inv.adjust_stock(session, admin, item.id, wh(session), date(Y, 1, 2), 10, unit_cost=100,
                     offset_account_id=acc_id(session, "3100"))
    inv.adjust_stock(session, admin, item.id, wh(session), date(Y, 1, 3), -4, note="rusak")
    assert item.qty_on_hand == 6 and item.stock_value == D("600.00")
    assert bal(session, "5500") == D("400.00")       # selisih persediaan (beban)
    with pytest.raises(AccountingError, match="tidak cukup"):
        inv.adjust_stock(session, admin, item.id, wh(session), date(Y, 1, 4), -50)


def test_service_item_has_no_stock(session, admin):
    svc_item = mk_item(session, admin, "JSA1", service=True)
    with pytest.raises(AccountingError, match="jasa"):
        inv.adjust_stock(session, admin, svc_item.id, wh(session), date(Y, 1, 2), 1, unit_cost=1)
    c = customer(session, admin)
    s = sv.create_invoice(session, admin, c.id, date(Y, 3, 1), [L("", 2, 50000, item_id=svc_item.id)])
    assert s.lines[0].cogs_amount == 0 and svc_item.qty_on_hand == 0


def test_inventory_requires_permission(session, admin):
    viewer = CurrentUser(1, "v", "V", "Viewer", frozenset({"inventory.view"}))
    with pytest.raises(PermissionDenied):
        inv.create_item(session, viewer, code="X", name="X")


# ================================================================= pembelian
def test_purchase_invoice_posts_stock_and_journal(session, admin):
    sup, item = supplier(session, admin), mk_item(session, admin)
    p = buy(session, admin, sup, item, 10, 100, tax=10)
    assert p.number == f"PUR-{Y}-00001"
    assert p.subtotal == D("1000.00") and p.tax_amount == D("100.00") and p.total == D("1100.00")
    assert item.qty_on_hand == 10 and item.stock_value == D("1000.00")
    jm = journal_map(session, p.journal_id)
    assert jm[acc_id(session, "1300")] == (D("1000.00"), D("0"))
    assert jm[acc_id(session, "1500")] == (D("100.00"), D("0"))
    assert jm[acc_id(session, "2100")] == (D("0"), D("1100.00"))


def test_purchase_non_stock_line_needs_account(session, admin):
    sup = supplier(session, admin)
    with pytest.raises(AccountingError, match="akun beban/aset"):
        pu.create_invoice(session, admin, sup.id, date(Y, 2, 1), [L("Listrik", 1, 500000)])
    p = pu.create_invoice(session, admin, sup.id, date(Y, 2, 1),
                          [L("Listrik", 1, 500000, account_id=acc_id(session, "5300"))])
    assert journal_map(session, p.journal_id)[acc_id(session, "5300")] == (D("500000.00"), D("0"))


def test_payment_flow_and_payable_aging_matches_gl(session, admin):
    sup, item = supplier(session, admin), mk_item(session, admin)
    p = buy(session, admin, sup, item, 10, 100, day=date(Y, 1, 1))
    pay = pu.create_payment(session, admin, sup.id, date(Y, 1, 10), acc_id(session, "1110"), [(p.id, 400)])
    assert pay.number == f"PAY-{Y}-00001" and p.paid_amount == D("400.00") and p.status == "OPEN"
    spec = rp.payable_aging(session, admin, date(Y, 3, 15))
    assert spec.meta["total"] == D("600.00") == spec.meta["gl_balance"]
    assert not any("PERHATIAN" in n for n in spec.notes)
    with pytest.raises(AccountingError, match="melebihi"):
        pu.create_payment(session, admin, sup.id, date(Y, 1, 11), acc_id(session, "1110"), [(p.id, 700)])
    pu.create_payment(session, admin, sup.id, date(Y, 1, 12), acc_id(session, "1110"), [(p.id, 600)])
    assert p.status == "PAID"
    pu.void_payment(session, admin, pay.id, void_date=date(Y, 1, 13))
    assert p.status == "OPEN" and p.paid_amount == D("600.00")


def test_void_purchase_blocked_after_payment_and_restores_otherwise(session, admin):
    sup, item = supplier(session, admin), mk_item(session, admin)
    p = buy(session, admin, sup, item, 10, 100)
    pu.create_payment(session, admin, sup.id, date(Y, 2, 5), acc_id(session, "1110"), [(p.id, 100)])
    with pytest.raises(AccountingError, match="pembayaran"):
        pu.void_invoice(session, admin, p.id)
    p2 = buy(session, admin, sup, item, 5, 100)
    pu.void_invoice(session, admin, p2.id, void_date=date(Y, 2, 20))
    assert p2.status == "VOID" and item.qty_on_hand == 10 and item.stock_value == D("1000.00")


def test_void_purchase_is_atomic_when_stock_already_sold(session, admin):
    sup, item, c = supplier(session, admin), mk_item(session, admin), customer(session, admin)
    p = buy(session, admin, sup, item, 10, 100)
    sell(session, admin, c, item, 8)
    session.commit()
    with pytest.raises(AccountingError, match="tidak cukup"):
        pu.void_invoice(session, admin, p.id, void_date=date(Y, 3, 5))
    session.rollback()                                # seluruh pembatalan harus ikut batal
    p = session.get(PurchaseInvoice, p.id)
    assert p.status == "OPEN"
    assert session.get(Journal, p.journal_id).status == "POSTED"


# ================================================================= HPP rata-rata & penjualan
def test_moving_average_cogs_on_sale(session, admin):
    sup, item, c = supplier(session, admin), mk_item(session, admin), customer(session, admin)
    buy(session, admin, sup, item, 10, 100)
    buy(session, admin, sup, item, 10, 200)
    assert item.qty_on_hand == 20 and item.stock_value == D("3000.00")
    s = sell(session, admin, c, item, 5)
    assert s.lines[0].cogs_amount == D("750.00")                  # 3000 * 5 / 20
    assert item.qty_on_hand == 15 and item.stock_value == D("2250.00")
    jm = journal_map(session, s.journal_id)
    assert jm[acc_id(session, "1200")] == (D("1500.00"), D("0"))
    assert jm[acc_id(session, "4100")] == (D("0"), D("1500.00"))
    assert jm[acc_id(session, "5100")] == (D("750.00"), D("0"))
    assert jm[acc_id(session, "1300")] == (D("0"), D("750.00"))


def test_sale_rejected_when_stock_insufficient(session, admin):
    sup, item, c = supplier(session, admin), mk_item(session, admin), customer(session, admin)
    buy(session, admin, sup, item, 3, 100)
    with pytest.raises(AccountingError, match="tidak cukup"):
        sell(session, admin, c, item, 10)


def test_selling_all_stock_leaves_no_rounding_residue(session, admin):
    sup, item, c = supplier(session, admin), mk_item(session, admin), customer(session, admin)
    buy(session, admin, sup, item, 3, D("33.33"))
    buy(session, admin, sup, item, 4, D("10.01"))
    sell(session, admin, c, item, 2)
    sell(session, admin, c, item, 5)                              # habiskan
    assert item.qty_on_hand == 0 and item.stock_value == D("0.00")


def test_void_sale_restores_stock_at_original_cost(session, admin):
    sup, item, c = supplier(session, admin), mk_item(session, admin), customer(session, admin)
    buy(session, admin, sup, item, 10, 100)
    buy(session, admin, sup, item, 10, 200)
    s = sell(session, admin, c, item, 5)
    sv.void_invoice(session, admin, s.id, void_date=date(Y, 3, 5))
    assert item.qty_on_hand == 20 and item.stock_value == D("3000.00")
    assert bal(session, "5100") == 0 and bal(session, "1300") == D("3000.00")


# ================================================================= retur
def test_sales_return_restores_stock_and_reduces_receivable(session, admin):
    sup, item, c = supplier(session, admin), mk_item(session, admin), customer(session, admin)
    buy(session, admin, sup, item, 10, 100)
    buy(session, admin, sup, item, 10, 200)
    s = sell(session, admin, c, item, 5)                          # HPP 750, piutang 1500
    r = sv.create_return(session, admin, s.id, date(Y, 3, 10), [(s.lines[0].id, 2)])
    assert r.number == f"SRT-{Y}-00001" and r.total == D("600.00")
    assert item.qty_on_hand == 17 and item.stock_value == D("2550.00")   # +2 pcs @ HPP asli 150
    assert outstanding(s) == D("900.00") and s.lines[0].returned_qty == 2
    jm = journal_map(session, r.journal_id)
    assert jm[acc_id(session, "4200")] == (D("600.00"), D("0"))
    assert jm[acc_id(session, "1200")] == (D("0"), D("600.00"))
    assert jm[acc_id(session, "1300")] == (D("300.00"), D("0"))
    assert jm[acc_id(session, "5100")] == (D("0"), D("300.00"))
    with pytest.raises(AccountingError, match="melebihi jumlah"):
        sv.create_return(session, admin, s.id, date(Y, 3, 11), [(s.lines[0].id, 4)])   # sisa hanya 3
    sv.void_return(session, admin, r.id, void_date=date(Y, 3, 12))
    assert item.qty_on_hand == 15 and item.stock_value == D("2250.00")
    assert outstanding(s) == D("1500.00") and s.lines[0].returned_qty == 0


def test_return_limited_by_outstanding_and_blocks_void(session, admin):
    sup, item, c = supplier(session, admin), mk_item(session, admin), customer(session, admin)
    buy(session, admin, sup, item, 10, 100)
    s = sell(session, admin, c, item, 5)                          # piutang 1500
    sv.create_receipt(session, admin, c.id, date(Y, 3, 5), acc_id(session, "1110"), [(s.id, 1400)])
    with pytest.raises(AccountingError, match="melebihi sisa tagihan"):
        sv.create_return(session, admin, s.id, date(Y, 3, 6), [(s.lines[0].id, 2)])
    s2 = sell(session, admin, c, item, 5, day=date(Y, 3, 7))
    sv.create_return(session, admin, s2.id, date(Y, 3, 8), [(s2.lines[0].id, 5)])   # retur penuh
    assert s2.status == "PAID" and outstanding(s2) == 0
    with pytest.raises(AccountingError, match="sudah ada retur"):
        sv.void_invoice(session, admin, s2.id)


def test_purchase_return_removes_stock_at_cost(session, admin):
    sup, item = supplier(session, admin), mk_item(session, admin)
    p = buy(session, admin, sup, item, 10, 100)
    r = pu.create_return(session, admin, p.id, date(Y, 2, 10), [(p.lines[0].id, 4)])
    assert r.number == f"PRT-{Y}-00001" and r.total == D("400.00")
    assert item.qty_on_hand == 6 and item.stock_value == D("600.00")
    jm = journal_map(session, r.journal_id)
    assert jm[acc_id(session, "2100")] == (D("400.00"), D("0"))
    assert jm[acc_id(session, "1300")] == (D("0"), D("400.00"))
    assert outstanding(p) == D("600.00")
    pu.void_return(session, admin, r.id, void_date=date(Y, 2, 11))
    assert item.qty_on_hand == 10 and item.stock_value == D("1000.00") and outstanding(p) == D("1000.00")


def test_purchase_return_blocked_when_stock_gone(session, admin):
    sup, item, c = supplier(session, admin), mk_item(session, admin), customer(session, admin)
    p = buy(session, admin, sup, item, 10, 100)
    sell(session, admin, c, item, 9)
    with pytest.raises(AccountingError, match="tidak cukup"):
        pu.create_return(session, admin, p.id, date(Y, 3, 10), [(p.lines[0].id, 5)])


# ================================================================= gudang
def test_transfer_between_warehouses_and_per_warehouse_stock_check(session, admin):
    item, c = mk_item(session, admin), customer(session, admin)
    w1 = wh(session)
    w2 = inv.create_warehouse(session, admin, code="GD2", name="Gudang 2").id
    inv.adjust_stock(session, admin, item.id, w1, date(Y, 1, 2), 10, unit_cost=100,
                     offset_account_id=acc_id(session, "3100"))
    inv.transfer_stock(session, admin, item.id, w1, w2, date(Y, 1, 5), 4)
    assert inv.warehouse_qty(session, item.id, w1) == 6 and inv.warehouse_qty(session, item.id, w2) == 4
    assert item.qty_on_hand == 10 and item.stock_value == D("1000.00")
    session.commit()
    with pytest.raises(AccountingError, match="tidak cukup"):
        sv.create_invoice(session, admin, c.id, date(Y, 3, 1), [L("", 7, 300, item_id=item.id)], warehouse_id=w1)
    session.rollback()
    with pytest.raises(AccountingError, match="tidak boleh sama"):
        inv.transfer_stock(session, admin, item.id, w1, w1, date(Y, 1, 6), 1)


# ================================================================= laporan persediaan & pajak
def test_stock_valuation_reconciles_with_gl_and_stock_card(session, admin):
    sup, item, c = supplier(session, admin), mk_item(session, admin), customer(session, admin)
    inv.adjust_stock(session, admin, item.id, wh(session), date(Y, 1, 2), 10, unit_cost=100,
                     offset_account_id=acc_id(session, "3100"))
    buy(session, admin, sup, item, 10, 200)
    s = sell(session, admin, c, item, 6)
    sv.create_return(session, admin, s.id, date(Y, 3, 10), [(s.lines[0].id, 1)])
    inv.adjust_stock(session, admin, item.id, wh(session), date(Y, 3, 20), -2)
    spec = rx.stock_valuation(session, admin, date(Y, 12, 31))
    assert spec.meta["total"] == spec.meta["gl_balance"] == item.stock_value
    assert not any("PERHATIAN" in n for n in spec.notes)
    card = rx.stock_card(session, admin, item.id, date(Y, 1, 1), date(Y, 12, 31))
    assert card.meta["closing_qty"] == item.qty_on_hand and card.meta["closing_value"] == item.stock_value
    # saldo awal kartu stok = posisi sebelum tanggal awal
    later = rx.stock_card(session, admin, item.id, date(Y, 3, 1), date(Y, 12, 31))
    assert later.rows[0].cells[6] == D("20.0000") + D("0") and later.meta["closing_qty"] == item.qty_on_hand


def test_tax_summary_and_gl_balance_after_mixed_activity(session, admin):
    sup, item, c = supplier(session, admin), mk_item(session, admin), customer(session, admin)
    buy(session, admin, sup, item, 10, 100, tax=10)               # pajak masukan 100
    sell(session, admin, c, item, 5, price=300, tax_rate=10)      # pajak keluaran 150
    t = rx.tax_summary(session, admin, date(Y, 1, 1), date(Y, 12, 31))
    assert t.meta["input"] == D("100.00") and t.meta["output"] == D("150.00") and t.meta["payable"] == D("50.00")
    tb = jr.trial_balance(session, admin, date(Y, 12, 31))
    assert tb["total_debit"] == tb["total_credit"]
    bs = rp.balance_sheet(session, admin, date(Y, 12, 31))
    assert bs.meta["balanced"]


def test_purchase_and_sales_reports_and_pdf_title(session, admin, tmp_path):
    from app.reports.pdf import render_invoice_pdf
    sup, item = supplier(session, admin), mk_item(session, admin)
    p = buy(session, admin, sup, item, 2, 100)
    spec = rp.purchase_report(session, admin, date(Y, 1, 1), date(Y, 12, 31))
    assert spec.meta["total"] == D("200.00") and spec.columns[2].title == "Pemasok"
    detail = pu.invoice_detail(session, admin, p.id)
    render_invoice_pdf(detail, {"name": "Toko"}, tmp_path / "p.pdf", title="FAKTUR PEMBELIAN", party_label="Dari:")
    assert (tmp_path / "p.pdf").read_bytes().startswith(b"%PDF")
