from datetime import date, timedelta
from decimal import Decimal

import pytest
from sqlalchemy import select

from app.database.models import Account, FiscalPeriod, Journal
from app.reports.export import render_report_xlsx
from app.reports.pdf import render_invoice_pdf, render_report_pdf
from app.services import excel_io as xl
from app.services import journals as jr
from app.services import reports as rp
from app.services import sales as sv
from app.services import settings as st
from app.services.auth import CurrentUser
from app.services.errors import AccountingError, PermissionDenied

Y = date.today().year
D = Decimal


def acc_id(session, code):
    return session.scalar(select(Account.id).where(Account.code == code))


def user_with(*perms):
    return CurrentUser(1, "u", "User", "Test", frozenset(perms))


def customer(session, admin, code="C001", term=30, name="CV Maju"):
    return sv.create_customer(session, admin, code=code, name=name, term_days=term)


def invoice(session, admin, cust, day, price=1000000, qty=1, tax=0, **kw):
    return sv.create_invoice(
        session, admin, cust.id, day, [sv.InvoiceLineInput("Ban mobil", qty, price)], tax_rate=tax, **kw)


def manual(session, admin, day, desc, debit_code, credit_code, amount):
    return jr.post_journal(session, admin, day, desc, [
        jr.LineInput(acc_id(session, debit_code), debit=amount),
        jr.LineInput(acc_id(session, credit_code), credit=amount)])


def rows_by_label(spec, label_col=1):
    return {r.cells[label_col]: r.cells[-1] for r in spec.rows}


# ================================================================= pelanggan & faktur
def test_customer_validation(session, admin):
    customer(session, admin)
    with pytest.raises(AccountingError, match="sudah dipakai"):
        customer(session, admin)
    with pytest.raises(AccountingError, match="Termin"):
        sv.create_customer(session, admin, code="X", name="X", term_days=999)


def test_invoice_posts_balanced_journal_with_tax(session, admin):
    c = customer(session, admin, term=14)
    inv = invoice(session, admin, c, date(Y, 3, 1), price=1000000, qty=1, tax=10)
    assert inv.number == f"INV-{Y}-00001"
    assert inv.subtotal == D("1000000.00") and inv.tax_amount == D("100000.00")
    assert inv.total == D("1100000.00")
    assert inv.due_date == date(Y, 3, 15)  # termin 14 hari
    journal = session.get(Journal, inv.journal_id)
    assert journal.source == "SALES"
    by_acc = {l.account_id: (l.debit, l.credit) for l in journal.lines}
    assert by_acc[acc_id(session, "1200")] == (D("1100000.00"), D("0"))
    assert by_acc[acc_id(session, "4100")] == (D("0"), D("1000000.00"))
    assert by_acc[acc_id(session, "2200")] == (D("0"), D("100000.00"))


def test_invoice_validation(session, admin):
    c = customer(session, admin)
    with pytest.raises(AccountingError, match="satu baris"):
        sv.create_invoice(session, admin, c.id, date(Y, 3, 1), [])
    with pytest.raises(AccountingError, match="lebih dari nol"):
        sv.create_invoice(session, admin, c.id, date(Y, 3, 1), [sv.InvoiceLineInput("x", 0, 100)])
    with pytest.raises(AccountingError, match="akun pendapatan"):
        sv.create_invoice(session, admin, c.id, date(Y, 3, 1),
                          [sv.InvoiceLineInput("x", 1, 100, account_id=acc_id(session, "1110"))])


def test_invoice_rejected_in_closed_period(session, admin):
    c = customer(session, admin)
    session.scalar(select(FiscalPeriod)).is_closed = True
    session.flush()
    with pytest.raises(AccountingError, match="ditutup"):
        invoice(session, admin, c, date(Y, 3, 1))


def test_sales_clerk_can_invoice_without_journal_permission_but_viewer_cannot(session, admin):
    c = customer(session, admin)
    clerk = user_with("sales.view", "sales.post")  # tanpa journals.post
    assert invoice(session, clerk, c, date(Y, 3, 1)).status == "OPEN"
    viewer = user_with("sales.view")
    with pytest.raises(PermissionDenied):
        invoice(session, viewer, c, date(Y, 3, 1))


# ================================================================= penerimaan & pembatalan
def test_receipt_partial_then_full(session, admin):
    c = customer(session, admin)
    inv = invoice(session, admin, c, date(Y, 3, 1), price=1000000)
    r1 = sv.create_receipt(session, admin, c.id, date(Y, 3, 10), acc_id(session, "1110"), [(inv.id, 400000)])
    assert r1.number == f"RCV-{Y}-00001"
    assert inv.paid_amount == D("400000.00") and inv.status == "OPEN"
    assert sv.status_label(inv) == "Dibayar sebagian"
    sv.create_receipt(session, admin, c.id, date(Y, 3, 20), acc_id(session, "1120"), [(inv.id, 600000)])
    assert inv.status == "PAID"
    assert sv.outstanding_invoices(session, admin, c.id) == []


def test_receipt_validations(session, admin):
    c1, c2 = customer(session, admin), customer(session, admin, code="C002", name="PT Lain")
    inv = invoice(session, admin, c1, date(Y, 3, 1), price=1000)
    cash = acc_id(session, "1110")
    with pytest.raises(AccountingError, match="melebihi"):
        sv.create_receipt(session, admin, c1.id, date(Y, 3, 2), cash, [(inv.id, 5000)])
    with pytest.raises(AccountingError, match="bukan milik"):
        sv.create_receipt(session, admin, c2.id, date(Y, 3, 2), cash, [(inv.id, 100)])
    with pytest.raises(AccountingError, match="sebelum tanggal faktur"):
        sv.create_receipt(session, admin, c1.id, date(Y, 2, 1), cash, [(inv.id, 100)])
    with pytest.raises(AccountingError, match="minimal satu"):
        sv.create_receipt(session, admin, c1.id, date(Y, 3, 2), cash, [(inv.id, 0)])
    with pytest.raises(AccountingError, match="kas/bank"):
        sv.create_receipt(session, admin, c1.id, date(Y, 3, 2), acc_id(session, "4100"), [(inv.id, 100)])


def test_void_rules(session, admin):
    c = customer(session, admin)
    inv = invoice(session, admin, c, date(Y, 3, 1), price=1000)
    rc = sv.create_receipt(session, admin, c.id, date(Y, 3, 5), acc_id(session, "1110"), [(inv.id, 1000)])
    assert inv.status == "PAID"
    with pytest.raises(AccountingError, match="pembayaran"):
        sv.void_invoice(session, admin, inv.id)           # sudah ada pembayaran
    sv.void_receipt(session, admin, rc.id, void_date=date(Y, 3, 6))
    assert inv.status == "OPEN" and inv.paid_amount == D("0.00")
    with pytest.raises(AccountingError, match="sudah dibatalkan"):
        sv.void_receipt(session, admin, rc.id)
    sv.void_invoice(session, admin, inv.id, "salah", void_date=date(Y, 3, 7))
    assert inv.status == "VOID" and inv.void_journal_id
    tb = jr.trial_balance(session, admin, date(Y, 12, 31))
    assert tb["total_debit"] == tb["total_credit"]
    assert all(r["balance_debit"] == r["balance_credit"] == 0 for r in tb["rows"])


def test_cannot_void_system_journal_from_general_journal(session, admin):
    c = customer(session, admin)
    inv = invoice(session, admin, c, date(Y, 3, 1))
    with pytest.raises(AccountingError, match="otomatis"):
        jr.void_journal(session, admin, inv.journal_id)


# ================================================================= laporan
def test_aging_buckets_and_gl_reconciliation(session, admin):
    c = customer(session, admin, term=30)
    invoice(session, admin, c, date(Y, 1, 1), price=100)    # jatuh tempo 31 Jan -> 43 hari (31-60)
    invoice(session, admin, c, date(Y, 2, 1), price=200)    # jatuh tempo 3 Mar  -> 12 hari (1-30)
    invoice(session, admin, c, date(Y, 3, 10), price=400)   # jatuh tempo 9 Apr  -> belum JT
    spec = rp.receivable_aging(session, admin, date(Y, 3, 15))
    total_row = spec.rows[-1].cells
    assert total_row[3:8] == [D("400.00"), D("200.00"), D("100.00"), D("0.00"), D("0.00")]
    assert spec.meta["total"] == D("700.00") == spec.meta["gl_balance"]
    assert not any("PERHATIAN" in n for n in spec.notes)


def test_aging_respects_receipts_and_flags_manual_journal(session, admin):
    c = customer(session, admin)
    inv = invoice(session, admin, c, date(Y, 1, 1), price=1000)
    sv.create_receipt(session, admin, c.id, date(Y, 2, 1), acc_id(session, "1110"), [(inv.id, 300)])
    assert rp.receivable_aging(session, admin, date(Y, 1, 20)).meta["total"] == D("1000.00")  # sebelum bayar
    assert rp.receivable_aging(session, admin, date(Y, 2, 20)).meta["total"] == D("700.00")
    manual(session, admin, date(Y, 2, 10), "Koreksi manual", "1200", "4100", 50)
    spec = rp.receivable_aging(session, admin, date(Y, 2, 20))
    assert any("PERHATIAN" in n for n in spec.notes)


def test_income_statement_with_cogs(session, admin):
    c = customer(session, admin)
    invoice(session, admin, c, date(Y, 3, 1), price=1000000)
    manual(session, admin, date(Y, 3, 2), "HPP", "5100", "1300", 300000)
    manual(session, admin, date(Y, 3, 3), "Gaji", "5200", "1110", 100000)
    spec = rp.income_statement(session, admin, date(Y, 1, 1), date(Y, 12, 31))
    assert spec.meta["revenue"] == D("1000000.00") and spec.meta["cogs"] == D("300000.00")
    assert spec.meta["expenses"] == D("100000.00") and spec.meta["net_income"] == D("600000.00")
    labels = rows_by_label(spec)
    assert labels["LABA KOTOR"] == D("700000.00")
    # di luar rentang tanggal -> kosong
    assert rp.income_statement(session, admin, date(Y, 6, 1), date(Y, 6, 30)).meta["net_income"] == 0


def test_balance_sheet_balances(session, admin):
    c = customer(session, admin)
    manual(session, admin, date(Y, 1, 5), "Setoran modal", "1110", "3100", 1000000)
    invoice(session, admin, c, date(Y, 3, 1), price=500000)
    manual(session, admin, date(Y, 3, 3), "Gaji", "5200", "1110", 100000)
    spec = rp.balance_sheet(session, admin, date(Y, 12, 31))
    m = spec.meta
    assert m["balanced"]
    assert m["total_assets"] == D("1400000.00")        # kas 900rb + piutang 500rb
    assert m["earnings"] == D("400000.00")
    assert m["total_equity"] == D("1400000.00")
    # sebelum transaksi apa pun -> semua nol & seimbang
    assert rp.balance_sheet(session, admin, date(Y, 1, 1)).meta["balanced"]


def test_cash_flow_classification(session, admin):
    c = customer(session, admin)
    manual(session, admin, date(Y, 1, 5), "Setoran modal", "1110", "3100", 1000000)       # pendanaan +1jt
    inv = invoice(session, admin, c, date(Y, 3, 1), price=500000)
    sv.create_receipt(session, admin, c.id, date(Y, 3, 10), acc_id(session, "1110"), [(inv.id, 500000)])  # operasi +500rb
    manual(session, admin, date(Y, 3, 12), "Gaji", "5200", "1110", 100000)               # operasi -100rb
    manual(session, admin, date(Y, 4, 1), "Beli peralatan", "1410", "1110", 200000)      # investasi -200rb
    manual(session, admin, date(Y, 4, 2), "Pindah kas ke bank", "1120", "1110", 50000)   # antar kas: netral
    spec = rp.cash_flow(session, admin, date(Y, 1, 1), date(Y, 12, 31))
    assert spec.meta["net_change"] == D("1200000.00") and spec.meta["closing"] == D("1200000.00")
    assert spec.meta["reconciled"]
    labels = rows_by_label(spec)
    assert labels["Kas bersih dari aktivitas operasi"] == D("400000.00")
    assert labels["Kas bersih dari aktivitas investasi"] == D("-200000.00")
    assert labels["Kas bersih dari aktivitas pendanaan"] == D("1000000.00")
    # periode berikutnya: saldo awal = saldo akhir sebelumnya
    later = rp.cash_flow(session, admin, date(Y, 6, 1), date(Y, 12, 31))
    assert later.meta["opening"] == D("1200000.00") and later.meta["net_change"] == 0


def test_cash_flow_requires_cash_setting(session, admin):
    st.save_many(session, admin, {"cash_parent": "9999"})
    with pytest.raises(AccountingError, match="Kas dan Bank"):
        rp.cash_flow(session, admin, date(Y, 1, 1), date(Y, 12, 31))


def test_general_ledger_running_balance(session, admin):
    manual(session, admin, date(Y, 1, 10), "Modal", "1110", "3100", 1000)
    manual(session, admin, date(Y, 2, 10), "Beban", "5200", "1110", 300)
    spec = rp.general_ledger(session, admin, acc_id(session, "1110"), date(Y, 2, 1), date(Y, 12, 31))
    assert spec.meta["opening"] == D("1000.00") and spec.meta["closing"] == D("700.00")
    assert spec.rows[1].cells[5] == D("700.00")
    # akun bersaldo normal kredit memakai tanda sebaliknya
    cap = rp.general_ledger(session, admin, acc_id(session, "3100"), date(Y, 1, 1), date(Y, 12, 31))
    assert cap.meta["closing"] == D("1000.00")


def test_sales_report_excludes_void(session, admin):
    c = customer(session, admin)
    invoice(session, admin, c, date(Y, 3, 1), price=1000)
    bad = invoice(session, admin, c, date(Y, 3, 2), price=5000)
    sv.void_invoice(session, admin, bad.id, void_date=date(Y, 3, 3))
    spec = rp.sales_report(session, admin, date(Y, 1, 1), date(Y, 12, 31))
    assert spec.meta["total"] == D("1000.00") and len(spec.rows) == 3


def test_reports_require_permission(session, admin):
    nobody = user_with("accounts.view")
    with pytest.raises(PermissionDenied):
        rp.balance_sheet(session, nobody, date(Y, 12, 31))
    with pytest.raises(PermissionDenied):
        rp.receivable_aging(session, nobody, date(Y, 12, 31))


# ================================================================= pengaturan & excel pelanggan
def test_settings_admin_only_and_validation(session, admin):
    with pytest.raises(PermissionDenied):
        st.save_many(session, user_with("reports.view"), {"company_name": "X"})
    with pytest.raises(AccountingError, match="antara 0 dan 100"):
        st.save_many(session, admin, {"default_tax_rate": "150"})
    st.save_many(session, admin, {"company_name": "Toko Ban Jaya", "default_tax_rate": "11"})
    assert st.company_info(session)["name"] == "Toko Ban Jaya"
    assert rp.balance_sheet(session, admin, date(Y, 12, 31)).company == "Toko Ban Jaya"


def test_missing_receivable_account_gives_clear_error(session, admin):
    c = customer(session, admin)
    st.save_many(session, admin, {"receivable_account": "9999"})
    with pytest.raises(AccountingError, match="Piutang Usaha"):
        invoice(session, admin, c, date(Y, 3, 1))


def test_import_customers_all_or_nothing(session, admin, tmp_path):
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(["Kode", "Nama", "Alamat", "Telepon", "Email", "Termin (hari)"])
    ws.append(["C1", "Satu", "Jl. A", None, None, 14])
    ws.append(["C2", "Dua", None, None, None, None])
    wb.save(tmp_path / "c.xlsx")
    res = xl.import_customers(session, admin, tmp_path / "c.xlsx")
    assert res.ok and res.imported == 2
    assert {c.code: c.term_days for c in sv.list_customers(session, admin)} == {"C1": 14, "C2": 30}

    wb2 = Workbook()
    ws2 = wb2.active
    ws2.append(["Kode", "Nama"])
    ws2.append(["C3", "Tiga"])
    ws2.append(["C1", "Dobel"])
    wb2.save(tmp_path / "d.xlsx")
    res = xl.import_customers(session, admin, tmp_path / "d.xlsx")
    assert not res.ok and len(sv.list_customers(session, admin)) == 2  # C3 pun tidak masuk


# ================================================================= PDF & Excel dari data nyata
def test_report_and_invoice_pdf_and_xlsx(session, admin, tmp_path):
    c = customer(session, admin)
    inv = invoice(session, admin, c, date(Y, 3, 1), price=850000, qty=4, tax=11)
    for name, spec in {
        "tb": rp.trial_balance_report(session, admin, date(Y, 12, 31)),
        "bs": rp.balance_sheet(session, admin, date(Y, 12, 31)),
        "is": rp.income_statement(session, admin, date(Y, 1, 1), date(Y, 12, 31)),
        "ag": rp.receivable_aging(session, admin, date(Y, 12, 31)),
    }.items():
        render_report_pdf(spec, tmp_path / f"{name}.pdf")
        assert (tmp_path / f"{name}.pdf").read_bytes().startswith(b"%PDF")
        render_report_xlsx(spec, tmp_path / f"{name}.xlsx")
    detail = sv.invoice_detail(session, admin, inv.id)
    render_invoice_pdf(detail, st.company_info(session), tmp_path / "inv.pdf")
    assert (tmp_path / "inv.pdf").read_bytes().startswith(b"%PDF")
    assert detail["total"] == D("3774000.00") and detail["status_label"] == "Belum lunas"
