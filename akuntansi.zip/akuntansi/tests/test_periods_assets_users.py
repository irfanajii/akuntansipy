import sqlite3
from datetime import date
from decimal import Decimal

import pytest
from openpyxl import Workbook
from sqlalchemy import create_engine, inspect, select, text

from app.config import DBConfig
from app.database.models import Account, Base, FiscalPeriod, FixedAsset, Item
from app.database.schema_sync import sync_missing_columns
from app.services import assets as asv
from app.services import excel_io as xl
from app.services import inventory as inv
from app.services import journals as jr
from app.services import periods as per
from app.services import purchases as pu
from app.services import reports as rp
from app.services import reports_ext as rx
from app.services import sales as sv
from app.services import users as us
from app.services.auth import CurrentUser, authenticate
from app.services.backup import backup_database
from app.services.errors import AccountingError, PermissionDenied
from app.services.trade_common import InvoiceLineInput as L

Y = date.today().year
D = Decimal


def acc_id(session, code):
    return session.scalar(select(Account.id).where(Account.code == code))


def manual(session, admin, day, desc, debit_code, credit_code, amount):
    return jr.post_journal(session, admin, day, desc, [
        jr.LineInput(acc_id(session, debit_code), debit=amount),
        jr.LineInput(acc_id(session, credit_code), credit=amount)])


def tb_net(session, admin, code):
    for r in jr.trial_balance(session, admin, date(Y, 12, 31))["rows"]:
        if r["code"] == code:
            return r["balance_debit"] - r["balance_credit"]
    return D("0")


# ================================================================= periode & tutup buku
def test_close_year_with_closing_entries(session, admin):
    c = sv.create_customer(session, admin, code="C1", name="CV Maju")
    sv.create_invoice(session, admin, c.id, date(Y, 3, 1), [L("Jasa", 1, 1000000)])
    manual(session, admin, date(Y, 3, 2), "Gaji", "5200", "1110", 200000)
    period = session.scalar(select(FiscalPeriod))
    per.close_period(session, admin, period.id, post_closing=True)
    assert period.is_closed and period.closing_journal_id
    assert session.scalar(select(FiscalPeriod).where(FiscalPeriod.start_date == date(Y + 1, 1, 1)))  # tahun baru siap

    # laba rugi tahun itu tetap terbaca (jurnal penutup diabaikan)
    assert rp.income_statement(session, admin, date(Y, 1, 1), date(Y, 12, 31)).meta["net_income"] == D("800000.00")
    # laba pindah ke Laba Ditahan dan neraca tetap seimbang
    bs = rp.balance_sheet(session, admin, date(Y, 12, 31))
    assert bs.meta["balanced"] and bs.meta["earnings"] == 0
    assert tb_net(session, admin, "3200") == D("-800000.00")
    assert tb_net(session, admin, "4100") == 0 and tb_net(session, admin, "5200") == 0
    with pytest.raises(AccountingError, match="ditutup"):
        manual(session, admin, date(Y, 6, 1), "Terlambat", "5200", "1110", 1)
    with pytest.raises(AccountingError, match="otomatis"):
        jr.void_journal(session, admin, period.closing_journal_id)

    per.reopen_period(session, admin, period.id)
    assert not period.is_closed and period.closing_journal_id is None
    assert tb_net(session, admin, "3200") == 0 and tb_net(session, admin, "4100") == D("-1000000.00")
    assert rp.income_statement(session, admin, date(Y, 1, 1), date(Y, 12, 31)).meta["net_income"] == D("800000.00")
    assert rp.balance_sheet(session, admin, date(Y, 12, 31)).meta["balanced"]


def test_close_without_closing_entries_and_reopen_order(session, admin):
    first = session.scalar(select(FiscalPeriod))
    per.close_period(session, admin, first.id, post_closing=True)       # membuat tahun berikutnya
    nxt = session.scalar(select(FiscalPeriod).where(FiscalPeriod.start_date == date(Y + 1, 1, 1)))
    per.close_period(session, admin, nxt.id)
    with pytest.raises(AccountingError, match="setelahnya"):
        per.reopen_period(session, admin, first.id)
    per.reopen_period(session, admin, nxt.id)
    per.reopen_period(session, admin, first.id)
    with pytest.raises(AccountingError, match="belum ditutup"):
        per.reopen_period(session, admin, first.id)


def test_create_period_overlap_and_permission(session, admin):
    with pytest.raises(AccountingError, match="bertabrakan"):
        per.create_period(session, admin, "Tabrakan", date(Y, 6, 1), date(Y, 7, 1))
    assert per.create_period(session, admin, "Tahun depan", date(Y + 5, 1, 1), date(Y + 5, 12, 31)).id
    nobody = CurrentUser(1, "u", "U", "U", frozenset({"reports.view"}))
    with pytest.raises(PermissionDenied):
        per.close_period(session, nobody, 1)


# ================================================================= aset tetap
def _asset(session, admin, **kw):
    args = dict(code="AST1", name="Mesin Press", acquisition_date=date(Y, 1, 15), cost=12000000, life_months=12)
    args.update(kw)
    return asv.create_asset(session, admin, **args)


def test_depreciation_run_and_reverse(session, admin):
    manual(session, admin, date(Y, 1, 15), "Beli mesin", "1410", "1110", 12000000)
    a = _asset(session, admin)
    res = asv.run_depreciation(session, admin, date(Y, 3, 10))           # Feb dan Mar
    assert len(res) == 2 and a.months_depreciated == 2 and a.accumulated == D("2000000.00")
    assert tb_net(session, admin, "5400") == D("2000000.00") and tb_net(session, admin, "1420") == D("-2000000.00")
    assert asv.run_depreciation(session, admin, date(Y, 3, 31)) == []    # tidak diposting dua kali
    with pytest.raises(AccountingError, match="setelahnya"):
        asv.reverse_depreciation(session, admin, asv.month_end(date(Y, 2, 1)))
    asv.reverse_depreciation(session, admin, asv.month_end(date(Y, 3, 1)))
    assert a.months_depreciated == 1 and a.accumulated == D("1000000.00")
    assert tb_net(session, admin, "5400") == D("1000000.00")


def test_final_month_absorbs_rounding(session, admin):
    a = _asset(session, admin, code="AST2", cost=1000, life_months=3)
    asv.run_depreciation(session, admin, date(Y, 4, 30))
    assert a.accumulated == D("1000.00") and a.months_depreciated == 3
    assert tb_net(session, admin, "5400") == D("1000.00")


def test_asset_validation(session, admin):
    with pytest.raises(AccountingError, match="Nilai sisa"):
        _asset(session, admin, salvage_value=12000000)
    with pytest.raises(AccountingError, match="Umur"):
        _asset(session, admin, life_months=0)
    _asset(session, admin)
    with pytest.raises(AccountingError, match="sudah dipakai"):
        _asset(session, admin)


def test_dispose_asset_gain_and_register(session, admin):
    manual(session, admin, date(Y, 1, 15), "Beli mesin", "1410", "1110", 12000000)
    a = _asset(session, admin)
    with pytest.raises(AccountingError, match="Jalankan dulu penyusutan"):
        asv.dispose_asset(session, admin, a.id, date(Y, 4, 20), 9500000, acc_id(session, "1110"))
    asv.run_depreciation(session, admin, date(Y, 4, 20))                 # Feb, Mar, Apr -> 3.000.000
    reg = rx.asset_register(session, admin, date(Y, 12, 31))
    assert reg.meta["cost"] == D("12000000.00") and reg.meta["book_value"] == D("9000000.00")
    _a, gain = asv.dispose_asset(session, admin, a.id, date(Y, 4, 20), 9500000, acc_id(session, "1110"))
    assert gain == D("500000.00") and a.status == "DISPOSED"
    assert tb_net(session, admin, "1410") == 0 and tb_net(session, admin, "1420") == 0
    assert tb_net(session, admin, "5600") == D("-500000.00")
    assert rx.asset_register(session, admin, date(Y, 12, 31)).meta["cost"] == 0
    with pytest.raises(AccountingError, match="sudah dilepas"):
        asv.dispose_asset(session, admin, a.id, date(Y, 5, 1), 0, None)
    tb = jr.trial_balance(session, admin, date(Y, 12, 31))
    assert tb["total_debit"] == tb["total_credit"]


def test_dispose_asset_with_loss(session, admin):
    manual(session, admin, date(Y, 1, 15), "Beli mesin", "1410", "1110", 12000000)
    a = _asset(session, admin)
    asv.run_depreciation(session, admin, date(Y, 3, 31))                 # 2.000.000 -> nilai buku 10.000.000
    _a, gain = asv.dispose_asset(session, admin, a.id, date(Y, 3, 31), 4000000, acc_id(session, "1110"))
    assert gain == D("-6000000.00") and tb_net(session, admin, "5600") == D("6000000.00")


# ================================================================= user, role, audit
def test_user_management_rules(session, admin):
    roles = {r["name"]: r for r in us.list_roles(session, admin)}
    assert roles["Administrator"]["permissions"] == ["*"]
    with pytest.raises(AccountingError, match="minimal 8"):
        us.create_user(session, admin, username="budi", full_name="Budi", password="pendek", role_id=roles["Akuntan"]["id"])
    with pytest.raises(AccountingError, match="Username"):
        us.create_user(session, admin, username="a b", full_name="X", password="rahasia123", role_id=roles["Akuntan"]["id"])
    with pytest.raises(AccountingError, match="sudah dipakai"):
        us.create_user(session, admin, username="ADMIN", full_name="X", password="rahasia123", role_id=roles["Akuntan"]["id"])
    u = us.create_user(session, admin, username="budi", full_name="Budi", password="rahasia123", role_id=roles["Akuntan"]["id"])
    logged = authenticate(session, "budi", "rahasia123")
    assert logged is not None and logged.can("sales.post") and not logged.can("users.manage")
    with pytest.raises(PermissionDenied):
        us.list_users(session, logged)
    us.update_user(session, admin, u.id, full_name="Budi S", role_id=roles["Viewer"]["id"], is_active=True)
    assert not authenticate(session, "budi", "rahasia123").can("sales.post")
    us.update_user(session, admin, u.id, full_name="Budi S", role_id=roles["Viewer"]["id"], is_active=False)
    assert authenticate(session, "budi", "rahasia123") is None


def test_admin_protection_and_password_change(session, admin):
    roles = {r["name"]: r for r in us.list_roles(session, admin)}
    with pytest.raises(AccountingError, match="sendiri"):
        us.update_user(session, admin, admin.id, full_name="A", role_id=roles["Administrator"]["id"], is_active=False)
    with pytest.raises(AccountingError, match="Administrator yang aktif"):
        us.update_user(session, admin, admin.id, full_name="A", role_id=roles["Viewer"]["id"], is_active=True)
    session.rollback()
    with pytest.raises(AccountingError, match="lama salah"):
        us.change_password(session, admin, "salah", "passwordbaru1")
    us.change_password(session, admin, "rahasia123", "passwordbaru1")
    assert authenticate(session, "admin", "rahasia123") is None
    assert authenticate(session, "admin", "passwordbaru1") is not None


def test_role_save_rules_and_audit(session, admin):
    r = us.save_role(session, admin, name="Kasir", permissions=["sales.view", "sales.post"])
    assert r.permissions == "sales.post,sales.view"
    with pytest.raises(AccountingError, match="tidak dikenal"):
        us.save_role(session, admin, name="X", permissions=["bukan.izin"])
    admin_role = next(x for x in us.list_roles(session, admin) if x["name"] == "Administrator")
    with pytest.raises(AccountingError, match="tidak bisa diubah"):
        us.save_role(session, admin, name="Administrator", permissions=[], role_id=admin_role["id"])
    log = us.list_audit(session, admin)
    assert any(a["entity"] == "role" and a["action"] == "SAVE" for a in log)
    viewer = CurrentUser(1, "v", "V", "V", frozenset({"reports.view"}))
    with pytest.raises(PermissionDenied):
        us.list_audit(session, viewer)


# ================================================================= migrasi kolom & backup
def test_sync_missing_columns_adds_new_columns():
    engine = create_engine("sqlite://")
    Base.metadata.create_all(engine)
    with engine.begin() as conn:
        conn.execute(text("ALTER TABLE sales_invoices DROP COLUMN returned_amount"))
        conn.execute(text("ALTER TABLE sales_invoice_lines DROP COLUMN cogs_amount"))
    assert "returned_amount" not in {c["name"] for c in inspect(engine).get_columns("sales_invoices")}
    added = sync_missing_columns(engine)
    assert "sales_invoices.returned_amount" in added and "sales_invoice_lines.cogs_amount" in added
    assert "returned_amount" in {c["name"] for c in inspect(engine).get_columns("sales_invoices")}
    assert sync_missing_columns(engine) == []                           # idempoten


def test_backup_sqlite_and_retention(tmp_path):
    db = tmp_path / "app.db"
    conn = sqlite3.connect(db)
    conn.execute("CREATE TABLE t (x)")
    conn.execute("INSERT INTO t VALUES (1)")
    conn.commit()
    conn.close()
    out = tmp_path / "bk"
    out.mkdir()
    for stamp in ("20200101_000000", "20200102_000000", "20200103_000000"):
        (out / f"akuntansi_{stamp}.db").write_bytes(b"old")
    cfg = DBConfig(driver="sqlite", sqlite_path=str(db))
    target = backup_database(cfg, out, keep=2)
    assert target.exists() and len(list(out.glob("akuntansi_*.db"))) == 2
    assert sqlite3.connect(target).execute("SELECT x FROM t").fetchone() == (1,)


def test_backup_mysqldump_missing_gives_clear_error(tmp_path):
    cfg = DBConfig(driver="mysql", mysqldump_path="mysqldump-tidak-ada-xyz")
    with pytest.raises(AccountingError, match="mysqldump tidak ditemukan"):
        backup_database(cfg, tmp_path)


# ================================================================= Excel: pemasok, barang, saldo awal
def make_xlsx(path, headers, rows):
    wb = Workbook()
    ws = wb.active
    ws.append(headers)
    for r in rows:
        ws.append(r)
    wb.save(path)
    return path


def test_import_suppliers_and_items(session, admin, tmp_path):
    f = make_xlsx(tmp_path / "s.xlsx", ["Kode", "Nama", "Termin (hari)"], [["S1", "PT Satu", 45], ["S2", "PT Dua", None]])
    res = xl.import_suppliers(session, admin, f)
    assert res.ok and {s.code: s.term_days for s in pu.list_suppliers(session, admin)} == {"S1": 45, "S2": 30}
    bad = make_xlsx(tmp_path / "s2.xlsx", ["Kode", "Nama"], [["S3", "Tiga"], ["S1", "Dobel"]])
    assert not xl.import_suppliers(session, admin, bad).ok and len(pu.list_suppliers(session, admin)) == 2

    f = make_xlsx(tmp_path / "i.xlsx", ["Kode", "Nama", "Satuan", "Harga Jual", "Jenis"],
                  [["B1", "Ban", "pcs", 850000, "Barang"], ["J1", "Jasa pasang", None, 50000, "Jasa"]])
    assert xl.import_items(session, admin, f).imported == 2
    kinds = {i.code: i.is_service for i in session.scalars(select(Item))}
    assert kinds == {"B1": False, "J1": True}


def test_import_opening_stock_all_or_nothing(session, admin, tmp_path):
    item = inv.create_item(session, admin, code="B1", name="Ban")
    cap = acc_id(session, "3100")
    ok = make_xlsx(tmp_path / "o.xlsx", ["Kode Barang", "Kode Gudang", "Qty", "Harga Pokok"], [["B1", "GD-UTAMA", 10, 700000]])
    res = xl.import_opening_stock(session, admin, ok, date(Y, 1, 2), cap)
    assert res.ok and item.qty_on_hand == 10 and item.stock_value == D("7000000.00")
    assert tb_net(session, admin, "1300") == D("7000000.00")
    bad = make_xlsx(tmp_path / "o2.xlsx", ["Kode Barang", "Kode Gudang", "Qty", "Harga Pokok"],
                    [["B1", "GD-UTAMA", 5, 100], ["B1", "GD-TIDAK-ADA", 5, 100]])
    res = xl.import_opening_stock(session, admin, bad, date(Y, 1, 3), cap)
    assert not res.ok and any("gudang" in e for e in res.errors)
    assert item.qty_on_hand == 10                                       # baris pertama pun dibatalkan
