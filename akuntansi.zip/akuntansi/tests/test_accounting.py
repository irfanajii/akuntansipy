from datetime import date
from decimal import Decimal

import pytest
from sqlalchemy import select

from app.database.models import Account, FiscalPeriod
from app.services import accounts as acc_svc
from app.services import journals as jr
from app.services.auth import CurrentUser, authenticate
from app.services.errors import AccountingError, PermissionDenied

TODAY = date.today()


def acc_id(session, code):
    return session.scalar(select(Account.id).where(Account.code == code))


def simple_lines(session, amount=100):
    return [
        jr.LineInput(acc_id(session, "1110"), debit=amount),
        jr.LineInput(acc_id(session, "4100"), credit=amount),
    ]


def test_login_wrong_password(session):
    assert authenticate(session, "admin", "salah") is None


def test_post_balanced_journal_and_numbering(session, admin):
    j1 = jr.post_journal(session, admin, TODAY, "Penjualan tunai", simple_lines(session))
    j2 = jr.post_journal(session, admin, TODAY, "Penjualan tunai 2", simple_lines(session, 50))
    assert j1.number == f"JU-{TODAY.year}-00001"
    assert j2.number == f"JU-{TODAY.year}-00002"


def test_unbalanced_journal_rejected(session, admin):
    lines = [
        jr.LineInput(acc_id(session, "1110"), debit=100),
        jr.LineInput(acc_id(session, "4100"), credit=90),
    ]
    with pytest.raises(AccountingError, match="seimbang"):
        jr.post_journal(session, admin, TODAY, "Salah", lines)


def test_line_with_both_sides_rejected(session, admin):
    lines = [
        jr.LineInput(acc_id(session, "1110"), debit=100, credit=100),
        jr.LineInput(acc_id(session, "4100"), credit=100),
    ]
    with pytest.raises(AccountingError):
        jr.post_journal(session, admin, TODAY, "Salah", lines)


def test_header_account_rejected(session, admin):
    lines = [
        jr.LineInput(acc_id(session, "1000"), debit=100),
        jr.LineInput(acc_id(session, "4100"), credit=100),
    ]
    with pytest.raises(AccountingError, match="header"):
        jr.post_journal(session, admin, TODAY, "Salah", lines)


def test_closed_period_rejected(session, admin):
    period = session.scalar(select(FiscalPeriod))
    period.is_closed = True
    session.flush()
    with pytest.raises(AccountingError, match="ditutup"):
        jr.post_journal(session, admin, TODAY, "Terlambat", simple_lines(session))


def test_no_period_rejected(session, admin):
    with pytest.raises(AccountingError, match="periode"):
        jr.post_journal(session, admin, date(1999, 1, 1), "Kuno", simple_lines(session))


def test_permission_checked_in_service(session):
    viewer = CurrentUser(1, "v", "Viewer", "Viewer", frozenset({"journals.view"}))
    with pytest.raises(PermissionDenied):
        jr.post_journal(session, viewer, TODAY, "Tidak boleh", simple_lines(session))


def test_void_creates_reversal_and_nets_to_zero(session, admin):
    original = jr.post_journal(session, admin, TODAY, "Penjualan", simple_lines(session, 250))
    reversal = jr.void_journal(session, admin, original.id, "salah input")
    assert original.status == "REVERSED"
    assert reversal.source == "REVERSAL"
    assert reversal.reversed_of_id == original.id

    tb = jr.trial_balance(session, admin, TODAY)
    assert tb["total_debit"] == tb["total_credit"] == Decimal("0.00")
    assert all(r["balance_debit"] == r["balance_credit"] == 0 for r in tb["rows"])


def test_cannot_void_twice_or_void_reversal(session, admin):
    original = jr.post_journal(session, admin, TODAY, "Penjualan", simple_lines(session))
    reversal = jr.void_journal(session, admin, original.id)
    with pytest.raises(AccountingError, match="sudah dibatalkan"):
        jr.void_journal(session, admin, original.id)
    with pytest.raises(AccountingError, match="pembalik"):
        jr.void_journal(session, admin, reversal.id)


def test_trial_balance_balances(session, admin):
    jr.post_journal(session, admin, TODAY, "Penjualan", simple_lines(session, 300))
    tb = jr.trial_balance(session, admin, TODAY)
    assert tb["total_debit"] == tb["total_credit"] == Decimal("300.00")


def test_account_code_unique_and_parent_must_be_header(session, admin):
    with pytest.raises(AccountingError, match="sudah dipakai"):
        acc_svc.create_account(session, admin, code="1110", name="Dobel", type="ASSET")
    with pytest.raises(AccountingError, match="header"):
        acc_svc.create_account(session, admin, code="1111", name="Anak Kas", type="ASSET",
                               parent_id=acc_id(session, "1110"))


def test_account_edit_conflict_detected(session, admin):
    acc = session.scalar(select(Account).where(Account.code == "1110"))
    with pytest.raises(AccountingError, match="diubah pengguna lain"):
        acc_svc.update_account(session, admin, acc.id, name="Kas Besar", type="ASSET",
                               parent_id=acc.parent_id, is_header=False, is_active=True,
                               expected_version=acc.version + 5)
