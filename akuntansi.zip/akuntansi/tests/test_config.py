from pathlib import Path

import pytest

from app import config as cfgmod
from app.config import DBConfig, config_path, load_config, resolve_sqlite_path, save_config, server_label


def test_save_and_load_roundtrip_with_special_characters(tmp_path):
    cfg = DBConfig(host="192.168.1.10", port=3307, name="akuntansi", user="app", password="p@ss%word=1;#")
    path = save_config(cfg, tmp_path / "sub" / "config.ini")
    loaded = load_config(path)
    assert loaded.host == "192.168.1.10" and loaded.port == 3307 and loaded.password == "p@ss%word=1;#"
    assert loaded.driver == "mysql" and loaded.backup_dir == "backup"


def test_missing_file_gives_clear_message(tmp_path):
    with pytest.raises(FileNotFoundError, match="Pengaturan Koneksi"):
        load_config(tmp_path / "nope.ini")


def test_config_without_database_section(tmp_path):
    f = tmp_path / "c.ini"
    f.write_text("[lain]\nx=1\n")
    with pytest.raises(ValueError, match="database"):
        load_config(f)


def test_config_path_priority(tmp_path, monkeypatch):
    monkeypatch.setenv("AKUNTANSI_CONFIG", str(tmp_path / "env.ini"))
    assert config_path() == tmp_path / "env.ini"
    monkeypatch.delenv("AKUNTANSI_CONFIG")
    monkeypatch.setattr(cfgmod, "base_dir", lambda: tmp_path)
    monkeypatch.setattr(cfgmod, "user_data_dir", lambda: tmp_path / "appdata")
    assert config_path() == tmp_path / "appdata" / "config.ini"       # belum ada config di samping aplikasi
    (tmp_path / "config.ini").write_text("[database]\n")
    assert config_path() == tmp_path / "config.ini"                    # mode portabel / developer


def test_user_data_dir_uses_appdata_on_windows(monkeypatch, tmp_path):
    monkeypatch.setattr(cfgmod.sys, "platform", "win32")
    monkeypatch.setenv("APPDATA", str(tmp_path))
    assert cfgmod.user_data_dir() == tmp_path / "AplikasiAkuntansi"


def test_sqlite_path_resolution_when_frozen(monkeypatch, tmp_path):
    monkeypatch.setattr(cfgmod, "user_data_dir", lambda: tmp_path)
    cfg = DBConfig(driver="sqlite", sqlite_path="akuntansi.db")
    monkeypatch.setattr(cfgmod, "is_frozen", lambda: True)
    assert resolve_sqlite_path(cfg) == tmp_path / "akuntansi.db"
    monkeypatch.setattr(cfgmod, "is_frozen", lambda: False)
    assert resolve_sqlite_path(cfg) == Path("akuntansi.db")
    absolute = DBConfig(driver="sqlite", sqlite_path=str(tmp_path / "x.db"))
    assert resolve_sqlite_path(absolute) == tmp_path / "x.db"


def test_server_label():
    assert server_label(DBConfig(host="10.0.0.5", port=3306, name="akuntansi")) == "10.0.0.5:3306/akuntansi"
