from datetime import date
from decimal import Decimal

import pytest
from openpyxl import Workbook, load_workbook
from sqlalchemy import func, select

from app.database.models import Account, Journal
from app.services import excel_io as xl
from app.services import journals as jr
from app.services.auth import CurrentUser
from app.services.errors import AccountingError, PermissionDenied

TODAY = date.today()


def make_xlsx(path, headers, rows):
    wb = Workbook()
    ws = wb.active
    ws.append(headers)
    for r in rows:
        ws.append(r)
    wb.save(path)
    return path


def count(session, model):
    return session.scalar(select(func.count()).select_from(model))


def acc_id(session, code):
    return session.scalar(select(Account.id).where(Account.code == code))


# ---------------- akun ----------------
def test_import_accounts_parent_after_child_and_numeric_code(session, admin, tmp_path):
    f = make_xlsx(tmp_path / "a.xlsx", ["Kode", "Nama", "Tipe", "Kode Induk", "Header"], [
        [6100, "Beban Bank", "Beban", 6000, "Tidak"],          # kode berupa angka, induk di bawah
        [6000, "BEBAN LAIN", "Beban", None, "Ya"],
    ])
    res = xl.import_accounts(session, admin, f)
    assert res.ok and res.imported == 2
    child = session.scalar(select(Account).where(Account.code == "6100"))
    assert child.parent_id == acc_id(session, "6000")


def test_import_accounts_all_or_nothing(session, admin, tmp_path):
    before = count(session, Account)
    f = make_xlsx(tmp_path / "a.xlsx", ["Kode", "Nama", "Tipe", "Kode Induk", "Header"], [
        ["7000", "Akun Bagus", "Aset", None, "Tidak"],
        ["7100", "Akun Salah", "Tipe Ngawur", None, "Tidak"],
        ["1110", "Kode Dobel dengan DB", "Aset", None, "Tidak"],
    ])
    res = xl.import_accounts(session, admin, f)
    assert not res.ok and res.imported == 0
    assert any("tipe" in e for e in res.errors)
    assert count(session, Account) == before


def test_import_accounts_duplicate_with_db_rolls_back_everything(session, admin, tmp_path):
    before = count(session, Account)
    f = make_xlsx(tmp_path / "a.xlsx", ["Kode", "Nama", "Tipe", "Kode Induk", "Header"], [
        ["7000", "Akun Bagus", "Aset", None, "Tidak"],
        ["1110", "Dobel", "Aset", None, "Tidak"],
    ])
    res = xl.import_accounts(session, admin, f)
    assert not res.ok
    assert any("sudah dipakai" in e for e in res.errors)
    assert count(session, Account) == before


def test_missing_required_column(session, admin, tmp_path):
    f = make_xlsx(tmp_path / "a.xlsx", ["Kode", "Nama"], [["1", "x"]])
    with pytest.raises(AccountingError, match="Kolom wajib"):
        xl.import_accounts(session, admin, f)


def test_not_an_xlsx_file(session, admin, tmp_path):
    bad = tmp_path / "x.xlsx"
    bad.write_text("bukan excel")
    with pytest.raises(AccountingError, match="tidak bisa dibaca"):
        xl.import_accounts(session, admin, bad)


def test_export_accounts_can_be_reimported_format(session, admin, tmp_path):
    f = tmp_path / "out.xlsx"
    n = xl.export_accounts(session, admin, f)
    ws = load_workbook(f).active
    assert ws.max_row == n + 1
    assert [c.value for c in ws[1]][:5] == ["Kode", "Nama", "Tipe", "Kode Induk", "Header"]


# ---------------- jurnal ----------------
J_HEADERS = ["Referensi", "Tanggal", "Keterangan", "Kode Akun", "Keterangan Baris", "Debit", "Kredit"]


def test_import_journals_groups_by_reference(session, admin, tmp_path):
    f = make_xlsx(tmp_path / "j.xlsx", J_HEADERS, [
        ["A1", TODAY, "Penjualan", "1110", None, 1000, None],
        ["A1", None, None, "4100", None, None, 1000],
        ["B1", TODAY, "Bayar listrik", 5300, "tagihan", "250,50", None],   # akun angka, nominal teks
        ["B1", None, None, "1110", None, None, "250,50"],
    ])
    res = xl.import_journals(session, admin, f)
    assert res.ok and res.imported == 2
    assert count(session, Journal) == 2
    tb = jr.trial_balance(session, admin, TODAY)
    assert tb["total_debit"] == tb["total_credit"]


def test_import_journals_all_or_nothing_on_unbalanced(session, admin, tmp_path):
    f = make_xlsx(tmp_path / "j.xlsx", J_HEADERS, [
        ["A1", TODAY, "Bagus", "1110", None, 1000, None],
        ["A1", None, None, "4100", None, None, 1000],
        ["B1", TODAY, "Tidak seimbang", "1110", None, 500, None],
        ["B1", None, None, "4100", None, None, 400],
    ])
    res = xl.import_journals(session, admin, f)
    assert not res.ok and res.imported == 0
    assert any("B1" in e and "seimbang" in e for e in res.errors)
    assert count(session, Journal) == 0  # A1 yang benar pun tidak tersimpan


def test_import_journals_reports_unknown_account_and_bad_date(session, admin, tmp_path):
    f = make_xlsx(tmp_path / "j.xlsx", J_HEADERS, [
        ["A1", TODAY, "x", "9999", None, 10, None],
        ["A2", "31/02/2026", "y", "1110", None, 10, None],
    ])
    res = xl.import_journals(session, admin, f)
    assert not res.ok
    assert any("9999" in e for e in res.errors)
    assert any("tanggal" in e for e in res.errors)


def test_import_requires_permission(session, tmp_path):
    viewer = CurrentUser(1, "v", "V", "Viewer", frozenset({"journals.view", "accounts.view"}))
    f = make_xlsx(tmp_path / "j.xlsx", J_HEADERS, [])
    with pytest.raises(PermissionDenied):
        xl.import_journals(session, viewer, f)
    with pytest.raises(PermissionDenied):
        xl.import_accounts(session, viewer, f)


def test_export_journals_and_formula_text_stays_text(session, admin, tmp_path):
    jr.post_journal(session, admin, TODAY, "=HYPERLINK(\"http://x\",\"klik\")", [
        jr.LineInput(acc_id(session, "1110"), debit=Decimal("100.50")),
        jr.LineInput(acc_id(session, "4100"), credit=Decimal("100.50")),
    ])
    f = tmp_path / "out.xlsx"
    n = xl.export_journals(session, admin, f, date(TODAY.year, 1, 1), TODAY)
    assert n == 2
    ws = load_workbook(f).active
    assert ws["C2"].data_type == "s"          # bukan rumus
    assert ws["H2"].value == pytest.approx(100.5)
    assert ws["I3"].value == pytest.approx(100.5)


def test_export_journals_bad_range(session, admin, tmp_path):
    with pytest.raises(AccountingError):
        xl.export_journals(session, admin, tmp_path / "x.xlsx", TODAY, date(TODAY.year - 1, 1, 1))


def test_export_trial_balance_and_templates(session, admin, tmp_path):
    jr.post_journal(session, admin, TODAY, "Penjualan", [
        jr.LineInput(acc_id(session, "1110"), debit=300),
        jr.LineInput(acc_id(session, "4100"), credit=300),
    ])
    f = tmp_path / "tb.xlsx"
    assert xl.export_trial_balance(session, admin, f, TODAY) == 2
    ws = load_workbook(f).active
    assert ws.cell(ws.max_row, 2).value == "TOTAL"
    assert ws.cell(ws.max_row, 5).value == pytest.approx(300)

    xl.template_accounts(tmp_path / "ta.xlsx")
    xl.template_journals(tmp_path / "tj.xlsx")
    assert load_workbook(tmp_path / "tj.xlsx").sheetnames == ["Jurnal", "Petunjuk"]
