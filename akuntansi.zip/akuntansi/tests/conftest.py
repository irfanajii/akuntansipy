import pytest
from sqlalchemy import create_engine, event
from sqlalchemy.orm import Session

from app.database.models import Base
from app.database.seed import seed
from app.services.auth import authenticate


@pytest.fixture()
def session():
    engine = create_engine("sqlite://")

    # Agar SAVEPOINT (begin_nested) bekerja benar di pysqlite; MySQL/MariaDB tidak perlu ini.
    @event.listens_for(engine, "connect")
    def _no_autobegin(dbapi_conn, _rec):
        dbapi_conn.isolation_level = None

    @event.listens_for(engine, "begin")
    def _emit_begin(conn):
        conn.exec_driver_sql("BEGIN")

    Base.metadata.create_all(engine)
    with Session(engine) as s:
        seed(s, admin_password="rahasia123")
        s.commit()
        yield s


@pytest.fixture()
def admin(session):
    user = authenticate(session, "admin", "rahasia123")
    assert user is not None
    return user
