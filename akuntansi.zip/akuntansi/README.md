# Aplikasi Akuntansi Desktop (Python + PySide6 + MariaDB/MySQL)

Aplikasi akuntansi multi-user untuk jaringan lokal (LAN): satu komputer menjalankan MariaDB/MySQL,
komputer lain menjalankan aplikasi ini dan terhubung ke server.

## Isi aplikasi
| Menu | Fitur |
|---|---|
| Master | Daftar Akun, Pelanggan, Pemasok, Barang & Persediaan (+ gudang), Aset Tetap |
| Penjualan | Faktur (cetak PDF), Penerimaan Pembayaran, Retur Penjualan |
| Pembelian | Faktur (cetak PDF), Pembayaran Hutang, Retur Pembelian |
| Akuntansi | Jurnal Umum (+ import/export Excel), Periode Akuntansi (tutup periode, tutup buku, buka kembali) |
| Laporan | Neraca Saldo, Buku Besar, Laba Rugi, Neraca, Arus Kas, Umur Piutang, Umur Hutang, Laporan Penjualan, Laporan Pembelian, Kartu Stok, Nilai Persediaan, Daftar Aset Tetap, Rekap Pajak. Semua bisa dicetak PDF / export Excel |
| Pengaturan | Perusahaan & akun otomatis, User dan Role, Log Audit |
| Berkas | Ganti Password, Backup Database |

## Pasang sebagai program Windows (installer .exe)
Pengguna akhir cukup menjalankan `AplikasiAkuntansi-Setup-x.y.z.exe`; koneksi database dan pembuatan tabel diisi lewat
jendela di dalam aplikasi. Langkah lengkap: **PANDUAN_INSTALASI.md**. Membuat installer dari kode sumber:
klik dua kali `build_windows.bat` di Windows (butuh Python dan Inno Setup), atau pakai GitHub Actions
(`.github/workflows/build-windows.yml`) tanpa memasang apa pun.

## 1. Siapkan server database (sekali, di komputer server)
1. Edit `setup_database.sql` (password dan subnet), lalu: `mysql -u root -p < setup_database.sql`
2. Pastikan MariaDB menerima koneksi LAN (`bind-address = 0.0.0.0`), buka port 3306 di firewall hanya untuk jaringan lokal.
3. Beri IP tetap (static) pada server.

## 2. Pasang aplikasi (di setiap komputer)
```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy config.ini.example config.ini      (isi host/password server)
```

## 3. Buat / perbarui database (dari satu komputer; versi installer melakukannya lewat jendela di aplikasi)
```
python init_db.py
```
- Pertama kali: membuat tabel, user `admin` (password ditanyakan), contoh akun, gudang utama, periode tahun berjalan.
- Setelah pembaruan aplikasi: **jalankan lagi**. Perintah ini menambah tabel baru, kolom baru pada tabel lama
  (`app/database/schema_sync.py`, hanya penambahan kolom), akun yang dibutuhkan modul baru (mis. 1420, 1500, 4200,
  5400, 5500, 5600 bila kodenya belum ada), pengaturan default, dan izin akses baru untuk role standar.
  Data yang sudah ada tidak dihapus.

## 4. Jalankan
```
python -m app.main
```
Langkah pertama setelah login sebagai admin: **Pengaturan > Pengaturan Perusahaan dan Akun** — isi nama perusahaan dan cocokkan
kode akun (piutang, hutang, persediaan, HPP, pajak, dst.) dengan daftar akun Anda.

## 5. Tes
```
pytest
```
Tes memakai SQLite sementara. Jika ada yang gagal, simpan pesan lengkapnya.

## Cara kerja penting
- **Jurnal & periode:** jurnal harus seimbang; jurnal diposting tidak dihapus tetapi dibatalkan dengan jurnal pembalik; periode
  yang ditutup menolak transaksi. Jurnal otomatis modul lain tidak bisa dibatalkan dari Jurnal Umum.
- **Penjualan/pembelian:** faktur membuat jurnal otomatis. Pembayaran dan retur dibatasi sisa tagihan. Faktur yang sudah
  dibayar atau diretur tidak bisa dibatalkan sebelum dokumen terkait dibatalkan.
- **Persediaan:** metode **rata-rata bergerak** dihitung menurut urutan input transaksi (bukan tanggal transaksi). Stok per
  gudang tidak boleh negatif. Faktur penjualan otomatis membuat HPP (Dr HPP / Cr Persediaan); retur mengembalikan stok pada
  HPP aslinya. Saldo awal stok: *Barang > Import Saldo Awal Stok* atau *Penyesuaian Stok* (akun lawan: modal).
  Laporan *Nilai Persediaan* dibandingkan otomatis dengan saldo akun persediaan di buku besar.
- **Aset tetap:** penyusutan garis lurus bulanan (mulai bulan setelah perolehan). Perolehan aset dicatat lewat faktur pembelian
  (baris akun aset tetap) atau jurnal manual, lalu didaftarkan di menu Aset Tetap. Pelepasan aset menghitung laba/rugi.
- **Tutup buku:** *Tutup Buku* membuat jurnal penutup (pendapatan & beban → Laba Ditahan) dan menyiapkan tahun berikutnya;
  laporan laba rugi tetap menampilkan angka tahun tersebut. *Buka Kembali* membalik jurnal penutup.
- **Arus kas:** metode langsung sederhana; klasifikasi investasi/pendanaan mengikuti kode header di Pengaturan.
- **Pajak:** tarif default faktur 0%. Atur sesuai ketentuan perpajakan usaha Anda. *Rekap Pajak* hanya bahan rekonsiliasi,
  bukan pelaporan pajak resmi/e-Faktur.
- **User & role:** perubahan izin berlaku saat user login berikutnya.
- **Backup:** *Berkas > Backup Database* (butuh `mysqldump` di komputer tersebut; atur `mysqldump_path` di `config.ini`).
  Disarankan menjadwalkan dari server (Windows Task Scheduler): `python backup_cli.py D:\backup 14`
  (simpan 14 backup terbaru). Restore: `mysql -u root -p akuntansi < akuntansi_YYYYMMDD_HHMMSS.sql`.
  Uji restore secara berkala.

## Belum ada
Rekonsiliasi bank, multi mata uang, uang muka/kelebihan bayar pelanggan & pemasok, pemesanan (PO/SO) dan pengiriman barang,
stok minimum, batch/serial, penyusutan saldo menurun, anggaran, penggajian, e-Faktur, dan Alembic (migrasi saat ini hanya
penambahan kolom lewat `init_db.py`).
