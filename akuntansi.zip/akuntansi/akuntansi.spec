# -*- mode: python ; coding: utf-8 -*-
# Build:  pyinstaller --noconfirm --clean akuntansi.spec
# Hasil:  dist/AplikasiAkuntansi/AplikasiAkuntansi.exe (+ folder pendukung), dibungkus installer oleh Inno Setup.
import os
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

hidden = (
    ["pymysql", "cryptography", "sqlalchemy.dialects.mysql.pymysql"]
    + collect_submodules("sqlalchemy.dialects.mysql")
    + collect_submodules("sqlalchemy.dialects.sqlite")
    + collect_submodules("reportlab.pdfbase")
    + collect_submodules("app")          # modul yang diimpor di dalam fungsi ikut terbawa
)
datas = (
    [("config.ini.example", "."), ("setup_database.sql", "."), ("README.md", "."), ("PANDUAN_INSTALASI.md", ".")]
    + collect_data_files("reportlab")
    + collect_data_files("openpyxl")
)
icon = "assets/app.ico" if os.path.exists("assets/app.ico") else None

a = Analysis(
    ["run_app.py"],
    pathex=["."],
    datas=datas,
    hiddenimports=hidden,
    excludes=["tkinter", "pytest", "unittest"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="AplikasiAkuntansi",
    console=False,      # aplikasi jendela (tanpa layar hitam)
    icon=icon,
    upx=False,          # UPX sering memicu peringatan antivirus
)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name="AplikasiAkuntansi")
