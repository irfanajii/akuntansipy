@echo off
setlocal EnableDelayedExpansion
REM ============================================================
REM  Membuat installer Windows: installer_output\AplikasiAkuntansi-Setup-<versi>.exe
REM  Syarat: Python 3.10+ 64-bit (centang "Add python.exe to PATH") dan Inno Setup 6.3+
REM  Jalankan dengan klik dua kali, atau dari Command Prompt di folder ini.
REM  Set SKIP_TESTS=1 untuk melewati pytest.
REM ============================================================
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo Python belum terpasang atau belum ada di PATH.
  exit /b 1
)

if not exist venv_build (
  echo [1/5] Membuat lingkungan virtual...
  python -m venv venv_build || exit /b 1
)
call venv_build\Scripts\activate.bat

echo [2/5] Memasang dependensi...
python -m pip install --upgrade pip || exit /b 1
pip install -r requirements.txt pyinstaller || exit /b 1

if not "%SKIP_TESTS%"=="1" (
  echo [3/5] Menjalankan tes...
  python -m pytest -q
  if errorlevel 1 (
    echo.
    echo Tes GAGAL. Perbaiki dulu atau jalankan ulang dengan: set SKIP_TESTS=1
    exit /b 1
  )
) else (
  echo [3/5] Tes dilewati.
)

echo [4/5] Membuat program dengan PyInstaller...
pyinstaller --noconfirm --clean akuntansi.spec || exit /b 1

for /f %%v in ('python -c "from app.version import __version__; print(__version__)"') do set APPVER=%%v

set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"

if "%ISCC%"=="" (
  echo.
  echo Inno Setup 6 tidak ditemukan. Program sudah jadi di dist\AplikasiAkuntansi
  echo Pasang Inno Setup dari https://jrsoftware.org/isdl.php lalu jalankan skrip ini lagi.
  exit /b 1
)

echo [5/5] Membuat installer dengan Inno Setup...
"%ISCC%" /DMyAppVersion=%APPVER% installer\AplikasiAkuntansi.iss || exit /b 1

echo.
echo Selesai. Installer: installer_output\AplikasiAkuntansi-Setup-%APPVER%.exe
endlocal
