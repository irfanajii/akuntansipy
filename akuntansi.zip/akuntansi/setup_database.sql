-- Jalankan sekali di server MariaDB/MySQL sebagai root:
--   mysql -u root -p < setup_database.sql
-- Sesuaikan password dan subnet jaringan ('192.168.1.%').

CREATE DATABASE IF NOT EXISTS akuntansi
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'akuntansi_app'@'192.168.1.%' IDENTIFIED BY 'GANTI_PASSWORD_INI';
CREATE USER IF NOT EXISTS 'akuntansi_app'@'localhost'   IDENTIFIED BY 'GANTI_PASSWORD_INI';

GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES
  ON akuntansi.* TO 'akuntansi_app'@'192.168.1.%';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, REFERENCES
  ON akuntansi.* TO 'akuntansi_app'@'localhost';

FLUSH PRIVILEGES;
