; Inno Setup 6.3+  (https://jrsoftware.org/isinfo.php)
; Dibuat otomatis oleh build_windows.bat:  ISCC /DMyAppVersion=1.0.0 installer\AplikasiAkuntansi.iss
#define MyAppName "Aplikasi Akuntansi"
#ifndef MyAppVersion
  #define MyAppVersion "1.0.0"
#endif
#define MyAppExe "AplikasiAkuntansi.exe"

[Setup]
; AppId jangan diubah agar versi baru menimpa (update) versi lama, bukan terpasang ganda.
AppId={{6F0B7C52-3D1E-4A64-9B8A-2C5E8F7D1A90}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=..\installer_output
OutputBaseFilename=AplikasiAkuntansi-Setup-{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
UninstallDisplayIcon={app}\{#MyAppExe}
#ifexist "..\assets\app.ico"
SetupIconFile=..\assets\app.ico
#endif
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Buat pintasan di Desktop"; GroupDescription: "Pintasan tambahan:"

[Files]
Source: "..\dist\AplikasiAkuntansi\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"; Tasks: desktopicon
Name: "{autoprograms}\{#MyAppName}\Panduan Instalasi"; Filename: "{app}\PANDUAN_INSTALASI.md"

[Run]
Filename: "{app}\{#MyAppExe}"; Description: "Jalankan {#MyAppName}"; Flags: nowait postinstall skipifsilent

; Pengaturan koneksi dan log disimpan per pengguna di %APPDATA%\AplikasiAkuntansi.
; Folder itu SENGAJA tidak dihapus saat uninstall agar pengaturan tidak hilang saat pembaruan/pemasangan ulang.
