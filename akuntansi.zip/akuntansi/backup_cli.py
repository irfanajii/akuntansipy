"""Backup dari command line / Windows Task Scheduler:  python backup_cli.py [folder] [jumlah_disimpan]"""
import sys

from app.config import load_config
from app.services.backup import backup_database
from app.services.errors import AccountingError


def main() -> int:
    cfg = load_config()
    out = sys.argv[1] if len(sys.argv) > 1 else None
    keep = int(sys.argv[2]) if len(sys.argv) > 2 else 14
    try:
        path = backup_database(cfg, out, keep=keep)
    except AccountingError as exc:
        print(exc)
        return 1
    print(f"Backup tersimpan: {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
