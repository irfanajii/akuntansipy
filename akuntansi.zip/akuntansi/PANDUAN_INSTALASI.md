# Panduan Instalasi (Windows)

Ada dua peran: **komputer server** (menjalankan database) dan **komputer pengguna** (menjalankan aplikasi).
Satu komputer boleh merangkap keduanya.

## A. Komputer server (sekali saja)
1. Pasang **MariaDB** (https://mariadb.org/download) atau MySQL. Catat password `root`.
2. Beri komputer ini **IP tetap** (static) di jaringan, mis. `192.168.1.10`.
3. Buka file `my.ini` MariaDB, pastikan di bagian `[mysqld]` ada `bind-address = 0.0.0.0`, lalu restart layanan MariaDB.
4. Buka **Windows Defender Firewall > Advanced settings > Inbound Rules > New Rule**: Port TCP **3306**, izinkan hanya untuk
   profil *Private* (jaringan kantor). Jangan buka ke internet.
5. Jalankan `setup_database.sql` (ada di folder instalasi aplikasi atau di folder proyek) setelah mengubah password dan
   subnet di dalamnya: `mysql -u root -p < setup_database.sql`
   Ini membuat database `akuntansi` dan user `akuntansi_app`.

## B. Komputer pengguna
1. Jalankan **AplikasiAkuntansi-Setup-x.y.z.exe** (perlu hak Administrator), ikuti langkah-langkahnya.
   - Windows SmartScreen mungkin menampilkan "Windows protected your PC" karena installer belum ditandatangani
     digital. Klik *More info > Run anyway* bila file berasal dari Anda sendiri.
2. Buka **Aplikasi Akuntansi**. Pada pembukaan pertama muncul **Pengaturan Koneksi Database**:
   isi alamat server (`192.168.1.10`), port `3306`, nama database `akuntansi`, user `akuntansi_app`, dan passwordnya.
   Klik **Tes Koneksi**, lalu **Simpan**.
3. Pada komputer **pertama** yang membuka aplikasi, database masih kosong: aplikasi meminta password untuk user `admin`
   lalu membuat tabel dan data awal otomatis. Komputer berikutnya langsung ke layar login.
4. Login sebagai `admin`, buka **Pengaturan > Pengaturan Perusahaan dan Akun**, isi nama perusahaan dan cocokkan kode akun.
5. Buat user lain di **Pengaturan > User dan Role**.

Pengaturan koneksi disimpan per pengguna Windows di `%APPDATA%\AplikasiAkuntansi\config.ini`
(berisi password database; jangan dibagikan). Log kesalahan ada di `%APPDATA%\AplikasiAkuntansi\app.log`.

## C. Memperbarui ke versi baru
1. Minta semua pengguna menutup aplikasi.
2. **Backup database** (lihat bagian D).
3. Jalankan installer versi baru di setiap komputer (menimpa versi lama, pengaturan tetap).
4. Buka aplikasi di satu komputer: bila struktur database perlu diperbarui, aplikasi menawarkan **Perbarui database**.
   Setujui, lalu komputer lain bisa dibuka seperti biasa.

## D. Backup otomatis
- Manual: menu **Berkas > Backup Database** (perlu `mysqldump` di komputer itu; atur `mysqldump_path` di `config.ini`,
  mis. `C:\Program Files\MariaDB 10.11\bin\mysqldump.exe`).
- Terjadwal dari server (Task Scheduler > Create Basic Task > Action *Start a program*):
  `"C:\Program Files\Aplikasi Akuntansi\AplikasiAkuntansi.exe"` dengan argumen `--backup D:\backup-akuntansi 14`
  (simpan 14 backup terbaru). Hasil dicatat di `%APPDATA%\AplikasiAkuntansi\backup.log` milik akun yang menjalankan tugas.
- Salin folder backup ke komputer/disk lain secara berkala dan **uji restore**:
  `mysql -u root -p akuntansi < akuntansi_YYYYMMDD_HHMMSS.sql`

## E. Masalah umum
| Gejala | Penyebab / solusi |
|---|---|
| "Tidak dapat terhubung ke database" | Periksa IP server, port 3306 di firewall server, `bind-address`, user/password, dan apakah subnet pada `setup_database.sql` sesuai jaringan. |
| "Access denied for user" | Password/user salah, atau user belum dibuat untuk alamat komputer ini (ulangi langkah A.5 dengan subnet yang benar). |
| Tidak bisa membuat tabel | User database butuh hak CREATE dan ALTER (sudah ada di `setup_database.sql`). |
| Aplikasi tertutup sendiri | Lihat `%APPDATA%\AplikasiAkuntansi\app.log`. |
| Antivirus menandai file | Program dibungkus PyInstaller dan belum ditandatangani; tambahkan pengecualian atau tandatangani installer dengan sertifikat code signing. |

---
# Untuk pengembang: membuat installer dari kode sumber
**Cara 1 - di komputer Windows (64-bit):** pasang Python 3.10+ (centang *Add to PATH*) dan Inno Setup 6.3+
(https://jrsoftware.org/isdl.php), lalu klik dua kali `build_windows.bat`.
Hasil: `installer_output\AplikasiAkuntansi-Setup-<versi>.exe`.

**Cara 2 - tanpa memasang apa pun:** unggah proyek ke GitHub, buka tab *Actions* > *Build Windows installer* > *Run workflow*;
unduh hasilnya dari *Artifacts*.

Nomor versi ada di `app/version.py`. Jangan mengubah `AppId` di `installer/AplikasiAkuntansi.iss` agar update menimpa
versi lama. Untuk bahasa Indonesia pada wizard installer, tambahkan `Indonesian.isl` (terjemahan tidak resmi Inno Setup).
